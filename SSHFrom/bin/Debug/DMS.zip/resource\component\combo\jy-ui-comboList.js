(function( $, undefined ) {
	
	
	$.widget("ui.comboList",$.ui.combo, {
		options:{ 
			
			keyHandler:{
			}
			
		},
		_onMoveDown:function(){
			if(this._isPanelShow()==false || this._hasLoadJson()==false){
				this._show();
				return;
			}
			
			var row = this.contentPanel.children(".list-item.focus");
			var nextRow = row.next(".list-item");
			if(nextRow.length==0){
				return;
			}
			row.removeClass("focus");
			nextRow.addClass("focus");
			this._resetScroll(nextRow,'down');
		},
		_onMoveUp:function(){
			if(this._isPanelShow()==false || this._hasLoadJson()==false){
				this._show();
				return;
			}
			
			var row = this.contentPanel.find(".list-item.focus");
			var preRow = row.prev(".list-item");
			if(preRow.length==0){
				return;
			}
			row.removeClass("focus");
			preRow.addClass("focus");
			this._resetScroll(preRow,'up');
		},
		_onClick:function(){
			if(this._isPanelShow())
				return;
			this._show();
		},
		_onArrowDown:function(){
			if(this._isPanelShow())
				return;
			this._show();
		},
		_onEnter:function(){
			this._hidePanel();
			var row = this.contentPanel.find(".list-item.focus");
			if(row.length>0){
				this._setValue(row);
			}
			
			//if(this.options.onChange&&this.options.onChange!=null){
			//	this.options.onChange.apply(this,[]);
			//}
			
			if(this.options.onChange) this.options.onChange(row.attr("val"), row.html());
		},
		_onBlur:function(event){
			if(this.options.validate&&this.options.validate==true){
				var val = $.trim(this.element.val());
				var data = this.getDataByText(val);
				if(data==null){
					this.element.val("");   
					this.element.attr("val",""); 
					
					if(this.options.onChange) this.options.onChange("", "");
					
					try{
						var select = this.element.parent().children("select");
						if(select.length>0){
							select.empty();
						}
					}catch(e){}
					
				}else{
					
					if(this.options.colModel==undefined)
						return;
					var id = '';
					for(var j=0;j<this.options.colModel.length;j++){
						var col = this.options.colModel[j];
						//TODO
						if(col==undefined){continue;};
						if(col.name==undefined)
							continue;
						if(col.isValue&&col.isValue==true){
							id = data[col.name];
							continue;
						}
					}
					
					this.element.val(val);
					this.element.attr("val",val); 
					
					if(id != ''){
						var select = this.element.parent().children("select");
						select.empty();
						var option = $("<option></option>");
						option.html(val);
						option.val(id);
						select.append(option);
						
						if(this.element.attr("val") != '' && this.element.attr("val") != val){
							if(this.options.onChange) this.options.onChange(id, val);
						}
						
					}
				}
			}else{
				var val = $.trim(this.element.val());
				this.element.val(val);
				this.element.attr("val",val); 
				
				/*为解决validate为false修改输入条件后向后台传入的不是真实的值,而是上一个选中的值*/
				var select = this.element.parent().children("select");
				if(select.length>0){
					select.empty();
					var option = $("<option></option>");
					option.html(this.element.html());
					option.val(this.element.attr("val"));
					select.append(option);
				}
			}
		},
		_setValue:function(row){
			this.element.val(row.text());
			this.element.attr("val",row.attr("val"));
			this.element.focusEnd();   
			var select = this.element.parent().children("select");
			if(select.length>0){
				select.empty();
				var option = $("<option></option>");
				option.html(row.text());
				option.val(row.attr("val"));
				select.append(option);
			}
			 
		},
		_onChange:function(){
			//alert('change');
			//alert(this.element.val());
			this._show(this.element.val());
		},
		_onShowPanel:function(){
			//this._load();
		},
		_show:function(condition){
			if(this.options.selectable!=null&&this.options.selectable==false){
				return;
			}
			//alert(condition);
			this._showPanel();
			var that = this;
			this._loadJson(condition,function(json){
				
				var datas = that._readJson(json);
				
				if(ObjectUtils.isNotNull(that.options.filterData)){
					datas = that.options.filterData(datas);
				}else{
					datas = that._filterData(datas,condition);
				}
				
				that.____show(datas);
				that._resetScroll();
			});
		},
		____show:function(datas){
			if(datas==null)
				return;
			
			for(var i=0;i<datas.length;i++){
				var data = datas[i];
				this._addRowData(data);
			}
			if(this.contentPanel.find(".list-item.focus").length==0){
				this.contentPanel.children(".list-item:first").addClass("focus");
			}
			if(datas.length==0){
				var row = $("<div class='list-item'>没有找到匹配的信息</div>");
				this.contentPanel.append(row);
				row.click(function(event){
					event.stopPropagation();
				});
			}
		},
		getSelectedRowData:function(){
			var val = this.getVal();
			var json = this._getCacheJson();
			var getColValueModel = function(colModel){
				for(var i=0;i<colModel.length;i++){
					var model = colModel[i];
					if(model.isValue&&model.isValue==true)
						return model.name;
				}
				return colModel[0].name;
			}
			if(json){
				var datas = json[this.options.jsonReader.root];
				if(datas&&datas!=null){
					for(var i=0;i<datas.length;i++){
						var data = datas[i];
						if(data[getColValueModel(this.options.colModel)]==val)
							return data;
					}
				}
			}
			return null;
		},
		addRowData:function(data){
			var json = this._getCacheJson();
			if(json){
				var datas = json[this.options.jsonReader.root];
				if(datas&&datas!=null){
					datas[datas.length]=data;
					this._addRowData(data);
				}
			}
		},
		_addRowData:function(data){			
			if(this.options.colModel==undefined)
				return;
			var that = this;
			var row = $("<div class='list-item'/>");
			for(var j=0;j<this.options.colModel.length;j++){
				var col = this.options.colModel[j];
				//TODO
				if(col==undefined){continue;};
				if(col.name==undefined)
					continue;
				if(col.isValue&&col.isValue==true){
					row.attr("val",data[col.name]);
					continue;
				}
				var html = data[col.name];
				if(j<this.options.colModel.length-1)
					html += " - ";
				row.append(html);
			}
			row.attr("title",row.html());
	        row.mouseover(function(){
	        	$(this).parent().children(".list-item.focus").removeClass("focus");
	        	$(this).addClass("focus");
	        });
	        row.click(function(event){
	        	event.stopPropagation();
	        	that._hidePanel();
	        	var val = that.element.attr("val");
	        	var sel = that.element.parent().children("select");
	        	if(sel.length>0)
	        		val = sel.val();
	        	if($(this).attr("val")!=val&&ObjectUtils.isNotNull(that.options.onchange)){
	        		that.options.onchange();
	        	}
	        	that._setValue($(this));
	        	that.element.focus();
	        	
	        	if(that.options.onChange) that.options.onChange($(this).attr("val"), $(this).html());
	        	
	        	//if(that.options.onChange&&that.options.onChange!=null){
	        	//	that.options.onChange.apply(that,[]);
				//}
	        });
	        this.contentPanel.append(row);
	        /*
	        if(this.oldVal==row.html()){
	        	row.addClass("focus");
	        	row.addClass("on");
	        	this._resetScroll(row,'up');
	        }*/
		},
		_resetScroll:function(row,type){
			var contentPanel = this.contentPanel; 
			if(type=='down'){
				if((row.position().top+row.outerHeight())>contentPanel.innerHeight()){
					contentPanel.scrollTop(
						row.position().top+row.outerHeight()+contentPanel.scrollTop()-contentPanel.innerHeight()
					);
				}
			}else if(type=='up'){
				//alert(row.position().top+":"+this.popupEle.scrollTop());
				if(row.position().top<0){
					contentPanel.scrollTop(
							contentPanel.scrollTop()+row.position().top
					);
				}
			}else{
				contentPanel.scrollTop(0);
			}
		},
		showPanel:function(val){
			/*
			var elementWidth = this.element.outerWidth();
			var containerWidth = this.element.parent().parent().parent().width();
			if(elementWidth>containerWidth){
				this.element.width(this.element.width()-(elementWidth-containerWidth));
			}*/
			this._show();
		},
		hidePanel:function(val){
			/*
			var elementWidth = this.element.outerWidth();
			var containerWidth = this.element.parent().parent().parent().width();
			if(elementWidth>containerWidth){
				this.element.width(this.element.width()-(elementWidth-containerWidth));
			}*/
			this._hidePanel();
		},
		selectByText:function(){
			this.element.select();
		}, 
		getVal:function(){
			return this.element.attr("val");
		},
		getText:function(){
			return this.element.val();
		}
	});


}( jQuery ) );