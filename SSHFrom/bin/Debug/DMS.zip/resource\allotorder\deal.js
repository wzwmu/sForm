var selectedGrid;
/**
 * 调用产品选择窗口后,在窗口中选择商品后点击保存会回调该函数
 * @param datas 被选择产品的json对象数组
 */
function fillProducts(datas){
	 for(var i=0;i<datas.length;i++){
     	datas[i]["productId"] = datas[i]["id"];
     	datas[i]["productName"] = datas[i]["name"];
     	delete datas[i].id;
     }
	$("#"+selectedGrid).editgrid("addRowDatas",datas,"productId");
}
/**
 * 调用产品选择窗口后,在窗口中如果要显示已经被选择的商品,需要提供该函数
 * @return 已经被选择产品的json对象数组
 */
function getRowDatas(){
	return $("#"+selectedGrid).editgrid("getEffectiveRowData","no");
}

$(document).ready(function(){
	initElements();

	$('#frm').validate({
		rules : {
			allotOrderId : {
				required : true
			},
			allotType : {
				required : true
			},
			exportOrgId : {
				required : true
			},
			exportStorageId : {
				required : true
			},
			importAddress : {
				required : true
			},
		},
		messages : {
			id : {},
			allotOrderId : {
				required : '调拔单编号不能为空'
			},
			allotType : {
				required : '请选择调拔类型'
			},
			exportOrgId : {
				required : '请选择调出组织'
			},
			exportStorageId : {
				required : '请选择调出仓库'
			},
			exportAddress : {},
			importAddress : {},
			importOrgId : {
				required : '请选择调入组织'
			},
			importStorageId : {
				required : '请选择调出仓库'
			},
			collator : {},
			collateDate : {}
		}
	});

	$('#AllotDetailsGrid').editgrid({	datatype: 'local',	dataSource:allotDetailsItems,	multiselect: false,	multiboxonly:false,	initRows:1,	autowidth:true,	autoResize:false,	autoResizeHeight:false,	colModel:AllotDetailsCols,	colOpt:[{url:'statics:delete'}],afterSaveCell : function(rowId,name,val,iRow,iCol) {}});
	

		$('.ui-jqgrid-title-AllotDetails').click(function() {
		selectedGrid = 'AllotDetailsGrid';
		$.dialog({
			id : '1',
			title : '选择产品',
			width : 800,
			height : 440,
			lock : false,
			content : 'url:' + base + '/select/selectProduct.do'
		});
	});
	
	
});

var AllotDetailsCols = [ {
		name : 'id',
		label : '主键',
		editable : false,
		hidden : true
	}, {
		name : 'productId',
		label : '产品编号',
		editable : true,
		hidden : false
	}
	/*, {
		name : 'importQuantity',
		label : '调入数量',
		editable : true,
		hidden : false
	}, {
		name : 'cancelQuantity',
		label : '取消数量',
		editable : true,
		hidden : false
	},  {
		name : 'actualQuantity',
		label : '实际调出数量',
		editable : true,
		hidden : false
	}*/,
	{
		name : 'allotQuantity',
		label : '调拔数量',
		editable : true,
		hidden : false
	}, {
		"align" : "center",
		"editable" : false,
		"fixed" : true,
		"hidden" : false,
		"label" : "操作",
		"name" : "operation",
		"sortable" : false,
		"width" : 60
	} ];

/**
 * 页面加载后对界面元素初始化,主要针对下拉类型
 * @return
 */
function initElements(){
	$(".ui-datepicker-input").datepicker();
	$('#allotType').enumeration({
		typecode : 'TCBJ_MOVE_ORDER_TYPE'
	});
	$('#exportOrgId').suppliers({editable:true});
	$('#exportStorageId').enumeration({
		typecode : ''
	});
	$('#exportAddress').enumeration({
		typecode : ''
	});
	$('#importAddress').enumeration({
		typecode : ''
	});
	$('#importOrgId').suppliers({editable:true});
	$('#importStorageId').enumeration({
		typecode : ''
	});
}

/**
 * 触发表单验证
 * @return
 */
function validate(){
	return $("#frm").valid();
}
/**
 * 触发grid验证
 * @return
 */
function validateGrid(){
	return true;
}
/**
 * 调出地址，调入地址级联
 */
$("#exportOrgId").change(function(){
	var id = $(this).val();
	alert("id"+id);
/*	$.ajax({
	   type: "POST",
	   url: "Partner.do",
	   data: "id=" + id,
	   dataType : "json",
	   success: function(partner){
		   initParnterData(partner);
		   initAddressData(partner.addresses);
		   initContactData(partner.contacts);
	   }
	}); */
	
})

