$(document).ready(function(){
	initSubmit();
});
/**
 * 为保存和提交按钮增加事件
 * @return
 */
function initSubmit(){
	$("#saveToBack,#saveToApprove").click(function(){
		$('#CheckVouchItemGrid').editgrid('blur');
		var submitType = $(this).attr("id");
		
		if(validate()==false||validateGrid()==false)
			return;
		var data = FormUtils.getSubmitData($(document));
		data.submitType=submitType;
		data.checkVouchItems = $('#CheckVouchItemGrid').editgrid('getEffectiveRowData','');
		//data.orderApplyItems = $("#productGrid").editgrid("getEffectiveRowData","no");
		//alert(JSON.stringify(data.orderApplyItems)); 
		var toserver = function(){
			var dlg = null;
			Ajax.post({
				url: "audit.do",
				data: data,
				contentType:"application/json;charset=utf-8",
				submitBefore:function(){
					dlg = ResultUtils.showProgress();
				},
				success: function(rtn){
					var title = "<div class='title'>已经将要货单退回给上一步处理,您可以继续选择下面的操作：</div>";
					if(submitType=="saveToApprove"){
						title = "<div class='title'>要货单已经提交到<span class='to'> '"+$("#supplierId_combo").val()+"' </span>审批,您可以继续选择下面的操作：</div>";
					}
					var ctn = title +
							 "<div class='row'><a href=\'audit.do\'>审核下一个要货单</a></div>"+
							 "<div class='row'><a href=\'audits.do?conscope=session\'>返回要货单审核列表</a> （<i>5秒后自动选择</i>）</div>";
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						timer:{
							second:5,
							callback:function(){ 
								window.location.href='audits.do?conscope=session';
							}
						},
						content:ctn
					});
				},   
				error: function(errors){
					var msg = errors[0].message;
					var ctn = "<div class='title'>要货单审核失败,具体原因如下：</div>"+
					 "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				}
			});
		};
		if(submitType=="saveToBack"){
			toserver();
		}else{
			$.dialog.confirm("<span style='padding:0px 30px;'>现在将要货单提交给<span class='to'> '"+$("#supplierId_combo").val()+"' </span>审批吗？</span>",function(){
				toserver();
			});
		}
	});
}