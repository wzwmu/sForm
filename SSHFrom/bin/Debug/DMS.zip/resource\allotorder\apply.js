
$(document).ready(function(){
	initSubmit();
});
/**
 * 为保存和提交按钮增加事件
 * @return
 */
function initSubmit(){
	$("#save,#saveToAudit,#saveToApprove").click(function(){
		$('#AllotDetailsGrid').editgrid('blur');
		var submitType = $(this).attr("id");
		if(validate()==false||validateGrid()==false)
			return;
		var data = FormUtils.getSubmitData($(document));
		data.submitType=submitType;
		data.allotDetailss = $('#AllotDetailsGrid').editgrid('getEffectiveRowData','');
		var toserver = function(){
			var dlg = null;
			Ajax.post({
				url: "apply.do",
				data: data,
				contentType:"application/json;charset=utf-8",
				submitBefore:function(){
					dlg = ResultUtils.showProgress();
				},
				success: function(rtn){
					var title = "<div class='title'>已经将要货单已经保存,您可以继续选择下面的操作：</div>";
					if(submitType=="saveToAudit"){
						title = "<div class='title'>要货单已经提交下一步审核,您可以继续选择下面的操作：</div>";
					}else if(submitType=="saveToApprove"){
						title = "<div class='title'>要货单已经提交到<span class='to'> '"+$("#supplierId_combo").val()+"' </span>审批,您可以继续选择下面的操作：</div>";
					}
					
					var ctn = title +
							 "<div class='row'><a href=\'apply.do\'>填写新的要货单</a></div>"+
							 "<div class='row'><a href=\'applys.do?conscope=session\'>返回要货单列表</a> （<i>5秒后自动选择</i>）</div>";
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						timer:{
							second:5,
							callback:function(){ 
								window.location.href='applys.do?conscope=session';
							}
						},
						content:ctn
					});
				},   
				error: function(errors){
					var msg = errors[0].message;
					var ctn = "<div class='title'>要货单提交失败,具体原因如下：</div>"+
					 "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				}
			});
		};
		if(submitType=="save"||submitType=="saveToBack"){
			toserver();
		}else{
			var title = "<span style='padding:0px 30px;'>现在将要货单提交到下一步审核吗？</span>";
			if(submitType=="saveToApprove")
				title = "<span style='padding:0px 30px;'>现在将要货单提交给<span class='to'>'"+$("#supplierId_combo").val()+"'</span>审核吗？</span>"
			$.dialog.confirm(title,function(){
				toserver();
			});
		}
	});
}