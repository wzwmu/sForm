$(document).ready(function(){

	$('#driverId').enumcontacts();
	$('#deliveryId').enumcontacts();
	
	$('#carType').enumeration({
		typecode : 'car_type',
		clear: true
	});
	
	$('#carType').enumeration({
		typecode : 'car_type'
	});
	$('#state').enumeration({
		typecode : 'car_state'
	});
	

	//新增
	$('.submit').click(function() {
		var title = "<div class='title'>已操作成功,您可以继续选择下面的操作：</div>" +
	 	"<div class='row'>" +
	 		"<a href=\'toAdd.do\'>新增车辆</a>" +
	 	"</div>" +
	 	"<div class='row'>" +
	 		"<a href=\'toIndex.do\'>返回车辆查询列表</a>" +
	 	"</div>";
		
		if(validate()==false){
			return;
		}
		
		var data = FormUtils.getSubmitData($(document));
		var dlg = null;
		Ajax.post({
			url : 'add.do',
			data : data,
			contentType : 'application/json;charset=utf-8',
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success : function(rtn) {
				if(rtn && rtn.msg && rtn.msg!=null){
					var msg = rtn.msg;
					var ctn = "<div class='title'>修改失败,具体原因如下：</div>"+
			 		  "<div class='row'>"+msg+"</div>";
			 		  
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				} else{
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						timer:{
							second:5,
							callback:function(){ 
								window.location.href='toIndex.do';
							}
						},
						content:title
					});
				}
			},
			error : function(errors) {
				var msg = errors[0].message;
				var ctn = "<div class='title'>保存失败,具体原因如下：</div>"+
				 		  "<div class='row'>"+msg+"</div>";
				 		  
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
			}
		});
	});
	
	
	//修改
	$('.edit').click(function() {
		var id = $("#id").val();
		var title = "<div class='title'>已操作成功,您可以继续选择下面的操作：</div>" +
	 	"<div class='row'>" +
	 		"<a href=\'toIndex.do\'>返回车辆查询列表</a>" +
	 	"</div>";
		if(validate()==false){
			return;
		}
		
		var data = FormUtils.getSubmitData($(document));
		var dlg = null;
		Ajax.post({
			url : 'edit.do',
			data : data,
			contentType : 'application/json;charset=utf-8',
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success : function(rtn) {
				if(rtn && rtn.msg && rtn.msg!=null){
					var msg = rtn.msg;
					var ctn = "<div class='title'>修改失败,具体原因如下：</div>"+
			 		  "<div class='row'>"+msg+"</div>";
			 		  
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				} else{
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						timer:{
							second:5,
							callback:function(){ 
								window.location.href='toIndex.do';
							}
						},
						content:title
					});
				}
			},
			error : function(errors) {
				var msg = errors[0].message;
				var ctn = "<div class='title'>修改失败,具体原因如下：</div>"+
		 		  "<div class='row'>"+msg+"</div>";
		 		  
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
			}
		});
	});
	
});

function validate(){
	return $('#frm').valid();
}

