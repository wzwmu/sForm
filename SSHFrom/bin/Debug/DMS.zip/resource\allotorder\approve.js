$(document).ready(function(){
	initSubmit();
});
/**
 * 为提交按钮增加事件
 * @return
 */
function initSubmit(){
	$("#approve").click(function(){
		
		var sel = $('input:radio[name="opinion"]:checked');
		if(sel.length==0){
			$("#approveerror").show();
			return false;
		}else{
			$("#approveerror").hide();
		}
		var data = FormUtils.getSubmitData($(document));
		data.opinion = sel.val();
		//alert(JSON.stringify(data)); 
		var toserver = function(){
			var dlg = null;
			Ajax.post({
				url: "approve.do?id=data.id",
				data: data,
				contentType:"application/json;charset=utf-8",
				submitBefore:function(){
					dlg = ResultUtils.showProgress();
				},
				success: function(rtn){
					var title = "<div class='title'>审批不通过,已经将订单发回给客户,您可以继续选择下面的操作：</div>";
					if(data.opinion=="agreen"){
						title = "<div class='title'>客户的订单审批通过,您可以继续选择下面的操作：</div>";
					}
					var ctn = title +
							 "<div class='row'><a href=\'approve.do\'>审批下一个要货单</a></div>"+
							 "<div class='row'><a href=\'approves.do?conscope=session\'>返回销售订单审批列表</a> （<i>5秒后自动选择</i>）</div>";
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						timer:{
							second:5,
							callback:function(){ 
								window.location.href='approves.do?conscope=session';
							}
						},
						content:ctn
					});
				},   
				error: function(errors){
					var msg = errors[0].message;
					var ctn = "<div class='title'>订单审批失败,具体原因如下：</div>"+
					 "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				}
			});
		};
		var title = "订单审批不通过,该订单将被发回给客户进行处理";
		if(data.opinion=="agreen"){
			title = "订单审批通过,请做好订单后续出库准备！";
		}
		$.dialog.confirm(title,function(){
			toserver();
		});
	});
}