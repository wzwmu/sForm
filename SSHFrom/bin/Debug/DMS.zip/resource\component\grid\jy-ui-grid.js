(function( $, undefined ) {
	
	$.widget("ui.grid", {
		options:{ 
			url:'',
			/*
			 * 支持三种类型:
			 * 'json':数据通过ajax从url获取;
			 * 'local':数据通过编写本地代码this.grid.jqGrid('addRowData',i+1,data);获取
			 * 'init':数据由组件初始化空白行,空白行数通过initRows设置,initRows默认值10
			 */
			datatype:'local',
			dataSource:null,
			/*
			 * 数据的格式类型:
			 * 'page':翻页类数据;
			 * 'list':列表类数据 
			 */
			arraytype:'page',
			/*
			 * [自定义属性]最少显示行数
			 */
			initRows:10,
			/*
			 * grid是否增加浏览器窗口resize感知后自动调整窗口大小
			 */
			autoResize:false,
			autoResizeHeight:null,
			autoResizeWidth:null,
			/*
			 * 表格高度设置:
			 * 'auto':自动拉升高度,表格内不出现滚动条
			 * 数值:表格绝对高度,内容超出出现纵向滚动条
			 */
			height: 'auto',
			/*
			 * 表格序号设置:
			 * true:自动出现序号
			 * false:不出现序号
			 */
			
			autowidth :false,
			cellEdit: false,
			gridview: true,
			onselectrow: false,
			shrinkToFit:true,
            forceFit: true,
			cellsubmit: 'clientArray',
			jsonReader: {
				/*
				 * 集合的名称
				 */
				root: "list",
				/*
				 * 最大页码
				 */
				total: "maxPage",
				/*
				 * 当前页码
				 */
				page: "currentPage",
				/*
				 * json中代表数据行总数的数据
				 */
				records: "records", 
				repeatitems: false //
			},
			prmNames : {
				page:"pageno", // 表示请求页码的参数名称
				rows:"rowsize", // 表示请求行数的参数名称
				sort: "sidx", // 表示用于排序的列名的参数名称
				order: "sord", // 表示采用的排序方式的参数名称
				search:"_search", // 表示是否是搜索请求的参数名称
				nd:"nd", // 表示已经发送请求的次数的参数名称
				id:"id", // 表示当在编辑数据模块中发送数据时，使用的id的名称
				oper:"oper", // operation参数名称
				editoper:"edit", // 当在edit模式中提交数据时，操作的名称
				addoper:"add", // 当在add模式中提交数据时，操作的名称
				deloper:"del", // 当在delete模式中提交数据时，操作的名称
				subgridid:"id", // 当点击以载入数据到子表时，传递的数据名称
				npage: null,
				totalrows:"totalrows" // 表示需从Server得到总共多少行数据的参数名称，参见jqGrid选项中的rowTotal
			},

			sortname: 'id',
			/*
			 * 多选
			 */
			multiselect: false,
			/*
			 * 行事件不能多选,只有复选框可以多选
			 */
			multiboxonly:false,
			/*
			 * 列表最左侧是否显示行数
			 */
			rownumbers:true,
			/*
			 * 默认每页行数
			 */
			rowNum:10,
			/*
			 * 是否显示每页记录数下拉框
			 */
		   	rowList:[10,20,30,50,100,150],//
		    /*
		     * 在右下角是否显示记录数
		     */
		   	viewrecords: true,
			/*
			 * grid数据是否指加载一次,如果设置为true,
			 * grid.trigger("reloadGrid")不起作用
			 */
		    loadonce: false,
			formatCell: function(rowid,name,val,iRow,iCol) {
            },
            beforeSubmitCell: function(rowid,name,val,iRow,iCol) {
            	//$(".goodsAuto").parent().appendTo($("#selectcontainer"));
            	//var rowData = {title:'sdfsdf'};
				//grid.jqGrid('setRowData', rowid, rowData);
            },
            afterSaveCell : function(rowid,name,val,iRow,iCol) {
                
            },
            ondblClickRow: function (rowid,iRow,iCol,e) {
            }
		}, 
		widget: function() {
			return this;
		},
		/*
		 * [自定义属性]当前选中行号
		 */
		_iRow:null,
		/*
		 * [自定义属性]当前选中列号
		 */
		_iCol:null,
		_resize:function(){
			/*
			 * 需先设置高度,再设置宽度才不会出现横向滚动条,顺序不能乱
			 */    
			var parent = $("#gbox_"+this.element.attr("id")).parent(); 
			if(parent.is('form'))
				parent = parent.parent();
			var top = 0,width=parent.width();  
			if(this.options.autoResizeHeight==null||this.options.autoResizeHeight==true){
				//alert(this.grid.offset());
				this.grid.setGridHeight($(window).height()-this.grid.offset().top-80);
			}
			if(this.options.autoResizeWidth==null||this.options.autoResizeWidth==true){
				this.grid.setGridWidth(width);
			}
		},
		_resetOptions:function(){
			this._resetOptionsForColModel();
		},
		_resetOptionsForColModel:function(){
			var colModels = this.options.colModel;
			for(var i=0;i<colModels.length;i++){
				var col = colModels[i];
				if(ObjectUtils.isNull(col))
					continue;
				if(StringUtils.isNotEmpty(col.edittype)){
					var edittypeObj = GridPlugins.getEdittype(col.edittype);
					if(edittypeObj!=null){
						col.edittype = "custom";
						col.editoptions = {};
						col.editoptions.custom_element=edittypeObj.element;
						col.editoptions.custom_value=edittypeObj.value;
						col.editoptions.handle=edittypeObj.handle;
						col.editoptions.show=edittypeObj.show;
					}
				}
				if(typeof(col.formatter)=="string"){
					if(col.formatter.indexOf("GridUtils")>=0){
						col.formatter = function(val, opt, row){
							var str = GridUtils.showGroup(val, opt, row);
							return str;
						};
					}
						
				}
			}
		},
		_create: function(){ 
			this._resetOptions();
			var that = this;
			/*
			 * 扩展grid的afterEditCell事件,
			 * 在扩展中增加对自定义枚举类型的显示
			 */
			var tmp = this.options.afterEditCell;
			var afterEditCell = function (rowid,name,val,iRow,iCol){
				var editoptions = $(this).getGridParam("colModel")[iCol].editoptions;
				if(typeof(editoptions)!=undefined&&editoptions!=null){
					var onShow = editoptions.show;
					if(typeof(onShow)!=undefined&&$.trim(onShow)!=='')
						onShow();
				}
				if(tmp!=undefined){
					tmp(rowid,name,val,iRow,iCol);
				}
				that._iRow = iRow;
				that._iCol = iCol;
				
            };
			this.options.afterEditCell = afterEditCell;
			
			/*
			 * 如果是列表型grid,做如下设置:
			 * 1、页脚只显示记录数,不显示翻页信息
			 * 2、rowNum默认值设置为5000
			 * 3、数据读取器root设为数据本身
			 */
			if(this.options.arraytype=='list'){
				this.options.rowList=[];
				if(this.options.rowNum&&this.options.rowNum==10)
					this.options.rowNum=5000;
				this.options.pgbuttons=false;
				this.options.pginput=false;
				this.options.jsonReader.root="";
			}
			
			/**
			 * 支持自定义属性colOpt,能够自动生成列表操作
			 * var colOpts = [];
			if(that.options.colOpt!=null){
				if(that.options.colOpt instanceof Function)
					colOpts = that.options.colOpt();
				else
					colOpts = that.options.colOpt;
			} 
			alert(JSON.stringify(colOpts));
			this.options.colOpt = colOpts;
			
			
			if(this.options.colOpt!=null&&this.options.colOpt.length>0){
				for(var i=0;i<this.options.colOpt.length;i++){
					var opt = this.options.colOpt[i];
					var url = opt.url;
					if(ObjectUtils.isNull(url))
						continue;
					if(url==="statics:insert"){
						opt.cls = StringUtils.isNotEmpty(opt.cls)?opt.cls:'ui-icon-plus';
						opt.title = StringUtils.isNotEmpty(opt.title)?opt.title:'新增行';
					}else if(url==="statics:delete"){
						opt.cls = StringUtils.isNotEmpty(opt.cls)?opt.cls:'ui-icon-trash';
						opt.title = StringUtils.isNotEmpty(opt.title)?opt.title:'删除行';
					}else{
						opt.cls = StringUtils.isNotEmpty(opt.cls)?opt.cls:'ui-icon-document';
						opt.title = StringUtils.isNotEmpty(opt.title)?opt.title:null;
					}
					this.options.colOpt[i] = opt;
				}
			} */
			
			var getColOpt = function(rowData){
				var colOpt = that.options.colOpt;
				if(that.options.colOpt instanceof Function){
					colOpt = that.options.colOpt(rowData);
				}
				if(colOpt==null)
					return [];
				return colOpt;
			};
			
			var colModel = this.options.colModel;
			for(var i=0;i<colModel.length;i++){
				if(ObjectUtils.isNull(colModel[i]))
					continue;
				if("operation"!=colModel[i].name&&"operating"!=colModel[i].name)
					continue;
				colModel[i].formatter=function(val, opt, row){
					var opts = [];
					opts[opts.length] = "<div class='m-grid-operation' data-id='";
					opts[opts.length] = opt.rowId;
					opts[opts.length] = "'>"; 
					
					if(that.options.colOpt==null)
						return "";
					
					
					var colOpt = getColOpt(row);
					for(var i=0;i<colOpt.length;i++){
						var opt = colOpt[i];
						var url = opt.url,cls=null,title=null;
						if(url==="statics:insert"){
							cls = StringUtils.isNotEmpty(opt.cls)?opt.cls:'ui-icon ui-icon-plus';
							title = StringUtils.isNotEmpty(opt.title)?opt.title:'新增行';
						}else if(url==="statics:delete"){
							cls = StringUtils.isNotEmpty(opt.cls)?opt.cls:'ui-icon ui-icon-trash';
							title = StringUtils.isNotEmpty(opt.title)?opt.title:'删除行';
						} else if(url==="statics:view_"){
							cls = 'view';
							title = '查看';
							opt.name = '&nbsp;<a href="javascript:;">查看</a>&nbsp;';
						} else if(url==="statics:delete_"){
							cls = 'delete';
							title = '删除';
							opt.name = '&nbsp;<a href="javascript:;">删除</a>&nbsp;';
						} else if(url==="statics:edit_"){
							cls = 'edit';
							title = '编辑';
							opt.name = '&nbsp;<a href="javascript:;">编辑</a>&nbsp;';
						} else if(url==="statics:up"){
							cls = 'up_move';
							title = '上移';
							opt.name = '&nbsp;<a href="javascript:;">上移</a>&nbsp;';
						}else if(url==="statics:down"){
							cls = 'down_move';
							title = '下移';
							opt.name = '&nbsp;<a href="javascript:;">下移</a>&nbsp;';
						}else{
							cls = StringUtils.isNotEmpty(opt.cls)?opt.cls:'ui-icon ui-icon-document';
							title = StringUtils.isNotEmpty(opt.title)?opt.title:null;
						}
						
						opts[opts.length] = "<span class='"+cls+"'";
						if(opt.title!=null)
							opts[opts.length] = "title='"+title+"'" ;
						opts[opts.length] = ">";
						if(opt.name!=null)
							opts[opts.length] = opt.name;
						opts[opts.length] = "</span>";
					}
				    opts[opts.length] = "</div>";
				    return opts.join("");
				};
			}
			
			this.grid = this.element.jqGrid(this.options);
			
			var iconClick = function(e,rowid,rowData){
				var opt = getColOpt(rowData)[$(this).index()];
				var 
				url = StringUtils.isNotEmpty(opt.url)?opt.url:"",
				title=null,
				target=StringUtils.isNotEmpty(opt.target)?opt.target:'popup';
				var allowEmpty = opt.allowEmpty;
				if(url=="")
					return;
				if(url==="statics:insert"){
					that._insertRow(rowid);
				}else if(url==="statics:delete"){
					
					that.blur();
					
					if(opt.isDelete) {
						opt.isDelete.apply($(this),[that,allowEmpty,rowid,rowData]);
						return;
					}
						
				
						
					if(typeof(allowEmpty)!=='undefined'&&allowEmpty!=null&&allowEmpty==true)
						that.delRow(rowid);
					else
						that.delRowNotEmpty(rowid);
					if(opt.callback)
						opt.callback.apply($(this),[e,rowid,rowData]);
				}else if(url==="javascript"){
					//应用层自行实现
					if(opt.callback)
						opt.callback.apply($(this),[e,rowid,rowData]);
						
				}else if(url==="statics:view_"){

					opt.callback.apply($(this),[e,rowid,rowData]);

				} else if(url==="statics:delete_"){

					that.delRow(rowid);
					
				}else if(url==="statics:edit_"){

					opt.callback.apply($(this),[e,rowid,rowData]);

				} else if(url==="statics:up" || url==="statics:down"){
					
					opt.callback.apply($(this),[e,rowid,rowData]);
					
				}else{
					url = StringUtils.replaceTemplate(url,rowData);
					title = StringUtils.isNotEmpty(opt.title)?opt.title:''; 
					if(target==="popup"){
						var popupOpt = { 
							    id: '1', 
							    title: title, 
							    width: '700px', 
							    height: 350, 
							    lock: true, 
							    content:'url:'+url
						};
						popupOpt = $.extend(popupOpt,opt.popupOpt);
						$.dialog(popupOpt);
					}else if(target==="self"){
						window.location.href = url;
					}else if(target==="ajax"){
						var render = opt&&opt.ajaxOpt&&opt.ajaxOpt.render?opt.ajaxOpt.render:'delete';
						$.dialog.confirm("你确定要"+title+"吗？", function(){
						    //var tip = $.dialog.tips("正在"+title+"...");
						    Ajax.get({
						    	url:url,
								data:{},
							    success:function(data){
									//tip.close();
									if(render==='delete')
										that.grid.jqGrid("delRowData",rowid,{reloadAfterSubmit:false});
									else if(render==='update')
										that.grid.jqGrid("setRowData",rowid,data);
							    },
							    error:function(err) {
							    	//tip.close();
					            }
						    });
						});
					}
				}
			};
			this.grid.on('click', ".m-grid-operation span", function(e){
				var rowid = $(this).parent().data('id');
				var title = $(this).attr("title");
				var rowData = that.grid.getRowData(rowid);
				rowData["___title"] = title;
				iconClick.apply($(this),[e,rowid,rowData]);
			});
			
			//this.grid.jqGrid('setGridParam',{cellEdit: true,editurl:'#',url:'#'});
			
			var initRows = this.options.initRows||0;
			if(this.options.datatype&&this.options.datatype==='init'){
				for(var i=0;i<initRows;i++)
					this.grid.jqGrid('addRowData',i+1,{});
			}else if(this.options.datatype&&this.options.datatype==='local' && this.options.dataSource!=null){
				var list = this.options.dataSource;
				if(typeof(list)=="string")
					list = eval(list);
				/*
				this.grid[0].addJSONData(list);
				for(var i=list.length;i<initRows;i++)
					this.grid.jqGrid('addRowData',i+1,{});
					*/
				for(var i=0;i<=list.length;i++)
					this.grid.jqGrid('addRowData',i+1,list[i]);
				for(var i=list.length;i<initRows;i++)
					this.grid.jqGrid('addRowData',i+1,{});	
				
			}else if(this.options.datatype&&this.options.datatype==='json'){
				//TODO 暂不实现自动填充空白行 	
			}else{
				
			}
			
			/*
			 * 取消单元格选中,设为行选中
			 */
			this.grid.jqGrid('setGridParam',{cellEdit: false});
			if(this.options.autoResize==true){
				var that = this;
				this._resize();
				$(window).resize(function(){
					that._resize();
				});
			}
		},
		_delRow:function(rowId){
			this.blur();
			this.grid.jqGrid("delRowData",rowId,{});
		},
		_insertRow:function(rowId){
			var ids = this.grid.jqGrid('getDataIDs'); 
			
			//TODO 在在分页情况下rowId不是整数
		    //var newrowId = (ids.length ==0 ? 1: Math.max.apply(Math,ids)+1);  
			var newrowId = Math.random();
			//alert(newrowId);
			/**
			 * 根据源代码查看addRowData(newrowid,data,pos,src)
			 * newrowid是新行id，需要重新指定不能与原有数据行id相同
			 * {}新行数据
			 * pos:first,last,before,after,其中before,after为相对位置
			 * src:相对位置rowid
			 */
		    this.grid.jqGrid("addRowData",newrowId,{},'after',rowId);;  
		},
		_edit:function(rowId,rowData){
			var title = rowData["___title"];
			$.dialog({ 
			    id: '1', 
			    title: title, 
			    width: '700px', 
			    height: 350, 
			    lock: true, 
			    content:'url:edit.do?id='+rowData.id
			});
		},
		_delete:function(rowId,rowData){
			var title = rowData["___title"];
			var that = this;
    		$.dialog.confirm("你确定要"+title+"吗？", function(){
	    		var tip = $.dialog.tips("正在"+title+"数据...");
				$.ajax({
					url:'delete.do',
					data:{id:rowData.id},
					method:'get',
					success:function(){
						tip.close();
						that.grid.jqGrid("delRowData",rowId,{reloadAfterSubmit:false});
					}
				});
			});
		},
		_init:function(){
		},
		destroy:function(){ 
			this.element.removeClass("ui-grid"); 
		},
		showme:function(){
			alert("11");
		},
		resize:function(){
			this._resize();
		},
		getEffectiveRowData:function(condition){
			var ids = this.grid.jqGrid('getDataIDs');
			var rowData = new Array();
			for(var i = 0, len = ids.length; i < len; i++){
				var row = this.grid.jqGrid('getRowData',ids[i]);
				delete row.operation;
				if(StringUtils.isEmpty(condition))
					rowData[rowData.length] = row;
				else if(StringUtils.isNotEmpty(row[condition]))
					rowData[rowData.length] = row;
			};
			return rowData;
		},
		// 新增，用于订单，获取整型数据
		getEffectiveRowDataPm2:function(condition,parameter){
			var ids = this.grid.jqGrid('getDataIDs');
			var rowData = new Array();
			for(var i = 0, len = ids.length; i < len; i++){
				var row = this.grid.jqGrid('getRowData',ids[i]);
				delete row.operation;
				
				var con1 = parseInt(row[condition]);
				var con2 = parseInt(row[parameter]);
				
				if(StringUtils.isEmpty(condition)){
					rowData[rowData.length] = row;	
				}else if(!isNaN(con1) || !isNaN(con2)){
					if(isNaN(con1)){
						row[condition] = '';
					}else{
						row[condition] = con1;
					}
					if(isNaN(con2)){
						row[parameter] = '';
					}else{
						row[parameter] = con2;
					}
					rowData[rowData.length] = row;
				}
			};
			return rowData;
		},
		getEffectiveRowDataByCols:function(cols){
			var ids = this.grid.jqGrid('getDataIDs');
			var rowData = new Array();
			for(var i = 0, len = ids.length; i < len; i++){
				var row = this.grid.jqGrid('getRowData',ids[i]);
				delete row.operation;
				if(cols==null)
					rowData[rowData.length] = row;
				else if(StringUtils.isNotEmpty(row[cols[0]])||StringUtils.isNotEmpty(row[cols[1]]))
					rowData[rowData.length] = row;
			};
			return rowData;
		}, 
		delRowNotEmpty:function(rowId){
			this.blur();
			var ids = this.grid.jqGrid('getDataIDs');
			if(ids.length<=1)
				return;
			this.grid.jqGrid("delRowData",rowId,{});
		},
		delRow:function(rowId){ 
			this.grid.jqGrid("delRowData",rowId,{});
		},
		delRows:function(){
			var ids = this.grid.jqGrid('getDataIDs');
			for(var i=0;i<ids.length;i++){
				this.delRow(ids[i]);
			}
		},
		setGridParam:function(config){
			return this.grid.jqGrid('setGridParam',config);
		},
		getSelRow:function(){
			return this._iRow;
		},
		getSelCell:function(){
			return this._iCol;
		},
		clearSelRow:function(){
			this._iRow = null;
		},
		clearSelCell:function(){
			this._iCol = null;
		},
		blur:function(){
			if(this._iRow!=null&&this._iCol!=null){
				this.grid.editCell(this._iRow, this._iCol, false);
				this.clearSelRow();
				this.clearSelCell();
			}
		},
		_addRowData:function(data,type){
			var ids = this.grid.jqGrid('getDataIDs');  
		    var newrowId = (ids.length ==0 ? 1: Math.max.apply(Math,ids)+1);  
		    if(type!=null){
		    	 newrowId = Math.random();
		    }
			this.grid.jqGrid('addRowData',newrowId,data);
			//this.grid.resetSelection();
			//this.grid.setSelection(newrowId);
		}, 
		addRowData:function(data){
			this._addRowData(data,null);
		}, 
		addRowDataForPage:function(data){
			this._addRowData(data,'page');
		}, 
		addRowDataFirst:function(data){
//			var ids = this.grid.jqGrid('getDataIDs');  
//		    var newrowId = (ids.length ==0 ? 1: Math.max.apply(Math,ids)+1);  
			this.grid.jqGrid('addRowData',0,data);
			//this.grid.resetSelection();
			//this.grid.setSelection(newrowId);
		},
		_addRowDatas:function(datas,prop,type){
			if(datas==null||datas.length==0) return;
			var val = this.grid.jqGrid("getRowData",1)[prop];
			if(StringUtils.isEmpty(val)){ 
				this.grid.jqGrid("delRowData",1,{});
			}
			var sels = {};
			var ids = this.grid.jqGrid('getDataIDs');
			for(var i = 0, len = ids.length; i < len; i++){
				var rowData = this.grid.jqGrid('getRowData',ids[i]);
				sels[rowData[prop]] = rowData[prop];
			}; 
			for(var i=0;i<datas.length;i++){
				if(StringUtils.isEmpty(sels[datas[i][prop]])){
					if (type==null)
						this.addRowData(datas[i]);
					else
						this.addRowDataForPage(datas[i]);
				}
			}
		},
		addRowDatas:function(datas,prop){
			this._addRowDatas(datas,prop,null);
		},
		addRowDatasForPage:function(datas,prop){
			this._addRowDatas(datas,prop,'page');
		},
		setRowData:function(rowid,rowData){
			this.grid.jqGrid("setRowData",rowid,rowData);
		},
		setSelections:function(datas,prop){
			if(datas==null&&datas.length==0)
				return;
			var ids = this.grid.jqGrid('getDataIDs');
			for(var i = 0, len = datas.length; i < len; i++){
				var val = datas[i][prop];
				if(StringUtils.isEmpty(val))
					continue;
				for(var j=0;j<ids.length;j++){
					var d = this.getRowData(ids[j]);
					if(d[prop]==val){
						this.grid.setSelection(ids[j]);
						break;
					}
				}
			}; 
		},
		getRowData:function(rowid){
			return this.grid.jqGrid("getRowData",rowid);
		},
		getSelRowDatas:function(){
			var datas = [];
			var ids = this.grid.jqGrid("getGridParam","selarrrow");
			for(var i = 0, len = ids.length; i < len; i++){
				var data = this.grid.jqGrid('getRowData',ids[i]);
				datas[datas.length] = data;
			}; 
			return datas;
		},
		footerData:function(type,data){
			this.grid.jqGrid("footerData",type,data);
		},
		getGridParam:function(type){
			return this.grid.jqGrid("getGridParam",type);	
		}
	});


}( jQuery ) );