/**
 * config = {
 * 		title: title, 
		width: '700px', 
		height: 350, 
		lock: true, 
		url:"",
		form:''
 * }
 */
$.fn.popup = function(config){   
	var module = $(this);
	if(!config)
		config = {};
	var popupOpt = { 
		    id: '1', 
		    title: "弹出窗口", 
		    width: 700, 
		    height: 350, 
		    lock: true, 
		    content:"url:about:blank"
	};
	popupOpt = $.extend(popupOpt,config);
	
			if(config.before&&typeof(config.before)=="function"){
				if(config.before()==false)
					return;
			}
			if(config.init&&typeof(config.init)=="function"){
				config.init();
			}
			var p = $.dialog(popupOpt);
			if(config.content&&typeof(config.content)=="function"){
				//p.content(config.content());
				var c = config.content();
				if(typeof(c)=="string"&&c.indexOf("url:")>=0){
					isurl = true;
				}
			}
			if(config.after&&typeof(config.after)=="function"){
				config.after();
			}
			p.button({
			    name: '保存',
			    disabled: true,	
			    focus:true
			},{
			    name: '取消'
			});
			var isurl = false;
			if(typeof(config.content)=="function"){
				var c = config.content();
				if(typeof(c)=="string"&&c.indexOf("url:")>=0){
					isurl = true;
				}
			}else if(typeof(config.content)=="string"){
				if(config.content.indexOf("url:")>=0){
					isurl = true;
				}
			}
			if(isurl==false){
				p.button({
				    name: '保存',
				    disabled: false,
				    callback:function(){
				    	if(config&&config.validateBefore){
				    		return config.validateBefore();
				    	}
				    	if(config&&config.validate){
				    		if(config.validate()==false)
				    			return false;
				    	}else{
				    		if(config&&config.form){
				    			var form = $(document).find(config.form);
					    		if(form.valid()==false)
					    			return false;
				    			/*console.info(p.iframe.contentWindow.ifm_validate.form());
				    			return p.iframe.contentWindow.ifm_validate.form();*/
				    		}
				    	}
				    	if(config&&config.submitSuccess){
				    		var data = null;
				    		if(config&&config.form){
				    			var form = $(config.form);
				    			data = FormUtils.getSubmitData(form);
				    		}else{
				    			data = FormUtils.getSubmitData($(document));
				    		}
				    		config.submitSuccess(data);
				    	}
				    	p.close();
				    }
				});
			}
			$(p.iframe).load(function(){
				p.button({
				    name: '保存',
				    disabled: false,
				    callback:function(){
				    	if(config&&config.validateBefore){
				    		config.validateBefore();
				    	}
				    	if(config&&config.validate){
				    		if(config.validate()==false)
				    			return false;
				    	}else{
				    		if(config&&config.form){
				    			
				    			/*var form = $(p.content.document).find(config.form);
				    			console.info(form.valid());
					    		if(form.valid() == false && !p.iframe.contentWindow.ifm_validate.form())
					    			return false;
					    		*/
				    			console.info(p.iframe.contentWindow.ifm_validate.form());
				    			if(!p.iframe.contentWindow.ifm_validate.form()){
				    				return false;
				    			}
				    		}
				    	}
						this.button({
			                name: '保存',
			                disabled: true
			            });
						var params = null;
						if(config&&config.submitData){
							if(typeof(config.submitData)=="function")
								params = config.submitData();
							else
								params = config.submitData;
						}else{
							if(config&&config.form){
				    			var form = $(p.content.document).find(config.form);
				    			params = FormUtils.getSubmitData(form);
				    		}else{
				    			params = FormUtils.getSubmitData($(p.content.document));
				    		}
							
						}
						if(config&&config.submitBefore){
							config.submitBefore();
						}
						var submitTo = config&&config.submitTo?config.submitTo:p.content.location.href;
						var submitContentType = config&&config.submitContentType?config.submitContentType:"application/x-www-form-urlencoded";
						var submitType = config&&config.submitType?config.submitType:"ajax";
						var dialog = this;
						if(submitType==='ajax'){
							Ajax.post({
								data:params,
							    dataType: "json",  
								contentType:submitContentType, 
							    url:submitTo,
							    success:function(data){console.info(JSON.stringify(data));
							    	if(config&&config.submitSuccess){
							    		config.submitSuccess(data);
							    	}
							    	dialog.close();
							    },
							    error:function(errs) {
							    	dialog.button({
							            name: '保存',
							            disabled:false
							        });
							    	for(var i=0;i<errs.length;i++){
							    		var err = errs[i];
							    		//ValidateFromUtils.showErrorMessage(err.message,err.code);
							    	}
					            }
					        });
							return false;
						}else{
							//iframe方式提交表单
							_AjaxForIframe.post({
								success:function(data){
							    	dialog.close();
							    },
							    error:function(errs) {
							    	dialog.button({
							            name: '保存',
							            disabled:false
							        });
					            }
							});
							return false;
						}
				    }
				});
			});

}; 

/**
 * config = {
 * 	   validateBefore:function(){}
 *     validate:function(){},
 *     submitBefore:function(){}
 *     submitData:function(){}
 *     submitTo:""
 *     submitContentType:""
 * }
 */
$.fn.popupButton = function(config){   
	
	////////////////////////
	var submitType = config&&config.submitType?config&&config.submitType:'ajax';
	if(submitType==='ajax'){
		var forms = $("form");
		if(forms.length>0){
			forms.attr("onSubmit","return false;");
		}	
	}
	////////////////////////
	
	
	var api = this[0];
	
	api.button({
	    name: '保存',
	    focus:true,
	    callback: function(){
	    	
	    },
	    focus: true
	},
	{
	    name: '取消'
	});
}; 