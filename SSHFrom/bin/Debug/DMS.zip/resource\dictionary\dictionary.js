$(document).ready(function(){
	Dictionary.initLayout();
	Dictionary.initEvent();
	//initScrollbar('');
});
$(window).resize(function(){
	Dictionary.initLayout();
	//initScrollbar('update');
});
var Dictionary = {
	initLayout:function(){
		$("#main,.main").height($(window).height()-42);
	},
	updateItem:function(itemContainer,data){
		var tr = itemContainer.find("#"+data["id"]);
		var array = [];
		array[array.length] = data["name"];
		if(StringUtils.isNotEmpty(data["remark"])){
			array[array.length] = "<span style='font-size:12px;color:#ccc'> - "+data["remark"]+"</span>";
		}
		tr.children("td[name='name']").html(array.join(""));
		tr.children("td[name='code']").html(data["code"]);
		tr.children("td[name='orderNo']").html(data["orderNo"]);
		if(data["manageable"]==1)
			tr.children("td[name='manageable']").html("<span class='infoState'>可以</span>");
		else
			tr.children("td[name='manageable']").html("<span class='warnState'>不可以</span>");
		if(data["hasDisabled"]==0)
			tr.children("td[name='hasDisabled']").html("<span class='infoState'>否</span>");
		else
			tr.children("td[name='hasDisabled']").html("<span class='warnState'>是</span>");
	},
	fillItem:function(itemContainer,data){
		var array = [];
		array[array.length] = "<tr id='";
		array[array.length] = data["id"];
		array[array.length] = "'>";
		/*
		array[array.length] = "<td class='center'>";
		
		if(data["manageable"]==1){
			array[array.length] = "<input type='radio' name='dict_item' value='";
			array[array.length] = data["id"];
			array[array.length] = "'/>";
		}
		
		array[array.length] = "</td>";
		*/
		array[array.length] = "<td name='name' class='overflow'>";
		array[array.length] = data["name"];
		if(StringUtils.isNotEmpty(data["remark"])){
			array[array.length] = "<span style='font-size:12px;color:#ccc'> - "+data["remark"]+"</span>";
		}
		array[array.length] = "</td>";
		array[array.length] = "<td name='code' class='overflow center'>";
		array[array.length] = data["code"];
		array[array.length] = "</td>";
		
		array[array.length] = "<td name='orderNo' class='overflow center'>";
		array[array.length] = data["orderNo"];
		array[array.length] = "</td>";
		
		array[array.length] = "<td name='groupNo' class='overflow center'>";
		array[array.length] = data["groupNo"];
		array[array.length] = "</td>";
		
		array[array.length] = "<td name='manageable' class='center' style='display:none;'>";
		if(data["manageable"]==1)
			array[array.length] = "<span class='infoState'>可以</span>";
		else
			array[array.length] = "<span class='warnState'>不可以</span>";
		array[array.length] = "</td>";
		array[array.length] = "<td name='hasDisabled' class='center'>";
		if(data["hasDisabled"]==0)
			array[array.length] = "<span class='infoState'>否</span>";
		else
			array[array.length] = "<span class='warnState'>是</span>";
		array[array.length] = "</td>";
		
		array[array.length] = "<td name='opeat' class='overflow center'>";
		array[array.length] = "<a class=\"opt mod\"><i class=\"icon-mod\"></i>修改</a>";
		array[array.length] = "</td>";
		
		array[array.length] = "<tr>";
		var tr = $(array.join(""));
		if(data["manageable"]==1){
			tr.click(function(){
				if(!$(this).hasClass("focus")){
					$(this).addClass("focus");
					$(this).find("input[type='radio']").prop("checked",true);
				}else{
					$(this).removeClass("focus");
					$(this).find("input[type='radio']").prop("checked",false);
				}
			});
		}
		itemContainer.append(tr);
	},
	fillDic:function(itemContainer,data){
		var tr = '<tr id="'+data.id+'" manageable="'+data.manageable+'">';
			tr += '<td class="overflow">';
			tr += data.name;
			tr += '</td><td class="overflow left">';
			tr += data.code;
			tr += '</td><td class="center" style="display:none;">';
			if(data.manageable == 1){
				tr += '<span class="infoState">';
				tr += '是';
			} else {
				tr += '<span class="warnState">';
				tr += '否';
			}
			tr += '</span></td></tr>';
			itemContainer.append($(tr));
	},
	initEvent:function(){
		$(document).on("click",".dictionarys tr",function(){
			var tr = $(this);
			var dictionaryId = tr.attr("id");
			Ajax.get({
				url : "getItems.do",
				data : {dictionaryId:dictionaryId},
				success:function(rtn){
					var itemContainer = $(".items");
					
					$("#needWarn").hide();
					$(".dictionarys tr").removeClass("focus");
					tr.addClass("focus");
					var manageable = tr.attr("manageable");
					if(manageable=="0"){
						$(".opts").hide();
					}else{
						$(".opts").show();
					}
					
					itemContainer.empty();
					for(var i in rtn){
						if(manageable=="0")
							rtn[i]["manageable"] = "0";
						Dictionary.fillItem(itemContainer,rtn[i]);
						addUpdateItemEvent();
					}
				},
				error:function(rtn){
					alert(rtn);
				}
			});
		});
		
		$(".add").click(function(){
			
			$(this).popup({
				title:'新增字典项',
				width:450,
				height:280,
				max:false,
				min:false, 
				fixed: true,
				form:'#ifm',
				content: 'url:editItem.do?dictionaryId=' + $(".dictionarys tr.focus").attr("id"),
				submitSuccess:function(data){
					var itemContainer = $(".items");
					Dictionary.fillItem(itemContainer,data);
					addUpdateItemEvent();
				}
			});
		});
		
		function addUpdateItemEvent(){
			
			$(".mod").unbind().click(function(){
				
				var itemId = $(this).parent().parent().attr("id");
				
				$(this).popup({
					title:'修改字典项',
					width:450,
					height:280,
					max:false,
					min:false, 
					fixed: true,
					form:'#ifm',
					before:function(){
						/*
						var checks = $(".items tr.focus");
						if(checks.length<1){
							$.dialog.alert("请选择要修改的字典项");
							return false;
						}*/
						return true;
					},
					content: 'url:editItem.do?itemId='+itemId,
					//validate:function(){return that.validate();},
					//submitData:function(){
					//		return FormUtils.getSubmitData($("#ifm"));
					//},
					submitSuccess:function(data){
						var itemContainer = $(".items");
						Dictionary.updateItem(itemContainer,data);
					}
				});
			});
			
		}

		/*
		
		
		$(".del").click(function(){
			var checks = $(".items tr.focus");
			if(checks.length<1){
				$.dialog.alert("请选择要删除的字典项");
				return false;
			}
			var ids = [];
			$.each(checks,function(i,n){
				ids[ids.length] = $(n).attr("id");
			})
			var dialog = null;
			$.dialog.confirm("你要删除选择的<font style='font-size:16px;color:red;'>"
					+ checks.length + "</font>个字典项吗?", function(){
				dialog =  $.dialog({title:'删除提示',content:'后台正在删除数据,请稍候...',min:false,max:false,lock:true,esc:false,close:false});
				Ajax.post({
					data:{ids:ids.join(",")},
					url:"delItems.do",
					success:function(){
						dialog.close();
						$(".items tr.focus").remove();
					}
				});
			}, function(){
				
			});
		});*/
		
		$(".addDic").click(function(){
			$(this).popup({
				title:'新增字典类别',
				width:450,
				height:240,
				max:false,
				min:false, 
				fixed: true,
				form:'#ifm',
				content: 'url:editDic.do',
				submitSuccess:function(data){
					var itemContainer = $(".dictionarys");
					Dictionary.fillDic(itemContainer,data);
				}
			});
		});
		
		
	}
}
/*
function initScrollbar(param){
	$("#listContainer").perfectScrollbar(param); 
}*/