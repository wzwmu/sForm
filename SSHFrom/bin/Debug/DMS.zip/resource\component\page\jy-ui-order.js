var Order = function(){};
Order = {
	_init:function(){
	
	},
	validate:function(){
		return true;
	},
	getFormData:function(){
		return null;
	},
	options:{
		focusEle:null,
		bindForm:"#frm"
	},
	saveOptions:{
		click:function(e){
			this.submit();
		},
		submitCallback:function(rtn){
			var next = $("<div class='ui-next' id='global_loading'><div class='t'>数据保存成功<div><div class='remark'>您可以继续选择下面的操作:<div></div>");
			var ul = $("<ul></ul>");
			var next_edit = $("<li>继续编辑该数据</li>");
			next_edit.click(function(){
				$("#id").val(rtn.id);
				next.remove();
			});
			var next_new = $("<li>新增数据</li>");
			next_new.click(function(){
				window.location.href="input.do";
			});
			var next_list = $("<li>返回列表数据</li>");
			next_list.click(function(){
				window.location.href="index.do";
			});
			
			next.append(ul.append(next_edit).append(next_new).append(next_list));
			$(document.body).append(next);
			next.css({left:($(document.body).width()-next.width())/2,top:($(document.body).height()-next.height())/2});
		},
	    bind:'#saveBtn'
	},
	comboOptions:[
	],
	gridOptions:{
		datatype: "local",
		dataSource:null,
		multiselect: false,
		multiboxonly:false,
		initRows:6,
		autoResize:true,
		autoResizeHeight:false,
		colOpts:[],
		colModel:[],
		bind:null
	},
	init:function(){
		this._initGlobal();
		this._initGrid(this.gridOptions.bind);
		this._initCombos();
		this._initSaveButton(this.saveOptions.bind);
		if(this._init)
			this._init();
		this._initEvent();
	},
	_initGlobal:function(){
		if(this.options.focusEle!=null)
			$(this.options.focusEle).focus();
	},
	_initCombos:function(){
		if(!ArrayUtils.isArray(this.comboOptions)||this.comboOptions.length==0)
			return;
		for(var i=0;i<this.comboOptions.length;i++){
			var opt = this.comboOptions[i];
			this._initCombo(opt);
		}
	},
	_initCombo:function(opt){
		if(StringUtils.isEmpty(opt.bind)||StringUtils.isEmpty(opt.type))
			return;
		if(opt.type=="datepicker"){
			$(opt.bind).datepicker();
			return;
		}
		var url = "";
		if(typeof(opt.type)=="function")
			opt.type = opt.type();
		if(opt.type=="partner")
			url = "../partner/find.do";
		if(opt.type=="repository")
			url = "../repository/find.do";
		if(opt.type=="goodsType")
			url = "../goodsType/findGoodsType.do";
		else if(opt.type=="customer")
			url = "../customer/find.do";
		else if(opt.type=="balanceaccount")
			url = "../balanceAccount/find.do";
		$(opt.bind).comboList({
			dataType:'json', 
			url:url,
			validate:true,
			jsonReader: {
				/*
				 * 集合的名称
				 */
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		});
	},
	_initGrid:function(bind){
		if(StringUtils.isEmpty(bind))
			return;
		this.grid = $(bind);
		var colModel = this.gridOptions.colModel;
		var that = this;
		for(var i=0;i<colModel.length;i++){
			if("operation"!=colModel[i].name)
				continue;
			colModel[i].formatter=function(val, opt, row){
				var opts = [];
				opts[opts.length] = "<div class='operating' data-id='";
				opts[opts.length] = opt.rowId;
				opts[opts.length] = "'>";
				for(var i=0;i<that.gridOptions.colOpts.length;i++){
					var opt = that.gridOptions.colOpts[i];
					opts[opts.length] = "<span class='ui-icon "+opt.cls+"' title='"+opt.title+"'></span>";
				}
			    opts[opts.length] = "</div>";
			    return opts.join("");
			};
		}
		
		if(this.gridOptions.colOpts==null||this.gridOptions.colOpts.length==0){
			this.gridOptions.colOpts = 
			[
			    {
			        type:'add',
			        name:'新增',
			        title:'新增行',
			        cls:'ui-icon-plus',
			        click:function(e,rowId,rowData){
				    	e.preventDefault();
						this._operationAdd(rowId);
			        }
			    },
			    {
			        type:'del',
			        name:'删除',
			        title:'删除行',
			        cls:'ui-icon-trash',
			        click:function(e,rowId,rowData){
				    	e.preventDefault();
				    	this._operationDel(rowId);
			        }
			    }
			];
		}
		this.grid.editgrid(this.gridOptions);
		for(var i=0;i<this.gridOptions.colOpts.length;i++){
			var opt = this.gridOptions.colOpts[i];
			var cls = opt.cls&&opt.cls.indexOf(".")<0?'.'+opt.cls:opt.cls;
			this.grid.on('click', cls, function(e){
				var id = $(this).parent().data('id');
				var data = that.grid.getRowData(id);
				var _opt = that.gridOptions.colOpts[$(this).index()];
				_opt.click.apply(that,[e,id,data]);
			});
		}
	},
	_initSaveButton:function(bind){
		if(StringUtils.isEmpty(bind))
			return;
		var that = this;
		$(bind).on({
			click:function(e){
				that.saveOptions.click.apply(that,[e]);
			}
		});
	},
	_initEvent:function(){
		var that = this;
		$(document.body).on('click',function(event){
			var target =event.srcElement ? event.srcElement :event.target;
			if($(target).hasClass("edit-cell"))
				return;
			that._cellBlur();
		});
	},
	_cellBlur:function(){
		var iRow = this.grid.editgrid('getSelRow');
		var iCol = this.grid.editgrid('getSelCell');
		if(iRow!=null&&iCol!=null){
			this.grid.editCell(iRow, iCol, false);
			this.grid.editgrid('clearSelRow');
			this.grid.editgrid('clearSelCell');
		}
	},
	_operationDel:function(rowId){
		this.grid.jqGrid("delRowData",rowId,{reloadAfterSubmit:false});
	},
	_operationAdd:function(rowId){
		var ids = this.grid.jqGrid('getDataIDs');  
	    var newrowId = (ids.length ==0 ? 1: Math.max.apply(Math,ids)+1);  
		/**
		 * 根据源代码查看addRowData(newrowid,data,pos,src)
		 * newrowid是新行id，需要重新指定不能与原有数据行id相同
		 * {}新行数据
		 * pos:first,last,before,after,其中before,after为相对位置
		 * src:相对位置rowid
		 */
	    this.grid.jqGrid("addRowData",newrowId,{},'after',rowId);;  
	},
	_getEffectiveRowData:function(condition){
		var ids = this.grid.jqGrid('getDataIDs');
		var rowData = new Array();
		for(var i = 0, len = ids.length; i < len; i++){
			var row = this.grid.jqGrid('getRowData',ids[i]);
			if(StringUtils.isEmpty(condition))
				rowData[rowData.length] = row;
			else if(StringUtils.isNotEmpty(row[condition]))
				rowData[rowData.length] = row;
		};
		return rowData;
	},
	submit:function(){
		if(StringUtils.isEmpty(this.options.bindForm))
			return;
		this._cellBlur();
		if(this.validate && this.validate()==false)
			return false;	
		var that = this;
		$.dialog.confirm('单据是否编辑完成,现在提交吗？', function(){
			that._submit();
		}, function(){
			
		});
	},
	_submit:function(){
		var data = FormUtils.getSubmitData(this.options.bindForm);
		if(this.grid){
			data.items = this.grid.jqGrid("getRowData");
		}
		var that = this;
		Ajax.post({
			type: "post",
			url: "input.do",
			data: JSON.stringify(data), 
			dataType: "json",  
			contentType:"application/json;charset=UTF-8", 
			success: function(rtn){
				//Confirm.tips({type:1,message:'数据保存成功'});
				if(that.saveOptions.submitCallback)
					that.saveOptions.submitCallback.apply(that,[rtn]);
			},   
			error: function(errors){
				var code = errors[0].code;
				var msg = errors[0].message;
				Confirm.tips({type:2,message:msg});
				$("input[name='"+code+"']").focus().addClass("error");
			}
		});
	},
	showMessage:function(msg){
		var errorContainer = $("#errors div");
		errorContainer.append("<label for='' class='error'>"+msg+"</label>");
		errorContainer.parent().show();
	},
	clearMessage:function(forId){
		if(StringUtils.isEmpty(forId)){
			$("#errors div").empty().hide();
		}else{
			var errorContainer = $("#errors div");
			errorContainer.children("label[for='"+forId+"']").remove();
			if(errorContainer.children("label").size()<1)
				errorContainer.parent().hide();
		}
	}
};