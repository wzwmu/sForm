var EditBase = { 
	init:function(){  
		this.initButton();
		if(this._init)
			this._init();
	},
	initButton:function(){
		var api = frameElement.api;
		var that = this;
		api.button({
		    name: '保存',
		    focus:true,
		    callback: function(){
				if(that.validate()==false)
					return false;
				this.button({
	                name: '保存',
	                disabled: true
	            });
				var params = FormUtils.getSubmitData("#frm");
				var url = window.location.href;
				var dialog = this;
				Ajax.post({
					data:JSON.stringify(params),
				    dataType: "json",  
					contentType:"application/json;charset=UTF-8", 
				    url:url,
				    success:function(data){
				    	if($("#id").val()!=""){
				    		var listgrid = api.opener.Index.grid;
				    		var rowid = listgrid.grid("getGridParam","selrow");
				    		listgrid.grid("setRowData",rowid,data);
				    	}else{
				    		var listgrid = api.opener.Index.grid;
				    		listgrid.grid("addRowData",data);
				    	}
				    	dialog.close();
				    },
				    error:function(err) {
				    	dialog.button({
				            name: '保存',
				            disabled:false
				        });
		            }
		        });
				return false;
		    },
		    focus: true
		},
		{
		    name: '取消'
		});
	}
}; 