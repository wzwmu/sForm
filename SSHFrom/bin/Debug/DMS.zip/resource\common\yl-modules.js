$.fn.found = function(config){   
	var module = $(this);
	var form = module.find("form");
	//if(form.length>0){
	//	form.attr("onSubmit","return false;");
	//}
	/*
	var defaultEles = module.find(".default");
	$.each(defaultEles,function(i,n){
		var ele = $(n);
		if(StringUtils.isNotEmpty(ele.val())){
			ele.attr("title",ele.val());
			ele.focus(function(){
				if($.trim($(this).val())==$(this).attr("title"))
					$(this).val("");
			}).blur(function(){
				if($.trim($(this).val())=="")
					$(this).val($(this).attr("title"));
			});
		}
	});*/
	/*
	var submitBtn = module.find("input[type='submit']");
	submitBtn.on({
		click:function(e){
			if(config&&config.submit)
				config.submit.apply(module,[e]);
			else
				clearEles.focus();
		}
	});
	*/
	var more = module.find(".more");
	var soh = $("<input type='hidden' class='___soh' name='___soh' value='h'/>");
	form.append(soh);
	more.click(function(){
		if($(this).hasClass("show")){
			$(this).removeClass("show");
			$(this).html("点击展开高级搜索");
			soh.val("h");
		}else{
			$(this).addClass("show");
			$(this).html("点击收起高级搜索");
			soh.val("s");
		}
		module.find(".complex").toggle();
	});
}; 
$.fn.opt = function(config){   
	var module = $(this);
	var url = config&&config.url?config.url:'edit.do';
	var title = config&&config.title?config.title:'编辑';
	var target =  config&&config.target?config.target:'self';
	if(target==="window"){
		module.on({
			click:function(e){
				window.open(url);
			}
		});
	}else if(target==="popup"){
		var popupOpt = { 
			    id: '1', 
			    title: title, 
			    width: '700px', 
			    height: 350, 
			    lock: true, 
			    content:'url:'+url
		};
		popupOpt = $.extend(popupOpt,config.popupOpt);
		module.on({
			click:function(e){
				$.dialog(popupOpt);
			}
		});
	}else{
		module.on({
			click:function(e){
				window.location.href = url;
			}
		});
	}
	
}; 

/**
 * config = {
 * 	   validateBefore:function(){}
 *     validate:function(){},
 *     submitBefore:function(){}
 *     submitData:function(){}
 *     submitTo:""
 *     submitContentType:""
 * }
 */
$.fn.popupButton = function(config){   
	
	////////////////////////
	var submitType = config&&config.submitType?config&&config.submitType:'ajax';
	if(submitType==='ajax'){
		var forms = $("form");
		if(forms.length>0){
			forms.attr("onSubmit","return false;");
		}	
	}
	////////////////////////
	
	
	var api = this[0];
	
	api.button({
	    name: '保存',
	    focus:true,
	    callback: function(){
	    	if(config&&config.validateBefore){
	    		config.validateBefore();
	    	}
	    	if(config&&config.validate){
	    		if(config.validate()==false)
	    			return false;
	    	}
			this.button({
                name: '保存',
                disabled: true
            });
			var params = null;
			if(config&&config.submitData){
				if(typeof(config.submitData)=="function")
					params = config.submitData();
				else
					params = config.submitData;
			}else{
				params = {};
			}
			if(config&&config.submitBefore){
				config.submitBefore();
			}
			
			var submitTo = config&&config.submitTo?config.submitTo:window.location.href;
			var submitContentType = config&&config.submitContentType?config.submitContentType:"application/x-www-form-urlencoded";
			
			var dialog = this;
			if(submitType==='ajax'){
				Ajax.post({
					data:params,
				    dataType: "json",  
					contentType:submitContentType, 
				    url:submitTo,
				    success:function(data){
				    	if($("#id").val()!=""){
				    		var listgrid = api.opener.Index.grid;
				    		var rowid = listgrid.grid("getGridParam","selrow");
				    		listgrid.grid("setRowData",rowid,data);
				    	}else{
				    		var listgrid = api.opener.Index.grid;
				    		listgrid.grid("addRowData",data);
				    	}
				    	dialog.close();
				    },
				    error:function(errs) {
				    	dialog.button({
				            name: '保存',
				            disabled:false
				        });
				    	for(var i=0;i<errs.length;i++){
				    		var err = errs[i];
				    		ValidateFromUtils.showErrorMessage(err.message,err.code);
				    	}
		            }
		        });
				return false;
			}else{
				//iframe方式提交表单
				_AjaxForIframe.post({
					success:function(data){
						if($("#id").val()!=""){
				    		var listgrid = api.opener.Index.grid;
				    		var rowid = listgrid.grid("getGridParam","selrow");
				    		listgrid.grid("setRowData",rowid,data);
				    	}else{
				    		var listgrid = api.opener.Index.grid;
				    		listgrid.grid("addRowData",data);
				    	}
				    	dialog.close();
				    },
				    error:function(errs) {
				    	dialog.button({
				            name: '保存',
				            disabled:false
				        });
				    	for(var i=0;i<errs.length;i++){
				    		var err = errs[i];
				    		ValidateFromUtils.showErrorMessage(err.message,err.code);
				    	}
		            }
				});
				return false;
			}
	    },
	    focus: true
	},
	{
	    name: '取消'
	});
}; 


$.fn.importExcel = function(config){   
	var module = $(this);
	module.click(function(){
		var url = config.url;
		var defaultTitleLine = config.defaultTitleLine;
		var defaultDataStartLine = config.defaultDataStartLine;
		var templateUrl = config.templateUrl;
		var title = config.title;
		if(url.indexOf("?")>0){
			url = url + "&defaultTitleLine="+defaultTitleLine;
			url = url + "&defaultDataStartLine="+defaultDataStartLine;
			url = url + "&templateUrl="+templateUrl;
		}else{
			url = url + "?defaultTitleLine="+defaultTitleLine;
			url = url + "&defaultDataStartLine="+defaultDataStartLine;
			url = url + "&templateUrl="+templateUrl;
		}
	    var dialog = $.dialog({
	        id: 'importexcelId',
	        title: title,
	        width: 600,
	        height: 330,
	        lock: true,
	        content: 'url:' + url
	    });
	});
};