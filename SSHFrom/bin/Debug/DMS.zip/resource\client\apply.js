$(document).ready(function(){
	//初始化数据
	if(addresses!=null || addresses!=""){
		initAddressData(addresses);
	}
	if(addresses!=null || addresses!=""){
		initContactData(contacts);
	}
	//选择经销商，带出数据
	$("#partners").partners({
		onChange:function(){
			var data = $("#partners").partners("getDataByVal",$("#partners").val());
			var id = data.id;
			
			Ajax.post({
				url: "AJAXPartner.do?id="+id,
				data: '',
				contentType:"application/json;charset=utf-8",
				success: function(data){
					var partner = eval("(" + data + ")");
//					alert(JSON.stringify(partner));
					if(partner != null){
						$("#applyerId").val(id);
						
						initEmptyPartnerShop();
						initPartnerShop(partner);
					   
						initEmptyCustomerData();
						initCustomerData(partner);
						if(partner[0] != null){
							initAddressData(partner[0].addresses);
							initContactData(partner[0].contacts);
						}else{
							initAddressData("");
							initContactData("");
						}
					}
				}
			});
		}
	});
	
	$(".submit").click(function(){
		$("#addressGridM").editgrid("blur");
		$("#addressGridError").html("");
		if(validate()==false || validateGrid()==false){
			return;
		}
		var data = FormUtils.getSubmitData($(document));

		data.addresses = $("#addressGridM").editgrid("getEffectiveRowData","addressTypeCode");
		
		var dlg = null;
		Ajax.post({
			url: "apply.do",
			data: data,
			contentType:"application/json;charset=utf-8",
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success: function(rtn){
				var	title = "<div class='title'>客户添加成功,您可以继续选择下面的操作：</div>";
				var ctn = title +
						 "<div class='row'><a href=\'apply.do\'>添加新的客户</a></div>" +
						 "<div class='row'><a href=\'applys.do\'>返回客户列表</a> （<i>5秒后自动选择</i>）</div>";
				ResultUtils.showSuccess({
					dialog:dlg,
					width:400,
					height:150,
					timer:{
						second:5,
						callback:function(){ 
							window.location.href='applys.do';
						}
					},
					content:ctn
				});
			},   
			error: function(errors){
				var msg = errors[0].message;
				var ctn = "<div class='title'>客户添加失败,具体原因如下：</div>"+
				 "<div class='row'>"+msg+"</div>";
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
			}
		});
		
	});
});

//TODO
function initAddressData(addresses) {
	$("#addressGridM").editgrid('delRows');
	if (addresses != null) {
		for ( var i = 0; i < addresses.length; i++) {
			$("#addressGridM").editgrid("addRowData", addresses[i]);
		}
		//没有数据添加一行空表格
		if (addresses.length == 0) {
			$("#addressGridM").editgrid("addRowData", "[]");
		}
	}
}

function initContactData(contacts){
	$("#contactGridM").editgrid('delRows');
	if(contacts != null){
		for(var i=0;i<contacts.length;i++){
			$("#contactGridM").editgrid("addRowData",contacts[i]);
		}
	}
}

function initEmptyPartnerShop(){
	$("#address").val("");
	$("#dealerName").val("");
	$("#shortName").val("");
	$("#no").val("");

	$("#taxNo").val("");
	$("#taxRegistNo").val("");

	$("#countryCodes").val("");
	$("#countryName").val("");
	$("#isReportName").val("");
	$("#isReportid").val("");

	$("#orgTypeName").val("");
	$("#orgTypeCodes").val("");
	
	$("#phone").val("");
	$("#provinceCode").val("");
	$("#provinceName").val("");
	$("#cityCode").val("");
	$("#countyCode").val("");

	$("#fax").val("");
}

function initPartnerShop(partner){
//	alert(JSON.stringify(partner[1]));
	if(partner[1] != null){
		$("#address").val(partner[1].address);
		$("#dealerName").val(partner[1].name);
		$("#shortName").val(partner[1].shortName);
		$("#no").val(partner[1].no);

		$("#taxNo").val(partner[1].taxNo);
		$("#taxRegistNo").val(partner[1].taxRegistNo);

		$("#countryCodes").val(partner[1].countryCode);
		$("#countryName").val(partner[1].countryName);
		$("#isReportName").val(partner[1].isReportName);
		$("#isReport").val(partner[1].isReport);

		$("#orgTypeName").val(partner[1].orgTypeName);
		$("#orgTypeCodes").val(partner[1].orgTypeCode);
		
		$("#phone").val(partner[1].phone);
		$("#provinceCode").val(partner[1].provinceCode);
		$("#provinceName").val(partner[1].provinceName);
		$("#cityCode").val(partner[1].cityName);
		$("#countyCode").val(partner[1].countyName);

		$("#fax").val(partner[1].fax);
		
		if(partner[1].orgtype == "Store"){
			$("#orgTypeName").val("单体门店");
//			$("#select").css("display","none");
//			$("#input").css("display","block");
		}else{
			$("#orgTypeName").val("经销商");
//			$("#input").css("display","none");
//			$("#select").css("display","block");
		}
	}
}

function initCustomerData(partner) {
	
//	alert(partner[0].bigAreaCode);
//	alert(partner[0].bigAreaName);
	
	
	$("#saleChannelTypeCode_combo").val("");
	$("#saleChannelTypeCode").find("option").val("");
	
	$("#bigAreaCode_combo").val("");
	$("#bigAreaCode").find("option").val("");
	
	$("#areaCode_combo").val("");
	$("#areaCode").find("option").val("");
	
	$("#bigAreaId_combo").val("");
	$("#bigAreaId").find("option").val("");
	
	$("#areaId_combo").val("");
	$("#areaId").find("option").val("");
	
	$("#marketManagerId").val(partner[0].marketManagerName);

	$("#saleChannelTypeCode_combo").val(partner[0].saleChannelTypeName);
	$("#saleChannelTypeCode").find("option").val(partner[0].saleChannelTypeCode);
	
	$("#partnerLevelCode_combo").val(partner[0].partnerLevelName);
	$("#partnerLevelCode").find("option").val(partner[0].partnerLevelCode);

	if(partner[0].purchaseSaleCode == null || partner[0].purchaseSaleCode ==""){
		$("#purchaseSaleCode_combo").val("购销");
		$("#purchaseSaleCode").find("option").val("GX");
	}else{
		$("#purchaseSaleCode_combo").val(partner[0].purchaseSaleName);
		$("#purchaseSaleCode").find("option").val(partner[0].purchaseSaleCode);
	}
	

	if(partner[0].creditLevelCode == null || partner[0].creditLevelCode == ""){
		$("#creditLevelCode_combo").val("普通");
		$("#creditLevelCode").find("option").val("NORMAL");
	}else{
		$("#creditLevelCode_combo").val(partner[0].creditLevelName);
		$("#creditLevelCode").find("option").val(partner[0].creditLevelCode);
	}
	
	if(partner[0].isCreditManaged == null || partner[0].isCreditManaged == ""){
		$("#isCreditManaged_combo").val("否");
		$("#isCreditManaged").find("option").val("N");
	}else{
		$("#isCreditManaged_combo").val(partner[0].isCreditManagedName);
		$("#isCreditManaged").find("option").val(partner[0].isCreditManaged);
	}
	
	if(partner[0].settlementModeCode == null || partner[0].settlementModeCode == ""){
		$("#settlementModeCode_combo").val("现款");
		$("#settlementModeCode").find("option").val("XK");
	}else{
		$("#settlementModeCode_combo").val(partner[0].settlementModeName);
		$("#settlementModeCode").find("option").val(partner[0].settlementModeCode);
	}
	
	if(partner[0].currencyCode == null || partner[0].currencyCode == ""){
		$("#currencyCode_combo").val("CNY");
		$("#currencyCode").find("option").val("CNY");
	}else{
		$("#currencyCode_combo").val(partner[0].currencyCode);
		$("#currencyCode").find("option").val(partner[0].currencyCode);
	}
	

	$("#startDt").val(partner[0].startdate);
	$("#endDt").val(partner[0].enddate);
	if(partner[0].saleTax == null || partner[0].saleTax == ""){
		$("#saleTax_combo").val("VAT17");
		$("#saleTax").find("option").val("17");
	}else{
		$("#saleTax_combo").val(partner[0].saleTaxName);
		$("#saleTax").find("option").val(partner[0].saleTax);
	}
	

	if(partner[0].orderTypeCode == null || partner[0].orderTypeCode == ""){
		$("#orderTypeCode_combo").val("普通订单");
		$("#orderTypeCode").find("option").val("NORMAL_ORDER");
	}else{
		$("#orderTypeCode_combo").val(partner[0].orderTypeName);
		$("#orderTypeCode").find("option").val(partner[0].orderTypeCode);
	}
	
	if(partner[0].rtnOrderTypeCode == null || partner[0].rtnOrderTypeCode == ""){
		$("#rtnOrderTypeCode_combo").val("普通退货");
		$("#rtnOrderTypeCode").find("option").val("NORMAL_RETURN");
	}else{
		$("#rtnOrderTypeCode_combo").val(partner[0].rtnOrderTypeName);
		$("#rtnOrderTypeCode").find("option").val(partner[0].rtnOrderTypeCode);
	}
	
	if(partner[0].isStockReceived == null || partner[0].isStockReceived == ""){
		$("#isStockReceived_combo").val("否");
		$("#isStockReceived").find("option").val("N");
	}else{
		$("#isStockReceived_combo").val(partner[0].isStockReceivedName);
		$("#isStockReceived").find("option").val(partner[0].isStockReceived);
	}
	
	if(partner[0].deliveryLevelCode == null || partner[0].deliveryLevelCode == ""){
		$("#deliveryLevelCode_combo").val("中");
		$("#deliveryLevelCode").find("option").val("MIDDLE");
	}else{
		$("#deliveryLevelCode_combo").val(partner[0].deliveryLevelName);
		$("#deliveryLevelCode").find("option").val(partner[0].deliveryLevelCode);
	}
	
	if(partner[0].isOrderFreezed == null || partner[0].isOrderFreezed == ""){
		$("#isOrderFreezed_combo").val("否");
		$("#isOrderFreezed").find("option").val("N");
	}else{
		$("#isOrderFreezed_combo").val(partner[0].isOrderFreezedName);
		$("#isOrderFreezed").find("option").val(partner[0].isOrderFreezed);
	}
	
	if(partner[0].isDeliveryFreezed == null || partner[0].isDeliveryFreezed == ""){
		$("#isDeliveryFreezed_combo").val("否");
		$("#isDeliveryFreezed").find("option").val("N");
	}else{
		$("#isDeliveryFreezed_combo").val(partner[0].isDeliveryFreezedName);
		$("#isDeliveryFreezed").find("option").val(partner[0].isDeliveryFreezed);
	}
	
	if(partner[0].invoiceTypeCode == null || partner[0].invoiceTypeCode == ""){
		$("#invoiceTypeCode_combo").val("增值税发票");
		$("#invoiceTypeCode").find("option").val("TAX_INVOICE");
	}else{
		$("#invoiceTypeCode_combo").val(partner[0].invoiceTypeName);
		$("#invoiceTypeCode").find("option").val(partner[0].invoiceTypeCode);
	}
	
	if(partner[0].isInvoiceFreezed == null || partner[0].isInvoiceFreezed == ""){
		$("#isInvoiceFreezed_combo").val("否");
		$("#isInvoiceFreezed").find("option").val("N");
	}else{
		$("#isInvoiceFreezed_combo").val(partner[0].isInvoiceFreezedName);
		$("#isInvoiceFreezed").find("option").val(partner[0].isInvoiceFreezed);
	}
	
	if(partner[0].isStockShow == null || partner[0].isStockShow == ""){
		$("#isStockShow_combo").val("否");
		$("#isStockShow").find("option").val("N");
	}else{
		$("#isStockShow_combo").val(partner[0].isStockShowName);
		$("#isStockShow").find("option").val(partner[0].isStockShow);
	}
	
	$("#transportOnlineCode").val(partner[0].transportOnlineCode);
	
	if(partner[0].deliveryCode == null || partner[0].deliveryCode == ""){
		$("#deliveryCode_combo").val("货运");
		$("#deliveryCode").find("option").val("FREIGHT");
	}else{
		$("#deliveryCode_combo").val(partner[0].deliveryCodeName);
		$("#deliveryCode").find("option").val(partner[0].deliveryCode);
	}
	

	$("#additionalRatio").val(partner[0].additionalRatio);

	if(partner[0].isAdditionalCal == null || partner[0].isAdditionalCal == ""){
		$("#isAdditionalCal_combo").val("否");
		$("#isAdditionalCal").find("option").val("N");
	}else{
		$("#isAdditionalCal_combo").val(partner[0].isAdditionalCalName);
		$("#isAdditionalCal").find("option").val(partner[0].isAdditionalCal);
	}
	
	if(partner[0].stockReceiveTypeName == null || partner[0].stockReceiveTypeName ==""){
		$("#stockReceiveTypeCode_combo").val("自动");
		$("#stockReceiveTypeCode").find("option").val("AUTO");
	}else{
		$("#stockReceiveTypeCode_combo").val(partner[0].stockReceiveTypeName);
		$("#stockReceiveTypeCode").find("option").val(partner[0].stockReceiveTypeName);
	}
	
	if(partner[0].giftCtrlMode == null || partner[0].giftCtrlMode == ""){
		$("#giftCtrlMode_combo").val("严格控制");
		$("#giftCtrlMode").find("option").val("0");
	}else{
		$("#giftCtrlMode_combo").val(partner[0].giftCtrlModeName);
		$("#giftCtrlMode").find("option").val(partner[0].giftCtrlMode);
	}
	
	if(partner[0].tHCJGiftBalance == null || partner[0].tHCJGiftBalance == ""){
		$("#tHCJGiftBalance_combo").val("否");
		$("#tHCJGiftBalance").find("option").val("N");
	}else{
		$("#tHCJGiftBalance_combo").val(partner[0].tHCJGiftBalanceName);
		$("#tHCJGiftBalance").find("option").val(partner[0].tHCJGiftBalance);
	}
	
	if(partner[0].nothingCanOrderFlg == null || partner[0].nothingCanOrderFlg == ""){
		$("#nothingCanOrderFlg_combo").val("否");
		$("#nothingCanOrderFlg").find("option").val("N");
	}else{
		$("#nothingCanOrderFlg_combo").val(partner[0].nothingCanOrderFlgName);
		$("#nothingCanOrderFlg").find("option").val(partner[0].nothingCanOrderFlg);
	}
	
	if(partner[0].priceDecimalDigits == null || partner[0].priceDecimalDigits == ""){
		$("#priceDecimalDigits_combo").val("1");
		$("#priceDecimalDigits").find("option").val("1");
	}else{
		$("#priceDecimalDigits_combo").val(partner[0].priceDecimalDigitsName);
		$("#priceDecimalDigits").find("option").val(partner[0].priceDecimalDigits);
	}
	
	if(partner[0].packCtrlFlg == null || partner[0].packCtrlFlg == ""){
		$("#packCtrlFlg_combo").val("是");
		$("#packCtrlFlg").find("option").val("Y");
	}else{
		$("#packCtrlFlg_combo").val(partner[0].packCtrlFlgName);
		$("#packCtrlFlg").find("option").val(partner[0].packCtrlFlg);
	}
	
	if(partner[0].zxbzsFlg == null || partner[0].zxbzsFlg == ""){
		$("#zxbzsFlg_combo").val("是");
		$("#zxbzsFlg").find("option").val("Y");
	}else{
		$("#packCtrlFlg_combo").val(partner[0].packCtrlFlgName);
		$("#packCtrlFlg").find("option").val(partner[0].packCtrlFlg);
	}
	
	
	$("#relatedDelearId_combo").val(partner[0].relatedDelearName);
	$("#relatedDelearId").find("option").val(partner[0].relatedDelearId);
	
}

function initEmptyCustomerData() {
	
	$("#bigAreaManagerId").val("");
	
	$("#marketManagerId").val("");
	
	$("#saleChannelTypeCode_combo").val("");
	$("#saleChannelTypeCode").find("option").val("");
	
	$("#partnerLevelCode_combo").val("");
	$("#partnerLevelCode").find("option").val("");

	$("#purchaseSaleCode_combo").val("");
	$("#purchaseSaleCode").find("option").val("");

	$("#creditLevelCode_combo").val("");
	$("#creditLevelCode").find("option").val("");

	$("#isCreditManaged_combo").val("");
	$("#isCreditManaged").find("option").val("");

	$("#settlementModeCode_combo").val("");
	$("#settlementModeCode").find("option").val("");

	$("#currencyCode_combo").val("");
	$("#currencyCode").find("option").val("");

	$("#startDt").val("");
	$("#endDt").val("");

	$("#saleTax_combo").val("");
	$("#saleTax").find("option").val("");

	$("#orderTypeCode_combo").val("");
	$("#orderTypeCode").find("option").val("");

	$("#rtnOrderTypeCode_combo").val("");
	$("#rtnOrderTypeCode").find("option").val("");

	$("#isStockReceived_combo").val("");
	$("#isStockReceived").find("option").val("");

	$("#deliveryLevelCode_combo").val("");
	$("#deliveryLevelCode").find("option").val("");

	$("#isOrderFreezed_combo").val("");
	$("#isOrderFreezed").find("option").val("");

	$("#isDeliveryFreezed_combo").val("");
	$("#isDeliveryFreezed").find("option").val("");

	$("#invoiceTypeCode_combo").val("");
	$("#invoiceTypeCode").find("option").val("");

	$("#isInvoiceFreezed_combo").val("");
	$("#isInvoiceFreezed").find("option").val("");

	$("#isStockShow_combo").val("");
	$("#isStockShow").find("option").val("");

	$("#transportOnlineCode").val("");

	$("#deliveryCode_combo").val("");
	$("#deliveryCode").find("option").val("");

	$("#additionalRatio").val("");

	$("#isAdditionalCal_combo").val("");
	$("#isAdditionalCal").find("option").val("");

	$("#stockReceiveTypeCode_combo").val("");
	$("#stockReceiveTypeCode").find("option").val("");
	
	$("#giftCtrlMode_combo").val("");
	$("#giftCtrlMode").find("option").val("");

	$("#tHCJGiftBalance_combo").val("");
	$("#tHCJGiftBalance").find("option").val("");
	
	$("#nothingCanOrderFlg_combo").val("");
	$("#nothingCanOrderFlg").find("option").val("");
	
	$("#priceDecimalDigits_combo").val("");
	$("#priceDecimalDigits").find("option").val("");
	
	$("#packCtrlFlg_combo").val("");
	$("#packCtrlFlg").find("option").val("");
	
	$("#relatedDelearId_combo").val("");
	$("#relatedDelearId").find("option").val("");
	
}

