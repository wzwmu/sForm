$(document).ready(function(){
	if($(".m-find").length > 0){$(".m-find").found();}
	
	if($(".ui-datepicker-input").length > 0){
		$(".ui-datepicker-input").datepicker({yearRange:"1990:2099"});
		
		$('.ui-datepicker-input').datepicker({ changeYear: true }); 
		//var changeYear = $('.ui-datepicker-input').datepicker('option', 'changeYear'); 
		$('.ui-datepicker-input').datepicker('option', 'changeYear', true);

	}
	
	$(".m-edittable .title .right").click(function(){
		var me = $(this);
		var tc = me.parent().next();
		if(me.hasClass("show")){
			me.removeClass("show");
			me.html("收起");
		}else{
			me.addClass("show");
			me.html("展开");
		}
		tc.toggle();
	});
	if(___soh!==undefined&&___soh=="s"){
		$(".m-find").find(".more").click();
	}
	
	$.validator.setDefaults({
		debug: false,
		errorElement : "span",
		errorPlacement: function(error, element) { 
			if(element.parent().children(".erroricon").length>0)
				return;
			if(error.html() == ''){return;}
			var err = $("<span class='erroricon'></span>");
			err.attr("title",error.html());
			err.html("&nbsp;&nbsp;"); 
			err.appendTo(element.parent());  
		},
		success:function(element){
			var id = element.attr("for");
			var ele = $("#"+id);
			if(ele.length==0){
				ele = $("input[name='"+id+"']");
			}
			if(ele.length>0)
				ele.parent().children(".erroricon").remove();
		}
	});
	
	// 删除附件
	$(".progressWrapper").each(function(i){
		$(this).find("img").click(function(){
			
			$(this).parent().slideUp();
			
			//$(this).parent().remove();
			// 记录删除附件的Id
			var _oldId = $("#deleteId").val();
			
			if(_oldId != ""){
				_oldId = _oldId + "|" + $(this).attr("id");
			}else{
				_oldId = $(this).attr("id");
			}
			
			$("#deleteId").val(_oldId);
		})
	});
	
	
	
});

function findPage(pageno,me,formId){
	var frm = $("form:first");
	var pagenoHidden = frm.find("input[name='pageno']");
	if ( pagenoHidden.size()<1 ){
		pagenoHidden = $("<input type='hidden' name='pageno' />");
		frm.append(pagenoHidden);
	}
	pagenoHidden.val(pageno);
	frm.get(0).submit();
}

function yon(title,url){
	if(!confirm(title))
		return;
	Ajax.post({
		url: url,
		data: {},
		contentType:"application/json;charset=utf-8",
		success: function(rtn){
			$(".m-find input[type='submit']").click();
		},   
		error: function(errors){
			//alert(2);
		}
	});
}
function del(title,url){
	$.dialog.confirm("<span style='padding:0px 30px;'>"+title+"</span>",function(){
		window.location.href = url;
	});
}

function ajaxDel(title, url){
	
	$.dialog.confirm("<span style='padding:0px 30px;'>"+title+"</span>",function(){
			
			var dlg = null;
			
			Ajax.post({
				url: url,
				data: {},
				contentType:"application/json;charset=utf-8",
				submitBefore:function(){
					dlg = $.dialog({
					    id: 'id_result_nav',
					    title: "温馨提示",
					    width:400, 
					    height:30,
					    fixed: true,
					    max: false,
					    min: false,
					    close:false,
					    background: '#000', /* 背景色 */
					    opacity: 0.2,       /* 透明度 */
					    content: "<div class='m-progress title'>正在执行,请稍候......</div>",
					    lock: true,
					    esc: false,	
					    cancel: false 
					});
				},
				success: function(rtn){
				
					var ctn = "<div class='title'>已成功作废!</div>";
					
					ResultUtils.showSuccess({
						dialog:dlg,
						width:300,
						height:30,
						timer:{
							second:5,
							callback:function(){
								location.reload();
							}
						},
						content:ctn
					});
				},   
				error: function(errors){
					var msg = errors[0].message;
					var ctn = "<div class='title'>操作失败,具体原因如下：</div>"+
					 		  "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				}
			});
	});
}