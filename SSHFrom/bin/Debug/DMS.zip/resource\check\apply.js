
$(document).ready(function(){
	initSubmit();
});
/**
 * 为保存和提交按钮增加事件
 * @return
 */
function importExcel(){
	var vouchType = $('input[name="vouchType"]').filter(':checked').val();
	var url = "checkVouchImport.do";
	if(vouchType=="snBatchVouch"){
		url = "../batchCheckExcel/checkVouchImport.do";
	}
	
    var dialog = $.dialog({
        id: 'subPartnerId',
        title: "excel导入",
        width: 600,
        height: 330,
        lock: true,
        content: 'url:' + url
    });
}
function initSubmit(){
	$("#create").click(function(){
		var storageId= $("#storageId").val();
		var remark=$("#remark").val();
		var vouchType = $('input[name="vouchType"]').filter(':checked').val();
		var vouchProductType=$("#vouchProductType").val();
		
		if(storageId==""||storageId==null) {
			var ctn = "<div class='row'>请选择仓库！</div>";
			var dlg = ResultUtils.showProgress();
			ResultUtils.showError({ 
				dialog:dlg,
				width:400,
				height:150,
				buttons:[{
				    name: '关闭'
				}],
				content:ctn
			});
		}else {
			var dlg = ResultUtils.showProgress();
			//window.location.href="createVouch.do?storageId="+storageId+"&remark="+encodeURI(encodeURI(remark))+"&vouchType="+vouchType+"&vouchProductType="+vouchProductType;
			
			var params = [
			              		  {
			              			  name: "storageId", 
			              			  val: storageId
			              		  },
			              		  {
			              			  name: "remark",
			              			  val: remark
			              		  },
			              		  {
			              			  name: "vouchType", 
			              			  val: vouchType
			              		  },
			              		  {
			              			  name: "vouchProductType", 
			              			  val: vouchProductType
			              		  }
			              	  ];
			
			urlPost("createVouch.do", params);
		}
		
	});
	
	var vouchids=$('input[name="id"]').val();
	var vouchType = $('input[name="vouchType"]').filter(':checked').val();
	var importurl = "checkVouchImport.do?vouchId="+vouchids;
	var exporturl="exportExcel.do?vouchId="+vouchids;
	if(vouchType=="snBatchVouch"){
		importurl = "../batchCheckExcel/checkVouchImport.do?vouchId="+vouchids;
		exporturl="../batchCheckExcel/exportExcel.do?vouchId="+vouchids;
	}
	$("#importBtn").importExcel({
    	url : importurl,
    	templateUrl : exporturl,
    	title : "盘点excel导入",
    	defaultTitleLine : 1,
		defaultDataStartLine : 2,
		hasErrorIsPass : 1
    });
	
	$("#detail").click(function(){
		var id=$('input[name="id"]').val();
		window.location.href="scanList.do?vocuId="+id;
	});
	
	$("#exportBtn").click(function(){
		var id=$('input[name="id"]').val();
		var checkVouchType = $('input[name="vouchType"]').filter(':checked').val();
		if(checkVouchType=="snBatchVouch"){
			window.location.href="../batchCheckExcel/exportExcel.do?vouchId="+id;
		}else {
			window.location.href="exportExcel.do?vouchId="+id;
		}
  	 }); 
	
	$("#first,#second,#save,#close,#ok").click(function(){
		var vouchProductType=$("#vouchProductType").val();
		var submitType = $(this).attr("id");
		var checkVouchType = $('input[name="vouchType"]').filter(':checked').val();
		$('#CheckVouchItemGrid').editgrid('blur');
		if(validate()==false||validateGrid()==false)
			return;
		var data = FormUtils.getSubmitData($(document));
		data.submitType=submitType;
		data.checkVouchItems = $('#CheckVouchItemGrid').editgrid('getEffectiveRowData','');
		var toserver = function(){
			var dlg = null;
			Ajax.post({
				url: "check.do",
				data: data,
				contentType:"application/json;charset=utf-8",
				submitBefore:function(){
					dlg = ResultUtils.showProgress();
				},
				success: function(rtn){
					var title = "<div class='title'>已经将盘点单保存,您可以继续选择下面的操作：</div>";
					
					if(submitType=="ok"){
						title = "<div class='title'>确认完成</div>";
						title = title + "<div class='row'><a href=\'list.do?vouchProductType="+vouchProductType+"&vouchType="+checkVouchType+"&conscope=session\'>返回盘点单列表</a> </div>";
//						title = title + "<div class='row'><a href='view.do?id='"+rtn+">返回该盘点单</a> </div>";
					}
					else if(submitType=="close"){
						title = "<div class='title'>已经关闭本次盘点</div>";
						title = title + "<div class='row'><a href=\'list.do?vouchProductType="+vouchProductType+"&vouchType="+checkVouchType+"&conscope=session\'>返回盘点单列表</a> </div>";
//						title = title + "<div class='row'><a href='view.do?id='"+rtn+">返回该盘点单</a> </div>";
//						window.location.href="view.do?id="+rtn;
					}
					else if(submitType=="save"){
						title = "<div class='title'>数据已经保存，请稍后</div>";
						title = title + "<div class='row'><a href=\'list.do?vouchProductType="+vouchProductType+"&vouchType="+checkVouchType+"&conscope=session\'>返回盘点单列表</a> </div>";
//						title = title + "<div class='row'><a href='check.do?id='"+rtn+">返回该盘点单</a> </div>";
//						window.location.href="check.do?id="+rtn;
					}
					
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						content:title
					});
				},   
				error: function(errors){
					var msg = errors[0].message;
					if(msg == "操作失败，请检查您的网络链接！")
					{
						msg="当前码库尚未处理完，请5分钟后再次尝试确认盘点";
					}
					var ctn = "<div class='title'>盘点单操作失败,具体原因如下：</div>"+
					 "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				}
			});
		};
		if(submitType=="close"){
			title = "<span style='padding:0px 30px;'>确定要删除本次盘点吗?<span class='to'></span></span>";
			$.dialog.confirm(title,function(){
				toserver();
			});
		}else if(submitType=="save") {
			if(checkVouchType=='snBatchVouch'){//批次盘点保存需要校验，验批次重复产品
				var result = validate_product_same_batch();
				if(!result) {
					return false;
				}else {
					toserver();
				}
			}else {
				toserver();
			}
			
		}else if(submitType=="ok"  ){
			var result = validate_table();
			if(!result) {
				return false;
			}
			if(checkVouchType=='snBatchVouch'){//批次盘点需要校验，验批次重复产品
				var sameBatch = validate_product_same_batch();
				if(!sameBatch) {
					return false;
				}
			}
			title = "<span style='padding:0px 30px;'>确定要确认盘点吗?<span class='to'></span></span>";
			$.dialog.confirm(title,function(){
				toserver();
			});
		}else{
			toserver();
		}
	});
}