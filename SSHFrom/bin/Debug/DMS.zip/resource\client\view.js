$(document).ready(function() {

	$("#addressGridM").editgrid({
		datatype : "local",
		dataSource : addresses,
		multiselect : false,
		multiboxonly : false,
		rownumbers : false,
		footerrow : false,
		initRows : 1,
		autowidth : true,
		autoResize : false,
		autoResizeHeight : false,
		colModel : addressColsM
	});

	$("#contactGridM").editgrid({
		datatype : "local",
		dataSource : contacts,
		multiselect : false,
		multiboxonly : false,
		rownumbers : false,
		footerrow : false,
		initRows : 0,
		autowidth : true,
		autoResize : false,
		autoResizeHeight : false,
		colModel : contactColsM
	});
});

var addressColsM = [ {
	name : 'id',
	label : 'id',
	hidden : true
}, {
	name : 'addressTypeCode',
	label : '地址类型代码',
	hidden : true
}, {
	name : 'addressTypeName',
	label : '地址类型<i>*</i>',
	editable : false,
	edittype : 'addresstype',
	width : 160,
	sortable : false
}, {
	name : 'countryCode',
	label : '国家代码',
	hidden : true
}, {
	name : 'countryName',
	label : '国家',
	editable : false,
	edittype : 'country',
	width : 200,
	sortable : false,
	hidden : true
}, {
	name : 'provinceCode',
	label : '省代码',
	hidden : true
}, {
	name : 'provinceName',
	label : '省<i>*</i>',
	editable : false,
	edittype : 'province',
	width : 200,
	sortable : false
}, {
	name : 'cityCode',
	label : '市代码',
	hidden : true
}, {
	name : 'cityName',
	label : '市<i>*</i>',
	editable : false,
	edittype : 'city',
	width : 200,
	sortable : false
}, {
	name : 'countyCode',
	label : '县代码',
	hidden : true
}, {
	name : 'countyName',
	label : '县',
	editable : false,
	edittype : 'county',
	width : 200,
	sortable : false
}, {
	name : 'address',
	label : '详细地址<i>*</i>',
	editable : false,
	width : 240,
	sortable : false
},{
    name:'cityManagerName',
    label:'城市经理',
    editable:false,
    edittype:'contact',
    width:200,
    sortable:false
},
{
    name:'cityManagerId',
    hidden:true
}, {
	name : 'zip',
	label : '邮编',
	editable : false,
	width : 120,
	sortable : false
}, {
	name : 'contactCode',
	label : '默认联系人<i>*</i>',
	editable : false,
	width : 180,
	sortable : false
}, {
	name : 'contactPhone',
	label : '联系人电话<i>*</i>',
	editable : false,
	width : 160,
	sortable : false
}, {
	name : 'startDt',
	label : '开始时间<i>*</i>',
	editable : false,
	width : 190,
	sorttype : "date",
	sortable : false
}, {
	name : 'endDt',
	label : '结束时间',
	editable : false,
	width : 190,
	sortable : false
}, {
	name : 'receiveTimeCode',
	label : '收货时间代码',
	hidden : true
}, {
	name : 'receiveTimeName',
	label : '收货时间<i>*</i>',
	editable : false,
	edittype : 'receivetime',
	width : 150,
	sortable : false
},
{
    name:'disDelearId',
    hidden:true
},
{
    name:'disDelearName',
    label:'分销经销商',
    editable:false,
    edittype:'disDelearId',
    width:190,
    sortable:false
},
{
    name:'harvestWarehouse',
    hidden:true
},
{
    name:'harvestWarehouseName',
    label:'默认仓库',
    editable:false,
    edittype:'partnerStorage',
    width:100,
    sortable:false
}];

var contactColsM = [ {
	name : 'id',
	label : 'id',
	hidden : true
}, {
	name : 'contactName',
	label : '联系人姓名',
	editable : false,
	width : 200,
	sortable : false
}, {
	name : 'dutyTypeCode',
	label : '职务类型代码',
	hidden : true
}, {
	name : 'dutyTypeName',
	label : '职务类型',
	editable : false,
	edittype : 'dutytype',
	width : 200,
	sortable : false
}, {
	name : 'mobile',
	label : '移动电话',
	editable : false,
	width : 200,
	sortable : false
}, {
	name : 'tel',
	label : '办公电话',
	editable : false,
	width : 200,
	sortable : false
}, {
	name : 'fax',
	label : '传真电话',
	editable : false,
	width : 200,
	sortable : false
}, {
	name : 'email',
	label : 'Email',
	editable : false,
	width : 200,
	sortable : false
}, {
	name : 'startDate',
	label : '开始日期',
	editable : false,
	width : 200,
	sortable : false
}, {
	name : 'endDate',
	label : '结束日期',
	editable : false,
	width : 200,
	sortable : false
} ];
