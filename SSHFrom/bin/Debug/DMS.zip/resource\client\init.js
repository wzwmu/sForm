function change(type){
	if(type=='g'){
		$("#provinceCode_combo").val("");
		$("#provinceCode").empty();
		$("#cityCode_combo").val("");
		$("#cityCode").empty();
		$("#countyCode_combo").val("");
		$("#countyCode").empty();
	}else if(type=='s'){
		$("#cityCode_combo").val("");
		$("#cityCode").empty();
		$("#countyCode_combo").val("");
		$("#countyCode").empty();
	}else if(type=='c'){
		$("#countyCode_combo").val("");
		$("#countyCode").empty();
	}else if(type=="q1"){
		$("#bigAreaCode_combo").val("");
		$("#bigAreaCode").empty();
		$("#areaCode_combo").val("");
		$("#areaCode").empty();
	}else if(type="q2"){
		$("#areaCode_combo").val("");
		$("#areaCode").empty();
	}
}

function changearea(){
	$("#areaCode_combo").val("");
	$("#areaCode").empty();
}

function getDate(){
	var d = new Date();
	var str = d.getFullYear()+"-"+((d.getMonth()+1)<10?"0":"")+(d.getMonth()+1)+"-"+(d.getDate()<10?"0":"")+d.getDate();
	return str;
}

$(document).ready(function(){

	$(".ui-datepicker-input").datepicker();
	
	$("#saleChannelTypeCode").channelTypes({
		onchange:function(){
			$("#bigAreaCode").val("");
			$("#bigAreaCode_combo").val("");
			$("#areaCode").val("");
			$("#areaCode_combo").val("");
		}
	});
	//常规处理方式
	$("#bigAreaCode").areas({
		onchange:function(){
			$("#areaCode").val("");
			$("#areaCode_combo").val("");
		},
		prmNames: {
			parentAreaId:"#saleChannelTypeCode"
		}
	});
	$("#areaCode").areas({
		prmNames: {
			parentAreaId:"#bigAreaCode"
		}
	});
	
	//门店
	$("#bigAreaId").allBigAreas({
		onchange:function(){
			$("#areaId").val("");
			$("#areaId_combo").val("");
		}
	});
	$("#areaId").areas({
		prmNames: {
			parentAreaId:"#bigAreaId"
		}
	});

	
	$("#relatedDelearId").applyers();
	
	$("#countryCode").enumeration({typecode:'COUNTRY',onchange:function(){change('g')}});
	$("#settlementModeCode").enumeration({typecode:'TCBJ_SETTLEMENT_MODE'});
	$("#creditLevelCode").enumeration({typecode:'TCBJ_CREDIT_LEVEL'});
	$("#deliveryCode").enumeration({typecode:'TCBJ_SHIPMENT_TYPE'});
	$("#purchaseSaleCode").enumeration({typecode:'TCBJ_PURCHASE_MODE'});
	$("#partnerLevelCode").enumeration({typecode:'TCBJ_PARTNER_LEVEL'});
	$("#orderTypeCode").enumeration({typecode:'TCBJ_ORDER_TYPE'});
	$("#rtnOrderTypeCode").enumeration({typecode:'TCBJ_RETURN_ORDER_TYPE'});
	$("#deliveryLevelCode").enumeration({typecode:'TCBJ_SHIPMENT_PRIORITY'});
	
	$("#saleTax").enumeration({typecode:'TCBJ_SALES_TAX_CODE'});
	$("#invoiceTypeCode").enumeration({typecode:'TCBJ_BILL_TYPE'});
	$("#stockReceiveTypeCode").enumeration({typecode:'TCBJ_RECEIVE_TYPE'});
	
	$("#bigAreaManagerId").contacts();
	$("#areaManagerId").contacts();
	$("#cityManagerId").contacts();
	$("#marketManagerId").contacts();
	$("#notmypartner").notmypartner();
	
	$("#currencyCode").currency();
	
	$("#giftCtrlMode").enumeration({typecode:'TCBJ_FREEGIFT_CTRL_MODE'});
	$("#tHCJGiftBalance").enumeration({typecode:'YON'});
	
	$("#zdbhFlg").enumeration({typecode:'YON'});
	$("#isReport").enumeration({typecode:'YON'});
	$("#isOrderFreezed").enumeration({typecode:'YON'});
	$("#isDeliveryFreezed").enumeration({typecode:'YON'});
	$("#isInvoiceFreezed").enumeration({typecode:'YON'});
	$("#isCreditManaged").enumeration({typecode:'YON'});
	$("#isStockShow").enumeration({typecode:'YON'});
	$("#isStockReceived").enumeration({typecode:'YON'});
	$("#isAdditionalCal").enumeration({typecode:'YON'});
	$("#zxbzsFlg").enumeration({typecode:'YON'});
	
	$("#nothingCanOrderFlg").enumeration({typecode:'YON'});
	$("#packCtrlFlg").enumeration({typecode:'YON'});
	$("#priceDecimalDigits").enumeration({typecode:'TCBJ_PRICE_DECIMAL_DIGITS'});
	
	$("#addressGridM").editgrid({
		datatype: "local",
		dataSource:addresses,
		multiselect: false,
		multiboxonly:false,
		rownumbers:false,
		footerrow : false,
		initRows:1, 
		autowidth:true,
		autoResize:false,
		autoResizeHeight:false,
		colModel:addressColsM,
		colOpt:[{url:'statics:insert'},{url:'statics:delete'}],
		afterSaveCell : function(rowid,name,val,iRow,iCol) {
			if(name==='addressTypeName'){
				var combo = GridPlugins.getEdittype("addresstype").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var rowData = {
        			addressTypeCode:null,
        			countryCode:"",
        			countryName:"",
        			startDt:"",
        			receiveTimeCode:null,
        			receiveTimeName:""
        		};
        		if(data!=null)
        		rowData = {
        			addressTypeCode:data.name,
        			countryCode:"China",
        			countryName:"中国",
        			startDt:getDate(),
        			receiveTimeCode:"1-5",
        			receiveTimeName:"周一至五 "
        		};
        		
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='countryName'){
				var combo = GridPlugins.getEdittype("country").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var rowData = {
        			countryCode:data.name
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='provinceName'){
				var combo = GridPlugins.getEdittype("province").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var oldData = $(this).jqGrid("getRowData",rowid);
        		if(oldData["provinceCode"]!=data.name){
            		var rowData = {
            			provinceCode:data.name,
            			cityName:'',
            			cityCode:'',
            			countyName:'',
            			countyCode:''
            		};
            		$(this).jqGrid("setRowData",rowid,rowData);
        		}
        	}else if(name==='cityName'){
				var combo = GridPlugins.getEdittype("city").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var oldData = $(this).jqGrid("getRowData",rowid);
        		if(oldData["cityCode"]!=data.name){
            		var rowData = {
            			cityeCode:data.name,
            			countyName:'',
            			countyCode:''
            		};
            		$(this).jqGrid("setRowData",rowid,rowData);
        		}
        		var rowData = {
        			cityCode:data.name
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='countyName'){
				var combo = GridPlugins.getEdittype("county").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var rowData = {
        			countyCode:data.name
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='receiveTimeName'){
				var combo = GridPlugins.getEdittype("receivetime").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var rowData = {
        			receiveTimeCode:data.name
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='disDelearName'){
				var combo = GridPlugins.getEdittype("disDelearId").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var oldData = $(this).jqGrid("getRowData",rowid);
        		if(oldData["disDelearName"]!=data.name){
            		var rowData = {
            			harvestWarehouse:'',
            			harvestWarehouseName:''
            		};
            		$(this).jqGrid("setRowData",rowid,rowData);
        		}
        		var rowData = {
        			disDelearId:data.applyerId
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='harvestWarehouseName'){
				var combo = GridPlugins.getEdittype("customerStorage").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var rowData = {
        			harvestWarehouse:data.id
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}else if(name==='cityManagerName'){
				var combo = GridPlugins.getEdittype("contact").getEle();
        		var data = combo.comboList("getDataByText",val);
        		if(data == null){return;}
        		var rowData = {
        			cityManagerId:data.id
        		};
        		$(this).jqGrid("setRowData",rowid,rowData);
        	}
        },
        afterEditCell : function(rowid,name,val,iRow,iCol) {
        	if(name==="startDt"){
        		$("#"+iRow+"_"+name).datepicker();
        	}else if(name==="endDt"){
        		$("#"+iRow+"_"+name).datepicker();
        	}
        }
	});
   
   $("#contactGridM").editgrid({
		datatype: "local",
		dataSource:contacts,
		multiselect: false,
		multiboxonly:false,
		rownumbers:false,
		footerrow : false,
		initRows:0,
		autowidth:true,
		autoResize:false,
		autoResizeHeight:false,
		colModel:contactColsM
	});
	
});


function validate(){
	return $("#frm").valid();
}

function validateGrid(){
	
	var addresses = $("#addressGridM").editgrid("getEffectiveRowData","addressTypeCode");
	if(addresses.length>0){
		for(var i=0;i<addresses.length;i++){
			var address = addresses[i];
			/*if(StringUtils.isEmpty(address['countryCode'])){$("#addressGridError").html("国家不能为空").show();return false;}*/
			if(StringUtils.isEmpty(address['provinceCode'])){$("#addressGridError").html("第"+(i+1)+"行，省不能为空").show();return false;}
			if(StringUtils.isEmpty(address['cityCode'])){$("#addressGridError").html("第"+(i+1)+"行，市不能为空").show();return false;}
			if(StringUtils.isEmpty(address['address'])){$("#addressGridError").html("第"+(i+1)+"行，详细地址不能为空").show();return false;}
//			if(StringUtils.zip(address['zip'])){$("#addressGridError").html("第"+(i+1)+"行，请填写正确的邮编").show();return false;}
			if(StringUtils.isEmpty(address['contactCode'])){$("#addressGridError").html("第"+(i+1)+"行，默认联系人不能为空").show();return false;}
			if(StringUtils.isEmpty(address['contactPhone'])){$("#addressGridError").html("第"+(i+1)+"行，默认联系电话不能为空").show();return false;}
			if(StringUtils.isEmpty(address['startDt'])){$("#addressGridError").html("第"+(i+1)+"行，开始时间不能为空").show();return false;}
			if(StringUtils.isEmpty(address['receiveTimeCode'])){$("#addressGridError").html("第"+(i+1)+"行，收货时间不能为空").show();return false;}
		}
	}
}


var contactColsM =
[
    {
        name:'id',
        label:'id',
        hidden:true
    },
    {
        name:'contactName',
        label:'联系人姓名',
        editable:false,
        width:200,
        sortable:false
    },
    {
        name:'dutyTypeCode',
        label:'职务类型代码',
        hidden:true
    },
    {
        name:'dutyTypeName',
        label:'职务类型',
        editable:false,
        edittype:'dutytype',
        width:200,
        sortable:false
    },
    {
        name:'mobile',
        label:'移动电话',
        editable:false,
        width:200,
        sortable:false
    },
    {
        name:'tel',
        label:'办公电话',
        editable:false,
        width:200,
        sortable:false
    },
    {
        name:'fax',
        label:'传真电话',
        editable:false,
        width:200,
        sortable:false
    },
    {
        name:'email',
        label:'Email',
        editable:false,
        width:200,
        sortable:false
    },
    {
        name:'startDate',
        label:'开始日期',
        editable:false,
        width:200,
        sortable:false
    },
    {
        name:'endDate',
        label:'结束日期',
        editable:false,
        width:200,
        sortable:false
    }
];

var addressColsM =
	[
	    {
	    name:'id',
        label:'id',
        hidden:true
    },
    {
        name:'addressTypeCode',
        label:'地址类型代码',
        hidden:true
    },
    {
        name:'addressTypeName',
        label:'地址类型<i>*</i>',
        editable:true,
        edittype:'addresstype',
        width:160,
        sortable:false
    },
    {
        name:'countryCode',
        label:'国家代码',
        hidden:true
    },
    {
        name:'countryName',
        label:'国家',
        editable:true,
        edittype:'country',
        width:200,
        sortable:false,
        hidden:true
    },
    {
        name:'provinceCode',
        label:'省代码',
        hidden:true
    },
    {
        name:'provinceName',
        label:'省<i>*</i>',
        editable:true,
        edittype:'province',
        width:200,
        sortable:false
    },
    {
        name:'cityCode',
        label:'市代码',
        hidden:true
    },
    {
        name:'cityName',
        label:'市<i>*</i>',
        editable:true,
        edittype:'city',
        width:200,
        sortable:false
    },
    {
        name:'countyCode',
        label:'县代码',
        hidden:true
    },
    {
        name:'countyName',
        label:'县',
        editable:true,
        edittype:'county',
        width:200,
        sortable:false
    },
    {
        name:'address',
        label:'详细地址<i>*</i>',
        editable:true,
        width:240,
        sortable:false
    },{
        name:'cityManagerName',
        label:'城市经理',
        editable:true,
        edittype:'contact',
        width:200,
        sortable:false
    },
    {
        name:'cityManagerId',
        hidden:true
    },
    {
        name:'zip',
        label:'邮编',
        editable:true,
        width:120,
        sortable:false
    },
    {
        name:'contactCode',
        label:'默认联系人<i>*</i>',
        editable:true,
        width:180,
        sortable:false
    },
    {
        name:'contactPhone',
        label:'联系人电话<i>*</i>',
        editable:true,
        width:160,
        sortable:false
    },
    {
        name:'startDt',
        label:'开始时间<i>*</i>',
        editable:true,
        width:190,
        sorttype:"date",
        sortable:false
    },
    {
        name:'endDt',
        label:'结束时间',
        editable:true,
        width:190,
        sortable:false
    },
    {
        name:'receiveTimeCode',
        label:'收货时间代码',
        hidden:true
    },
    {
        name:'receiveTimeName',
        label:'收货时间<i>*</i>',
        editable:true,
        edittype:'receivetime',
        width:190,
        sortable:false
    },
    {
        name:'disDelearId',
        hidden:true
    },
    {
        name:'disDelearName',
        label:'分销经销商',
        editable:true,
        edittype:'disDelearId',
        width:190,
        sortable:false
    },
    {
        name:'harvestWarehouse',
        hidden:true
    },
    {
        name:'harvestWarehouseName',
        label:'默认仓库',
        editable:true,
        edittype:'customerStorage',
        width:100,
        sortable:false
    },
    {"align":"center","editable":false,"fixed":true,"hidden":false,"label":"操作","name":"operation","sortable":false,"width":60}
];

