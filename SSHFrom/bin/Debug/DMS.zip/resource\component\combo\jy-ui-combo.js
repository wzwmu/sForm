(function($, undefined) {

	var combo_global_layer = 1;

	$
			.widget(
					"ui.combo",
					{
						options : {
							/**
							 * 从服务器获取combo数据 在dataType=json时需要设置该参数
							 */
							url : 'getArticles.do',
							/**
							 * 
							 */
							timeout : 15000,
							/**
							 * 支持两种类型: 'json':数据通过ajax从url获取,需要设置url参数;
							 * 'local':数据通过本地数据获取,需要设置dataSource参数
							 */
							dataType : "json",
							/**
							 * 从本地获取combo数据 在dataType=local时需要设置该参数
							 */
							dataSource : null,
							/**
							 * 是否启用本地缓存,在dataType=json的情况下,
							 * 如果该参数为true,只从服务器获取一次数据,反之每次都从服务器获取数据
							 */
							dataCache : true,

							/**
							 * 控件是否显示清除数据按钮
							 */
							clear : false,

							/**
							 * 控件初始化即加载数据,默认加载
							 */
							initLoad : true,

							/**
							 * combo显示列定义 isValue:true的列只能有一个,
							 * isText:true的列可以有多个
							 */
							colModel : [ {
								name : 'id',
								isValue : true
							}, {
								name : 'name',
								align : "center",
								isText : true
							} ],
							/**
							 * json格式数据阅读器,从json数据中的root属性获取combo需要的数据
							 */
							jsonReader : {
								/*
								 * 集合的名称
								 */
								root : null
							},
							prmNames : {
								/*
								 * 传递到后台查询条件的名称
								 */
								condition : "categoryName"
							},

							/*
							 * 组件的宽度
							 */
							width : null,
							/*
							 * 默认为false,表示会处理 组件不处理组件的宽度,一切以界面元素的原始尺寸显示
							 * 该参数主要用于解决jquery-ui-grid的编辑宽度自动拉伸问题
							 */
							autoWidth : false,
							/*
							 * 下拉面板的宽度
							 */
							panelWidth : null,
							/*
							 * 下拉面板的高度
							 */
							panelHeight : 200,
							/*
							 * 定义是否支持多选
							 */
							multiple : false,
							/*
							 * 多选时文本的分隔符
							 */
							separator : ',',
							/*
							 * 定义是否用户可以往文本域中直接输入文字
							 */
							editable : true,

							selectable : true,

							/*
							 * operator:{ caption:'新增商品ww',
							 * callback:function(){} },
							 */

							operator : null,

							onchange : null,

							arrow : {
								/*
								 * 是否显示向下箭头的按钮
								 */
								hasDownArrow : true,
								alt : '打开下拉菜单',
								callback : function(combo) {
								}
							},

							/* operator:null, */

							/*
							 * 键盘事件
							 */
							keyHandler : {},
							/*
							 * 鼠标事件
							 */
							mouseHandler : {
								clike : null
							},
							onSelect : null,
							cache : {}
						},
						widget : function() {
							alert('rtn');
							return this;
						},
						_createWrapper2 : function() {
							var wrap = $("<div class='m-combo'></div>");
							if (this.options.arrow != null
									&& this.options.arrow.hasDownArrow == true) {
								var arrow = $(
										"<span class='m-combo-icon select'></span>")
										.appendTo(wrap);
								arrow.attr("title", this.options.arrow.alt);
							}
							var ep = this.element.parent();
							ep.append(wrap.prepend(this.element));
							// wrap.css({width:this.options.width||this.element.outerWidth()});
							if (this.options.editable != true)
								this.element.attr("readonly", "readonly");
							else
								this.element.removeAttr("readonly");
							this._initElementEvent();
						},
						_createWrapper : function() {
							var wrap = $("<div class='m-combo'></div>");
							if (this.options.arrow != null
									&& this.options.arrow.hasDownArrow == true) {
								var arrow = $("<span class='m-combo-icon select'></span>");
								arrow.attr("title", this.options.arrow.alt);
								wrap.append(arrow);
							}

							var elementParent = this.element.parent();
							if (this.element.is("select")) {
								var input = $("<input type='text'/>");
								if (this.element.attr("id") != undefined)
									input.attr("id", this.element.attr("id")
											+ "_combo");
								if (this.element.attr("name") != undefined)
									input.attr("name", this.element
											.attr("name")
											+ "_combo");
								if (this.element.attr("class") != undefined)
									input.attr("class", this.element
											.attr("class"));
								if (this.element.attr("style") != undefined)
									input.attr("style", this.element
											.attr("style"));
								if (this.element.attr("title") != undefined)
									input.attr("title", this.element
											.attr("title"));
								if (this.element.hasClass("required"))
									this.element.removeClass("required");
								input.val(this.element.find("option:selected")
										.text());
								wrap.prepend(input);
								wrap.append(this.element);
								/*
								 * //填充值 var val = this.element.val();
								 * if(StringUtils.isNotEmpty(val)){ //自动填充值 var
								 * data = this.getDataByVal(val);
								 * if(data!=null){ var str = ""; for(var j=0;j<this.options.colModel.length;j++){
								 * if(this.options.colModel[j].isValue&&this.options.colModel[j].isValue==true)
								 * continue;
								 * str+=data[this.options.colModel[j].name]+" "; }
								 * input.val(str); } }
								 */
								this.element.hide();
								this.element = input;
							} else {
								wrap.prepend(this.element);
							}
							elementParent.append(wrap);

							this._resize();

							/* ************************************************* */

							/*
							 * =====================让input宽度100%时不溢出
							 * ==================== var elementWidth =
							 * this.element.outerWidth(); var containerWidth =
							 * this.element.parent().parent().width();
							 * //alert(elementWidth+":"+containerWidth);
							 * if(elementWidth>containerWidth){
							 * this.element.width(this.element.width()-(elementWidth-containerWidth)); }
							 * /*========================================
							 */

							// wrap.css({width:this.options.width||this.element.outerWidth()});
							if (this.options.editable != true)
								this.element.attr("readonly", "readonly");
							else
								this.element.removeAttr("readonly");

							this._initElementEvent();
						},
						_createPanel : function() { // 创建下拉框显示面板div
							var panel = $("<div class='m-combo-panel' style='display:none;' id='id"
									+ this._getSimpleEventNamespace()
									+ "'></div>");
							this.panel = panel;
							$(document.body).append(panel);

							var contentPanel = $("<div class='m-combo-cpanel'></div>"); // 创建包含的内容的div
							this.contentPanel = contentPanel;
							panel.append(contentPanel);

							if (this.options.operator != null
									|| this.options.clear == true) {
								var operatePanel = $("<div class='m-combo-opanel'></div>");// 操作显示面板div
								if (this.options.operator != null) {
									var opt = $("<a href='#'><i class='icon'></i>"
											+ this.options.operator.caption
											+ "</a>");
									// opt.attr("href",this.options.operator.callback(this));
									this._on(opt, {
										click : function() {
											this.options.operator
													.callback(this);
										}
									});
									operatePanel.append(opt);
								}
								if (this.options.clear == true) {
									var cls = $("<a href='#'>清除</a>");
									this._on(cls, {
										click : function() {
											this.clearVal();
										}
									});
									operatePanel.append(cls);
								}
								operatePanel.click(function(event) {
									event.stopPropagation();
								});
								this.operatePanel = operatePanel;
								panel.append(operatePanel);
							}
							;

						},
						_resize : function() {
							if (this.options.autoWidth == true)
								return;
							if (this.options.width != null
									&& this.options.width.toString() != ""
									&& this.options.width.toString()
											.toLowerCase() != 'auto') {
								this.element.css({
									width : this.options.width
								});
							} else {
								// alert(this.element.css("width"));
								this.element.css({
									width : this.element.parent().width()
								});
							}
							/*
							 * alert(this.element.width());
							 * this.element.css({width:this.element.width()-(this.element.outerWidth()-this.element.width())});
							 * this.element.parent().css({width:this.element.outerWidth()});
							 */
						},
						_create : function() {
							/*
							 * if(this.options.dataType==="local"){
							 * this._loadJson("",function(data){}); }
							 */
							this._createWrapper();
							this._createPanel();
							if (this.options.initLoad == true)
								this.initData();
						},
						setVal : function(val) {
							var that = this;
							this
									._loadJson(
											"",
											function() {
												if (1 == 1) {
													var data = that
															.getDataByVal(val);
													var str = "";
													if (data != null) {
														var str = "";
														for (var j = 0; j < that.options.colModel.length; j++) {
															if (that.options.colModel[j].isValue
																	&& that.options.colModel[j].isValue == true)
																continue;
															str += data[that.options.colModel[j].name];
															if (j < that.options.colModel.length - 1)
																str += " - ";
														}
													} else {
														val = "";
													}
													that.element.val(str);
													var select = that.element
															.parent().children(
																	"select");
													if (select.length > 0) {
														select.empty();
														var option = $("<option></option>");
														option.html(str);
														option.val(val);
														select.append(option);
													}
												}

											});
						},
						initData : function() {
							var that = this;
							var select = that.element.parent().find("select");
							if (select.size() < 1)
								return;
							this
									._loadJson(
											"",
											function() {
												var val = select.val();
												// 填充值
												// alert(that.options.initLoad);
												if (1 == 1/* StringUtils.isNotEmpty(val) */) {
													// 自动填充值
													var data = that
															.getDataByVal(val);
													if (data != null) {
														var str = "";
														for (var j = 0; j < that.options.colModel.length; j++) {
															if (!that.options.colModel[j])
																continue;
															if (that.options.colModel[j].isValue
																	&& that.options.colModel[j].isValue == true)
																continue;
															if (data[that.options.colModel[j].name] == null)
																continue;
															str += data[that.options.colModel[j].name];
															if (j < that.options.colModel.length - 1)
																str += " - ";
														}
														that.element.val(str);
													}
												}
											});
						},
						_init : function() {
						},
						_isPanelShow : function() {
							return this.panel.is(":visible");
						},
						_showPanel : function(event) {
							if (this._isPanelShow())
								return;
							this.panel.show();

							var panelWidth = this.options.panelWidth
									|| this.element.outerWidth();
							var panelHeight = this.options.panelHeight || 200;
							// this.contentPanel.css({width:panelWidth-2,height:panelHeight-this.operatePanel.outerHeight()});
							this.contentPanel.css({
								width : panelWidth - 2,
								height : panelHeight
							});
							var offset = this.element.offset();
							this.panel.css({
								zIndex : combo_global_layer++,
								left : offset.left,
								top : offset.top + this.element.outerHeight()
										- 1
							});
							this.__trigger("_onShowPanel", event);
						},
						_hidePanel : function(event) {
							this.panel.hide();
							this.__trigger("_onHidePanel", event);
						},
						hidePanel : function() {
							this._hidePanel();
						},
						_initElementEvent : function() {
							if (/msie/.test(navigator.userAgent.toLowerCase())) {
								var that = this;
								this.element[0]
										.attachEvent(
												'onpropertychange',
												function(event) {
													if (event.propertyName == "value") {
														if (that.element
																.is(":focus") == true)
															that
																	.__trigger(
																			"_onChange",
																			event);
													}
												});
							}
							this._on(this.element, {
								input : function(event) {
									this.__trigger("_onChange", event);
								},
								keydown : function(event) {
									switch (event.keyCode) {
									case 8:
										if (this.options.editable == false) {
											return false;
										}
										break;
									case 40:
										/* 向下键 */
										this.__trigger("_onMoveDown", event);
										return true;
									case 38:
										// 向上键
										this.__trigger("_onMoveUp", event);
										return false;
									case 13:
										this.element.blur();
										this.__trigger("_onEnter", event);
										this.element.focus();
										break;
									}
								},
								keyup : function(event) {
									// if(event.keyCode == 40||event.keyCode ==
									// 38)
									// return;
									/* 增加esc键盘监听 */
									if (event.keyCode == 27) {
										this._hidePanel();
										return;
									}
									// alert(this.element.val()+":"+this.oldVal);
									// if(this.element.val()==this.oldVal)
									// return;
									// this.__trigger( "_onChange", event );
									// this._showPanel();
									// this.oldVal = this.element.val();
								},
								click : function(event) {
									// var target =event.srcElement ?
									// event.srcElement :event.target;
									// if(target==this.element.get(0))
									// event.stopPropagation();
									this.__trigger("_onClick", event);
								},
								dblclick : function() {
									event.stopPropagation();
									this.__trigger("_onDblclick", event);
								},
								blur : function(event) {
									// this.element.css({border:'1px solid
									// #D7D7D7'});
									this.__trigger("_onBlur", event);
								},
								focus : function(event) {
									// this.element.css({border:'1px solid
									// #999'});
									this.__trigger("_onFocus", event);
								}
							});
							this
									._on(
											$(document),
											{
												click : function(event) {
													var target = event.srcElement ? event.srcElement
															: event.target;
													if (target == this.element
															.get(0)
															|| target == this.element
																	.parent()
																	.children(
																			"span")
																	.get(0)
															|| (target == this.element
																	.parent()
																	.parent()
																	.parent()
																	.get(0))
															&& $(target)
																	.hasClass(
																			"edit-cell"))
														return;
													this._hidePanel();
												}
											});
							var arrow = this.element.parent().children("span");
							this._on(arrow, {
								click : function(event) {
									// event.stopPropagation();
									this.element.focus();
									this.__trigger("_onArrowDown", event);
									if (this.options.arrow
											&& this.options.arrow.callback)
										this.options.arrow.callback(this);
								}
							});
						},
						_getValueColMode : function() {
							for (var i = 0; i < this.options.colModel.length; i++) {
								var col = this.options.colModel[i];
								if (col.name == undefined)
									continue;
								if (col.isValue && col.isValue == true) {
									return col;
								}
							}
							return null;
						},
						getDataByText : function(text) {
							var json = this._getCacheJson();
							if (json == null)
								return;
							var datas = this._readJson(json);
							for (var i = 0; i < datas.length; i++) {
								var str = "";
								var data = datas[i];
								for (var j = 0; j < this.options.colModel.length; j++) {
									if (this.options.colModel[j].isValue
											&& this.options.colModel[j].isValue == true)
										continue;
									if (data[this.options.colModel[j].name] == null)
										continue;
									str += data[this.options.colModel[j].name];
									if (j < this.options.colModel.length - 1)
										str += " - ";
								}
								if ($.trim(str) == $.trim(text))
									return data;
							}
							return null;
						},
						getDataByVal : function(value) {
							var json = this._getCacheJson();
							if (json == null)
								return;
							var datas = this._readJson(json);
							var colmode = this._getValueColMode();
							if (colmode == null)
								return null;
							for (var i = 0; i < datas.length; i++) {
								var data = datas[i];
								if (data == null)
									continue;
								if (data[colmode.name] == value)
									return data;
							}
							return null;
						},
						getFullDataByName : function(value) {

							var json = this._getCacheJson();

							if (json == null)
								return;

							for (var i = 0; i < json.length; i++) {

								if (json[i].shopName == value)
									return json[i];
							}

							return null;
						},
						clearVal : function() {
							this.element.val("");
							this.element.attr("val", "");
							var select = this.element.parent().children(
									"select");
							if (select.length > 0) {
								select.empty();
							}
							this.hidePanel();
							if (this.options.onChange)
								this.options.onChange("", "");
						},
						_hasLoadJson : function() {
							if (this._loading == undefined
									|| this._loading == true)
								return false;
							return true;
						},
						_loadJson : function(condition, callback) {
							if (this._loading == undefined
									|| this._loading == false) {
								this._loading = true;
								this._clearPanel();

								if (this.options.dataType === "local") {
									if (this.options.dataCache == false
											|| this.options.dataSource === undefined
											|| this.options.dataSource == null) {
										if (this.options.type === "enum") {

											if (this.options.dependence !== undefined) {
												var val = null;
												// alert(typeof(this.options.dependence).toLowerCase());
												if (typeof (this.options.dependence) === "function") {
													val = this.options.dependence
															.apply(
																	this.element,
																	[]);
													// data = ();

												} else {
													val = $(
															this.options.dependence)
															.val();
												}
												// alert(val);
												// console.info(JSON.stringify(___dictionarys));
												if (StringUtils.isNotEmpty(val)) {
													// 过滤数据
													var datas = ___dictionarys[this.options.typecode];
													var rtns = [];
													for (var i = 0; i < datas.length; i++) {
														var data = datas[i];
														if (data["parName"] == val)
															rtns[rtns.length] = data;
													}
													this.options.dataSource = rtns;
												}

											} else {
												this.options.dataSource = ___dictionarys[this.options.typecode];
											}

										} else if (this.options.type === "currency") {
											this.options.dataSource = ___currencytype;
										} else if (this.options.type === "contacts") {
											this.options.dataSource = ___employees;
										}
									}

									if (typeof this.options.dataSource == 'function') {

										this._setCacheJson(this.options
												.dataSource());
										if (callback)
											callback(this.options.dataSource());

									} else {

										this
												._setCacheJson(this.options.dataSource);
										if (callback)
											callback(this.options.dataSource);
									}

									this._loading = false;
									return;
								}

								var that = this;
								var data = {};
								data[this.options.prmNames.condition] = condition;
								if (this.options.dataCache != true
										|| (this.options.dataCache == true && this
												._getCacheJson() == undefined)) {
									this.contentPanel.addClass("loading");
									var url = this.options.url;
									var timeout = this.options.timeout;
									if (StringUtils
											.isNotEmpty(this.options.prmNames)) {
										for ( var i in this.options.prmNames) {
											var ele = this.options.prmNames[i];
											var val = null;
											if (typeof (ele) === 'function') {
												val = ele.apply(this.element,
														[]);
												if (StringUtils.isNotEmpty(val)) {
													val = val.replace(
															/&nbsp;/g, '');
												}
											} else {
												val = $(ele).val();
											}
											if (StringUtils.isNotEmpty(val)) {
												data[i] = val;
											}
										}
									}
									if (StringUtils
											.isNotEmpty(this.options.typecode)) {
										url = url + "?typecode="
												+ this.options.typecode;
										if (StringUtils
												.isNotEmpty(this.options.groupNo)) {
											if (typeof (this.options.groupNo) === 'function') {
												url = url
														+ "&groupNo="
														+ this.options.groupNo
																.apply(this, []);
											} else {
												url = url + "&groupNo="
														+ this.options.groupNo;
											}

										}

									}

									$.ajax({
										url : url,
										type : 'GET',
										dataType : 'json',
										data : data,
										timeout : timeout,
										error : function() {
											// TODO alert('不能从服务器获取数据');
											that.contentPanel
													.removeClass("loading");
											that._loading = false;
										},
										success : function(json) {
											that._setCacheJson(json);
											if (callback)
												callback(json);
											that.contentPanel
													.removeClass("loading");
											that._loading = false;
										}
									});
								} else {
									var json = this._getCacheJson();
									if (callback)
										callback(json);
									this._loading = false;
								}
							}
						},
						_readJson : function(json) {
							if (json == undefined || json == null)
								return null;
							if (this.options.jsonReader.root == undefined
									|| this.options.jsonReader.root == null)
								return json;
							return json[this.options.jsonReader.root];
						},
						_getCacheJson : function() {
							return this.options.cache["json"];
							// return this._cache["json"];
						},
						_setCacheJson : function(json) {
							this.options.cache["json"] = json;
						},
						_filterData : function(datas, condition) {
							if (datas == null)
								return null;
							if (this.options.filter != undefined
									&& this.options.filter != null) {
								var _datas = [];
								for (var i = 0; i < datas.length; i++) {
									var tof = true;
									for ( var j in this.options.filter) {
										var vals = this.options.filter[j]
												.split(",");
										var _tof = false;
										for (var n = 0; n < vals.length; n++) {
											if (datas[i][j] == vals[n]) {
												_tof = true;
												break;
											}
										}
										if (_tof == false) {
											tof = false;
											break;
										}
									}
									if (tof == true)
										_datas[_datas.length] = datas[i];
								}
								datas = _datas;
							}
							if (typeof (condition) == undefined
									|| condition == null)
								return datas;
							condition = $.trim(condition);
							// var conditionName =
							// this.options.prmNames.condition;
							var newDatas = [];
							for (var i = 0; i < datas.length; i++) {
								var data = datas[i];
								var str = "";
								for (var j = 0; j < this.options.colModel.length; j++) {
									if (!this.options.colModel[j])
										continue;
									if (this.options.colModel[j].isValue
											&& this.options.colModel[j].isValue === true)
										continue;
									if (data[this.options.colModel[j].name] == null)
										continue;
									str += data[this.options.colModel[j].name];
									if (j < this.options.colModel.length - 1)
										str += " - ";
								}
								if (str.indexOf(condition) >= 0) {
									newDatas[newDatas.length] = data;
								}
							}
							return newDatas;
						},
						_clearPanel : function() {
							if (this.contentPanel)
								this.contentPanel.empty();
						},
						_getSimpleEventNamespace : function() {
							if (this.eventNamespace
									&& this.eventNamespace.length > 0)
								return this.eventNamespace.replace(".", "-");
							return "combo";
						},
						__trigger : function(type, event, datas) {
							if (this[type]) {
								if (arguments.length == 2)
									this[type](event);
								else if (arguments.length == 3)
									this[type](event, datas);
							}
						},
						selectable : function(val) {
							this.options.selectable = val;
						},
						destroy : function() {
							this.element.removeClass("m-combo");
						}
					});

}(jQuery));