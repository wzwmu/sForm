var selectedGrid;


$(document).ready(function(){
	console.log(itermList);
	$('#vouchItemGrid').editgrid({
		datatype : 'local',
		dataSource : itermList,
		multiselect : false,
		multiboxonly : false,
		initRows : 1,
		
		rownumbers : false,
		footerrow : false,
		rowNum:200,
		arraytype:'page',
		pager:'#pager',
		
		autowidth : true,
		autoResize : true,
		autoResizeHeight : false,
		colModel : CheckVouchItemCols,
		colOpt:[{url:'statics:insert'},{url:'statics:delete',allowEmpty:false,callback:function(e, rowid, rowData){
			OrderBase._calculateActTotal($(gridId));
		}}],
		beforeEditCell:function(rowId, name, val, iRow, iCol) {
			/*if(name==='realityQuantity'){
				var row = $("#CheckVouchItemGrid").editgrid('getRowData',rowId);
				if(row.electType=='Electronic') {
					this.removeClass("edit-cell ui-state-highlight");
				}
			}*/
			if(name==='productName'){
				var vouchTypeTemp = $("#vouchTypeTemp").val();
				if(vouchTypeTemp!='fillVouch') {
					setTimeout(function () {
	                	$("#CheckVouchItemGrid").jqGrid('restoreCell', iRow, iCol);
	                }, 1);
				}
			}
		},
		gridComplete:function(){
        	if($("#RowGrid").editgrid('getEffectiveRowData').length==0){
        		$("#RowGrid").editgrid('addRowData',{});
        	}
        },afterSaveCell : function(rowId,name,val,iRow,iCol) {
			if(name === 'productName'){
				var combo = GridPlugins.getEdittype("OrderItem").getEle();
				var data = combo.comboList("getDataByText",val);
				var rowData = {
					productNo:	data.no,
					productId:data.id
				};
				$(this).jqGrid("setRowData",rowId,rowData);
			} else if(name === 'productDt'){
				var dateTemp = val.split("-");
				if(dateTemp.length>2) {
					var rowData = {
						batchNo:	dateTemp[0]+dateTemp[1]+dateTemp[2]
					};
					$(this).jqGrid("setRowData",rowId,rowData);
				}
			}
        },afterEditCell: function (rowid, name, val, iRow, iCol) {
            if (name === "productDt") {
                $("#" + iRow + "_" + name).datepicker();
            }
        }
	});
	
	
	
	$("#save").click(function(){
		$('#vouchItemGrid').editgrid('blur');
		var submitType = $(this).attr("id");
	
		var dataPremer = {};
		var data = FormUtils.getSubmitData($(document));
		dataPremer.checkVouchSnaps = $('#vouchItemGrid').editgrid('getEffectiveRowData','');
		dataPremer.vocuId = data.vocuId;
		dataPremer.snapIds = data.snapIds;
		dataPremer.vouchProductType= data.vouchProductType;
		var toserver = function(){
			var dlg = null;
			Ajax.post({
				url: "saveFillVouchDetail.do",
				data: dataPremer,
				contentType:"application/json;charset=utf-8",
				submitBefore:function(){
					dlg = ResultUtils.showProgress();
				},
				success: function(rtn){
					var title = "<div class='title'>已经将修改保存,您可以继续选择下面的操作：</div>";
					title = title + "<div class='row'><a href=scanList.do?vocuId="+data.vocuId+">返回盘点单列表</a> </div>";
			
					ResultUtils.showSuccess({
						dialog:dlg,
						width:400,
						height:150,
						content:title
					});
				},   
				error: function(errors){
					var msg = errors[0].message;
					var ctn = "<div class='title'>操作失败,具体原因如下：</div>"+
					 "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
				}
			});
		};
		if(submitType=="save"){
			title = "<span style='padding:0px 30px;'>确定要保存吗?<span class='to'></span></span>";
			$.dialog.confirm(title,function(){
				toserver();
			});
		}else{
			toserver();
		}
	});
	
});

var CheckVouchItemCols = [ {
	name : 'productId',
	label : '产品编号ID',
	editable : false,
	hidden : true
},{
	name : 'productNo',
	label : '产品编号',
	editable : false,
	hidden : false
}, {
	name : 'productName',
	label : '产品全称',
	edittype:'OrderItem',
	editable:true,
	sortable : false
},{
	name : 'batchNo',
	label : '产品批次',
	editable : false,
	hidden : false,
	width : 120
}, {
	name : 'productDt',
	label : '生产日期',
	editable : true,
	formatter:"date",formatoptions: {srcformat:'u'},
	hidden : false
}, {
	name : 'quantity',
	label : '库存数量',
	editable : true,
	formatter:"currency",
	formatoptions:{decimalPlaces:0,showZero:true},
	hidden : false
}, {
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
}, {
	"align" : "center",
	"editable" : false,
	"fixed" : true,
	"hidden" : false,
	"label" : "操作",
	"name" : "operation",
	"sortable" : false,
	"width" : 60
}];


GridPlugins.edittypes.push({
	getEle : function() {
		return $('.grid_plugins_element_OrderItem');
	},
	name : 'OrderItem',
	element : function(value, options) {
		var elem = $('.grid_plugins_element_OrderItem');
		if (elem.length == 0) {
			elem = $("<input type='text' class='grid_plugins_element_OrderItem textbox' style='width:100%'>");
			var container = $("#grid_plugins_element_container");
			if (container.length == 0) {
				container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
				$(document.body).append(container);
				container.append(elem);
			}
			// 初始化下拉组件
			elem.comboList({
				dataType:'json', 
				url:getGridUrl(),
				dataCache:true,
				validate : true,
				autoWidth : true,
				jsonReader : {
					root : null
				},
				editable : true,
				colModel : [ {
					name : 'productId',
					isValue : true
				}, {
					name : 'productName',
					align : "center",
					isText : true
				} ],
				prmNames : {
					condition : "name"
				}
			});
		}
		elem.val(value);
		return elem.parent()[0];
	},
	value : function(elem, operation, value) {
		if (operation === 'get') {
			$('#grid_plugins_element_container').append(elem);
			$('.grid_plugins_element_OrderItem').comboList('hidePanel');
			$(elem).focus();
			return $('.grid_plugins_element_OrderItem').val();
		} else if (operation === 'set') {
			$('.grid_plugins_element_OrderItem').val(value);
		}
	},
	handle : function() {
	},
	show : function() {
		$(".grid_plugins_element_OrderItem").comboList('showPanel');
	}
});


/**
 * 触发表单验证
 * @return
 *//*
function validate(){
	return $("#frm").valid();
}*/
/**
 * 触发grid验证
 * @return
 */
function validateGrid(){
	return true;
}

function getGridUrl(){
	var url = "../select/findProductsByType.do?type="+$("#vouchProductType").val();
	
	return url;
}

