var OrderApply = $.extend(true, OrderBase, {
	_initElements : function() {

	}
});
var productCols = [ {
	name : '_id',
	label : '_id',
	hidden : true
}, {
	name : 'no',
	label : '产品编号',
	width : 60,
	align : "center",
	sortable : false
}, {
	name : 'productName',
	label : '产品全称',
	edittype:'OrderItem',
	editable:true,
	sortable : false
}, {
	name : 'minUnit',
	label : '包装数',
	width : 60,
	align : "right",
	sortable : false
}, {
	name : 'typeCode',
	hidden : true
}, {
	name : 'typeName',
	label : '订单类型',
	editable : true,
	width : 60,
	align : "center",
	edittype : 'OrderItemType',
	sortable : false
}, {
	name : 'quantityBuy',
	label : '申购数量',
	editable : false,
	align : "right",
	width : 60,
	sortable : false
}, {
	name : 'quantity',
	label : '订单数量',
	editable : true,
	align : "right",
	classes : 'celledit',
	width : 60,
	sortable : false
}, {
	name : "productId",
	hidden : true
}, {
	name : "priceType",
	hidden : true
}, {
	name : "price1",
	hidden : true
}, {
	name : "price2",
	hidden : true
}, {
	name : "price3",
	hidden : true
}, {
	name : 'price',
	label : '单价(元)',
	width : 25,
	formatter : "currency",
	formatoptions : {
		decimalPlaces : griddigits,
		showZero : true
	},
	editable : true,
	align : "right",
	sortable : true
}, {
	name : 'money',
	label : '金额(元)',
	width : 35,
	formatter : "currency",
	formatoptions : {
		decimalPlaces : griddigits,
		showZero : true
	},
	align : "right",
	sortable : false
}, {
	name : 'unitCode',
	label : '单位',
	width : 30,
	align : "center",
	sortable : false
}, {
	name : 'stateName',
	label : '状态',
	width : 60,
	align : "center",
	hidden : false
}, {
	align : "center",
	label : "操作",
	name : "operation",
	width : 60,
	sortable : false
} ];

GridPlugins.edittypes.push({
	getEle : function() {
		return $('.grid_plugins_element_OrderItem');
	},
	name : 'OrderItem',
	element : function(value, options) {
		var elem = $('.grid_plugins_element_OrderItem');
		if (elem.length == 0) {
			elem = $("<input type='text' class='grid_plugins_element_OrderItem textbox' style='width:100%'>");
			var container = $("#grid_plugins_element_container");
			if (container.length == 0) {
				container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
				$(document.body).append(container);
				container.append(elem);
			}
			// 初始化下拉组件
			elem.comboList({
//				dataType:'local',
//				dataSource : products,
				dataType:'json', 
				url:getGridUrl(),
				dataCache:true,
				validate : true,
				autoWidth : true,
				jsonReader : {
					root : null
				},
				editable : true,
				colModel : [ {
					name : 'productId',
					isValue : true
				}, {
					name : 'productName',
					align : "center",
					isText : true
				} ],
				prmNames : {
					condition : "name"
				}
			});
		}
		elem.val(value);
		return elem.parent()[0];
	},
	value : function(elem, operation, value) {
		if (operation === 'get') {
			$('#grid_plugins_element_container').append(elem);
			$('.grid_plugins_element_OrderItem').comboList('hidePanel');
			$(elem).focus();
			return $('.grid_plugins_element_OrderItem').val();
		} else if (operation === 'set') {
			$('.grid_plugins_element_OrderItem').val(value);
		}
	},
	handle : function() {
	},
	show : function() {
		$(".grid_plugins_element_OrderItem").comboList('showPanel');
	}
});

function getGridUrl(){
	var url = "findOrderItemsGrid.do?";
	var applyerId = $("#applyerId").val();
	if(StringUtils.isNotEmpty(applyerId)){
		url += "applyId="+applyerId;
	}else{
		url += "applyId=";
	}
	var id = $("#id").val();
	if(StringUtils.isNotEmpty(id)){
		url += "&id="+id;
	}
	var priceId = $("#priceId").val();
	if(StringUtils.isNotEmpty(priceId)){
		url += "&priceId="+priceId;
	}
	var productType = $("#productType").val();
	if(StringUtils.isNotEmpty(productType)){
		url += "&productType="+productType;
	}
	return url;
}

