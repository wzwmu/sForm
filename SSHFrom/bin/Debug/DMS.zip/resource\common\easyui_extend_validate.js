$.fn.errorMessage={
		  message:"请填写信息",
		  email:"请输入正确的email地址",
          url  :"请输入正确的url地址",
		  length:"输入的值应介于 {0} 和 {1}之间",
		  json:"请核对字段信息",
		  minLength:"输入的信息不能少于{0} 个.",
		  maxLength:"输入的信息不能多于{0} 个.",
          mobile:"请输入正确的手机号码.",
          phone:"格式不正确,请使用下面格式:020-88888888",
          equalTo:"密码不一致请新输入",
          idcard:"身份证号码格式不正确",
          intOrFloat:"请输入正确的值",
          number:"请输入数字"
		};
$.fn.validatebox.defaults={required:false,validType:null,delay:200,missingMessage:$.fn.errorMessage.message,invalidMessage:null,tipPosition:"right",deltaX:0,tipOptions:{showEvent:"none",hideEvent:"none",showDelay:0,hideDelay:0,zIndex:"",onShow:function(){$(this).tooltip("tip").css({color:"#000",borderColor:"#CC9933",backgroundColor:"#FFFFCC"});},onHide:function(){$(this).tooltip("destroy");}},rules:{email:{validator:function(_3e8){return /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/i.test(_3e8);},message:$.fn.errorMessage.email},url:{validator:function(_3e9){return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(_3e9);},message:$.fn.errorMessage.url},length:{validator:function(_3ea,_3eb){var len=$.trim(_3ea).length;return len>=_3eb[0]&&len<=_3eb[1];},message:$.fn.errorMessage.length},remote:{validator:function(_3ec,_3ed){var data={};data[_3ed[1]]=_3ec;var _3ee=$.ajax({url:_3ed[0],dataType:"json",data:data,async:false,cache:false,type:"post"}).responseText;return _3ee=="true";},message:$.fn.errorMessage.json}}};
//验证扩展例子；至少输入n个字符
$.extend($.fn.validatebox.defaults.rules, { 
minLength: { 
validator: function(value, param){ 
 return $.trim(value).length >= param[0]; 
}, 
message: $.fn.errorMessage.minLength 
} 
}); 
//验证扩展例子；输入不能超过n个字符
$.extend($.fn.validatebox.defaults.rules, { 
maxLength: { 
validator: function(value, param){ 
 return $.trim(value).length <= param[0]; 
}, 
message: $.fn.errorMessage.maxLength 
} 
}); 
//验证固定电话号码
$.extend($.fn.validatebox.defaults.rules, { 
	phone : {
		 validator : function(value) {
	            var regu= /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/;
	            var re=new RegExp(regu);
	            if(re.test(value)){
	            	return true;
	            }
	            else{
	            	return false;
	            	};
	             
		 },
	        message : $.fn.errorMessage.phone
	}
}); 
//验证扩展例子；验证手机号
$.extend($.fn.validatebox.defaults.rules, { 
mobile: { 
validator: function(value,param){ 
    var regu = /^1[3|4|5|8][0-9]\d{8}$/;
    var re = new RegExp(regu);
    if (re.test(value)) {
        return  true;
    }else {
        return false;
    }; 
}, 
message: $.fn.errorMessage.mobile 
} 
}); 
//验证扩展例子；验证身份证
$.extend($.fn.validatebox.defaults.rules, {
	  idcard : {// 验证身份证
	        validator : function(value) {
	            return /^\d{15}(\d{2}[A-Za-z0-9])?$/i.test(value);
	        }, 
        message: $.fn.errorMessage.idcard 
    }
});
//下拉列表非空验证
$.extend($.fn.validatebox.defaults.rules, {
	  selectRequired : {
		  validator : function(value) {
	            return value?true:false;
		  }, 
		  message: $.fn.errorMessage.message 
	  }
});
//验证扩展例子；验证密码
$.extend($.fn.validatebox.defaults.rules, {  
    /*必须和某个字段相等*/
    equalTo: {
        validator:function(value,param){
            return $(param[0]).val() == value;
        },
        message: $.fn.errorMessage.equalTo 
    }
           
});

//验证整数或小数
$.extend($.fn.validatebox.defaults.rules, {  
	intOrFloat : {
	    validator : function(value) {
	        return /^\d+(\.\d+)?$/i.test(value);
	    },
	    message : $.fn.errorMessage.intOrFloat
	}       
});

$.extend($.fn.validatebox.defaults.rules, {
	loginName: {
		validator: function (value, param) {
			if (value.length < param[0]) {
				$.fn.validatebox.defaults.rules.loginName.message = '用户名要' + param[0] + '位数！';
				return false;
			} else {
					var postdata = {};
					
					if (param[3]) {
						postdata[param[2]] = param[3];
					} else {
						postdata[param[2]] = value;
					}
					
					var result = $.ajax({
						url: param[1],
						data: postdata,
						type: 'post',
						dataType: 'json',
						async: false,
						cache: false
					}).responseText;
					if (result == 'false') {
						$.fn.validatebox.defaults.rules.loginName.message = '用户名已存在！';
						return false;
					} else {	
						return true;
					}
				}
		},
		message: ''
	}
});

//验证扩展例子；验证数字
$.extend($.fn.validatebox.defaults.rules, { 
number: { 
validator: function(value,param){ 
    var regu = /^[0-9]+$/;
    var re = new RegExp(regu);
    if (re.test(value)) {
        return  true;
    }else {
        return false;
    }; 
}, 
message: $.fn.errorMessage.number 
} 
});
 
/**
验证用法 class   required validType
class：验证标识
required：可选可选可不选 值为true表示内容不能为空
validType：验证类型 email url等，可以自定义扩展easyui验证规则，如验证手机 mobile
<input   type="text" class="easyui-validatebox" required="true" validType="mobile" />
*/

