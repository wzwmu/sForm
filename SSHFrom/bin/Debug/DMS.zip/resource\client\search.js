function change(type) {
	if (type == 'g') {
		$("#provinceId_combo").val("");
		$("#provinceId").empty();
		$("#cityId_combo").val("");
		$("#cityId").empty();
		$("#countyId_combo").val("");
		$("#countyId").empty();
	} else if (type == 's') {
		$("#cityId_combo").val("");
		$("#cityId").empty();
		$("#countyId_combo").val("");
		$("#countyId").empty();
	} else if (type == 'c') {
		$("#countyId_combo").val("");
		$("#countyId").empty();
	}
};
  

$(function(){
	$("#provinceId").enumeration({
		typecode : 'STATE_ABBREV',
		clear:true,
		onchange : function() {
			change('s');
		}
	});
	$("#cityId").enumeration({
		typecode : 'TCBJ_CITY',
		dependence : '#provinceId',
		clear:true,
		onchange : function() {
			change('c');
		}
	});
	$("#countyId").enumeration({
		typecode : 'COUNTY',
		clear:true,
		dependence : '#cityId'
	});
	$("#bigAreaId").allBigAreas({
		onchange:function(){
			$("#areaId").val("");
			$("#areaId_combo").val("");
		}
		,clear:true
	});
	$("#areaId").areas({
		prmNames: {
			parentAreaId:"#bigAreaId"
		},clear:true
	});
	$("#objectId").contacts({
		clear : true,
		editable:true
	});

});


