(function( $, undefined ) {
	
	
	$.widget("ui.comboTree",$.ui.combo, {
		options:{ 
			
			keyHandler:{
			}
			
		},
		_onMoveDown:function(){

		},
		_onMoveUp:function(){

		},
		_onClick:function(){
			if(this._isPanelShow())
				return;
			this._show();
		},
		_onArrowDown:function(){
			if(this._isPanelShow())
				return;
			this._show();
		},
		_onEnter:function(){
			/*this._hidePanel();
			var row = this.contentPanel.find(".list-item.focus");
			if(row.length>0){
				this._setValue(row);
			}
			
			//if(this.options.onChange&&this.options.onChange!=null){
			//	this.options.onChange.apply(this,[]);
			//}
			
			if(this.options.onChange) this.options.onChange(row.attr("val"), row.html());
			*/
		},
		_onBlur:function(event){
			
			if(this.options.validate&&this.options.validate==true){
				
				var val = $.trim(this.element.val());
				
				var json = this._getCacheJson();
				
				if(json){
				
					for(var i = 0; i < json.length; i++){
						
						if(json[i].name == val){
							
							this.element.val(json[i].name);
							this.element.attr("val", json[i].id);  
							
							return;
						}
					}
				}
				
				this.element.val("");
				this.element.attr(""); 

				if(this.options.onChange) this.options.onChange("", "");
			}
		},
		_setValue:function(node){
			this.element.val(node.name);
			this.element.attr("val", node.id);
			this.element.focusEnd();   
			var select = this.element.parent().children("select");
			if(select.length>0){
				select.empty();
				var option = $("<option></option>");
				option.html(node.name);
				option.val(node.id);
				select.append(option);
			}
			 
		},
		_onChange:function(){
			this._show(this.element.val());
		},
		_onShowPanel:function(){
			//this._load();
		},
		_show:function(condition){
			if(this.options.selectable!=null&&this.options.selectable==false){
				return;
			}
			//alert(condition);
			this._showPanel();
			var that = this;
			this._loadJson(condition,function(json){
				//var datas = json;
				//datas = that._filterData(datas,condition);
				that.____show(json, condition);
				that._resetScroll();
			});
		},
		____show:function(datas, condition){
			if(datas==null)
				return;
			
			this._addRowData(datas, condition);

		},
		getSelectedRowData:function(){
			var val = this.getVal();
			var json = this._getCacheJson();
			var getColValueModel = function(colModel){
				for(var i=0;i<colModel.length;i++){
					var model = colModel[i];
					if(model.isValue&&model.isValue==true)
						return model.name;
				}
				return colModel[0].name;
			}
			if(json){
				var datas = json[this.options.jsonReader.root];
				if(datas&&datas!=null){
					for(var i=0;i<datas.length;i++){
						var data = datas[i];
						if(data[getColValueModel(this.options.colModel)]==val)
							return data;
					}
				}
			}
			return null;
		},
		addRowData:function(data){
			var json = this._getCacheJson();
			if(json){
				var datas = json[this.options.jsonReader.root];
				if(datas&&datas!=null){
					datas[datas.length]=data;
					this._addRowData(data);
				}
			}
		},
		_addRowData:function(zNodes, condition){	
			
			if(this.options.colModel==undefined)
				return;
			
			var that = this;
			
			this.contentPanel.append($("<div id='treeDemo' class='ztree'/>"));
			
			var setting = {
							data: {
								simpleData: {
									enable: true
								}
							},
							callback: {
								onClick: function(e, treeId, treeNode) {
									that._hidePanel();
									that._setValue(treeNode);
						        	that.element.focus();
						        	
						        	if(that.options.onChange) 
						        		that.options.onChange(treeNode.id, treeNode.name);
								}
							}
						 };
			 
			var treeObj = $.fn.zTree.init($("#treeDemo"), setting, zNodes);
			
			$("#treeDemo").click(function(event){
	        	event.stopPropagation();
	        });
			
			if(!condition) return;
			
			var pNode = null, isMatchNode = false;
			
			for(var i = 0; i < zNodes.length; i++){
				
				if(zNodes[i].name.indexOf(condition) >= 0){
					
					pNode = treeObj.getNodeByParam("id", zNodes[i].pId);
					
					if(pNode && pNode.isHidden){
						
						treeObj.showNode(pNode);
						treeObj.expandNode(pNode, true, true, true);
					}
					
					treeObj.showNode(treeObj.getNodeByParam("id", zNodes[i].id));
					isMatchNode = true;
					
				}else{
					treeObj.hideNode(treeObj.getNodeByParam("id", zNodes[i].id));
				}
			}
			

			if(!isMatchNode){
				var row = $("<div class='list-item'>没有找到匹配的信息</div>");
				this.contentPanel.append(row);
				row.click(function(event){
					event.stopPropagation();
				});
			}

		},
		_resetScroll:function(row,type){
			var contentPanel = this.contentPanel; 
			if(type=='down'){
				if((row.position().top+row.outerHeight())>contentPanel.innerHeight()){
					contentPanel.scrollTop(
						row.position().top+row.outerHeight()+contentPanel.scrollTop()-contentPanel.innerHeight()
					);
				}
			}else if(type=='up'){
				//alert(row.position().top+":"+this.popupEle.scrollTop());
				if(row.position().top<0){
					contentPanel.scrollTop(
							contentPanel.scrollTop()+row.position().top
					);
				}
			}else{
				contentPanel.scrollTop(0);
			}
		},
		showPanel:function(val){
			/*
			var elementWidth = this.element.outerWidth();
			var containerWidth = this.element.parent().parent().parent().width();
			if(elementWidth>containerWidth){
				this.element.width(this.element.width()-(elementWidth-containerWidth));
			}*/
			this._show();
		},
		hidePanel:function(val){
			/*
			var elementWidth = this.element.outerWidth();
			var containerWidth = this.element.parent().parent().parent().width();
			if(elementWidth>containerWidth){
				this.element.width(this.element.width()-(elementWidth-containerWidth));
			}*/
			this._hidePanel();
		},
		selectByText:function(){
			this.element.select();
		}, 
		getVal:function(){
			return this.element.attr("val");
		},
		getText:function(){
			return this.element.val();
		},
		initData:function(){
			var that = this;
			var select = that.element.parent().find("select");
			if(select.size()<1)
				return;
			this._loadJson("",function(){
				var val = select.val();
				//填充值
				//alert(that.options.initLoad);
				if(1==1/*StringUtils.isNotEmpty(val)*/){
					
					var json = that._getCacheJson();
					
					for(var i = 0; i < json.length; i++){
						
						if(json[i].id == val){
							
							that.element.val(json[i].name);
							that.element.attr("val", json[i].id);  
							
							return;
						}
					}
					
					//自动填充值
					/*var data = that.getDataByVal(val);
					if(data!=null){
						var str = "";
						for(var j=0;j<that.options.colModel.length;j++){
							if(!that.options.colModel[j])
								continue;
							if(that.options.colModel[j].isValue&&that.options.colModel[j].isValue==true)
								continue;
							str+=data[that.options.colModel[j].name];
							if(j<that.options.colModel.length-1)
								str += " ";
						}
						that.element.val(str);
					}*/
				}
			});
		}
	});


}( jQuery ) );