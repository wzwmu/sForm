$(document).ready(function(){
	var colstemp = CheckVouchItemCols;
	if($("#vouchTypeTemp").val()=='monthVouch') {
		colstemp = CheckVouchItemColsMonth;
	}else if($("#vouchTypeTemp").val()=='snBatchVouch'){
		colstemp = CheckVouchItemSnBatch;
	}
	$('#CheckVouchItemGrid').grid({	datatype: 'local',	dataSource:checkVouchItemItems,	multiselect: false,	multiboxonly:false,	initRows:1,	autowidth:true,	autoResize:false,	autoResizeHeight:false,	colModel:colstemp, });
	
	$("#detail").click(function(){
		var id=$('input[name="id"]').val();
		window.location.href="scanList.do?vocuId="+id;
	});
});
var CheckVouchItemColsMonth = [ {
	name : 'productId',
	label : '产品编号ID',
	editable : true,
	hidden : true
}, {
	name : 'no',
	label : '产品编号',
	editable : true,
	hidden : false
}, {
	name : 'productName',
	label : '产品名称',
	editable : true,
	hidden : false
}/*, {
	name : 'secondSnapshootQuantity',
	label : '第二次快照数量',
	editable : true,
	hidden : false
}*/, {
	name : 'unitCode',
	label : '单位',
	editable : false,
	hidden : false
}, {
	name : 'snapshootQuantity',
	label : '库存',
	editable : true,
	hidden : false
}, {
	name : 'realityQuantity',
	label : '实盘数量',
	editable : true,
	hidden : false
}, {
	name : 'differenceQuantity',
	label : '差异数量',
	editable : true,
	hidden : false
},{
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
}, {
	"align" : "center",
	"editable" : false,
	"fixed" : true,
	"hidden" : true,
	"label" : "操作",
	"name" : "operation",
	"sortable" : false,
	"width" : 60
} ];

var CheckVouchItemCols = [ {
	name : 'productId',
	label : '产品编号ID',
	editable : true,
	hidden : true
}, {
	name : 'no',
	label : '产品编号',
	editable : true,
	hidden : false
}, {
	name : 'productName',
	label : '产品名称',
	editable : true,
	hidden : false
}/*, {
	name : 'secondSnapshootQuantity',
	label : '第二次快照数量',
	editable : true,
	hidden : false
}, {
	name : 'differenceQuantity',
	label : '差异数量',
	editable : true,
	hidden : false
}*/,{
	name : 'unitCode',
	label : '单位',
	editable : false,
	hidden : false
}, {
	name : 'snapshootQuantity',
	label : '库存',
	editable : true,
	hidden : false
}, {
	name : 'realityQuantity',
	label : '实盘数量',
	editable : true,
	hidden : false
}, {
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
}, {
	"align" : "center",
	"editable" : false,
	"fixed" : true,
	"hidden" : true,
	"label" : "操作",
	"name" : "operation",
	"sortable" : false,
	"width" : 60
} ];



var CheckVouchItemSnBatch= [ {
	name : 'productId',
	label : '产品编号ID',
	editable : true,
	hidden : true
}, {
	name : 'no',
	label : '产品编号',
	editable : true,
	hidden : false
}, {
	name : 'productName',
	label : '产品名称',
	editable : true,
	hidden : false
},{
	name : 'unitCode',
	label : '单位',
	editable : false,
	hidden : false
},{
	name : 'batchNo',
	label : '批次',
	editable : false,
	hidden : false
}, {
	name : 'snapshootQuantity',
	label : '库存',
	editable : true,
	hidden : false
}, {
	name : 'realityQuantity',
	label : '实盘数量',
	editable : true,
	hidden : false
}, {
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
}, {
	"align" : "center",
	"editable" : false,
	"fixed" : true,
	"hidden" : true,
	"label" : "操作",
	"name" : "operation",
	"sortable" : false,
	"width" : 60
} ];
