$(document).ready(function(){
	
	$(".submit").click(function(){
		$("#addressGridM").editgrid("blur");
		$("#addressGridError").html("");
		
		if(validate()==false || validateGrid()==false)
			return;
		
		var data = FormUtils.getSubmitData($(document));
		data.addresses = $("#addressGridM").editgrid("getEffectiveRowData","addressTypeCode");
		//alert(JSON.stringify(data.addresses));
		
		var dlg = null;
		Ajax.post({
			url: "editPartner.do",
			data: data,
			contentType:"application/json;charset=utf-8",
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success: function(rtn){
				var	title = "<div class='title'>客户修改成功,您可以继续选择下面的操作：</div>";
				var ctn = title +
						 "<div class='row'><a href=\'apply.do\'>添加新的客户</a></div>" +
						 "<div class='row'><a href=\'applys.do\'>返回客户列表</a> （<i>5秒后自动选择</i>）</div>";
				ResultUtils.showSuccess({
					dialog:dlg,
					width:400,
					height:150,
					timer:{
						second:5,
						callback:function(){ 
							window.location.href='applys.do';
						}
					},
					content:ctn
				});
			},   
			error: function(errors){
				var msg = errors[0].message;
				var ctn = "<div class='title'>客户修改失败,具体原因如下：</div>"+
				 "<div class='row'>"+msg+"</div>";
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
			}
		});
	});
});