	$(document).ready(function(){
		initMenus();
		initlayouter();
		initEvent();
	});
	$(window).resize(function(){
		initlayouter();
	});
	function initEvent(){
		$(".u-identity").mouseover(function(){
			$(this).addClass("over");
			$(this).children(".sel").show();
		}).mouseout(function(){
			$(this).removeClass("over");
			$(this).children(".sel").hide();
		});
		$(".u-identity li").mouseover(function(){
			if(!$(this).hasClass("focus"))
				$(this).addClass("over");
		}).mouseout(function(){
			$(this).removeClass("over");
		});
	}
	var currentA = null;
	function initMenus(){
		$.each($(".menu div"),function(i,n){
			var div = $(n);
			div.mouseover(function(){
				$(this).addClass("over");
			}).mouseout(function(){
				$(this).removeClass("over");
			});
			div.click(function(){
				var menu = div.parent();
				if(div.hasClass("focus")){
					if(!div.hasClass("icon_1")){
						menu.removeClass("focus");
						div.removeClass("focus");
					}
					$("ul").hide();
					return;
				}
				$(".menu,.menu div").removeClass("focus");
				$("ul").hide();
				menu.addClass("focus");
				div.addClass("focus");
				menu.children("ul").show();
			});
		});
		$.each($("a"),function(i,n){
			var a = $(n);
			a.click(function(){
				if(currentA!=null)
					currentA.removeClass("foc");
				a.addClass("foc");
				currentA = a;
			});
		});
	}
	function initlayouter(){
		var left = $("#g_left");
		//var center = $("#g_center");
		var right = $("#g_right");
		var ifr = $("#u_iframe");

		//var height = document.body.scrollHeight - 155;
		
		//var height = $(window).height()-76;

		//alert( $(document.body).innerHeight());
		var height = $(document).innerHeight()-76;

		left.height(height);
		//center.height(height);
		right.height(height);
		//ifr.height(height);
//		$("#tree").height(height+100);
//		$("#m_g_right").height(height+104);
//		$("#m_u_iframe").height(height+109);
		
	}
	
	function go(url){
		$("#u_iframe").attr("src",url);
	}
	
	function logout(){
		if(confirm("您要安全退出系统吗?")){
			window.location.href = "logout.do";
		}
	}
	
	function getTotalHeight(){
        
        if($.browser.msie){
            return document.compatMode == "CSS1Compat"? document.documentElement.clientHeight :
                     document.body.clientHeight;
        }else{
            return self.innerHeight;
        }
    }
