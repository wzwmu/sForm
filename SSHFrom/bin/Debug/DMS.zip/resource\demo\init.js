$(document).ready(function(){
	
	$("#roleType").enumeration({
		typecode : 'TCBJ_PERSON_TYPE_CD'
	});
	
	
	//新增
	$(".save").click(function(){
		if(validate()==false)
			return;
		var data = FormUtils.getSubmitData($(document));
		
		var dlg = null;
		Ajax.post({
			url: "add.do",
			data: data,
			contentType:"application/json;charset=utf-8",
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success: function(rtn){
				var ctn = "<div class='title'>数据新增成功,您可以继续选择下面的操作：</div>";
				ctn = ctn + "<div class='row'><a href=\'add.do\'>继续新增</a></div>";
				ctn = ctn + "<div class='row'><a href=\'list.do\'>返回数据列表</a>(5 秒钟之后自动选择)</div>";
				ResultUtils.showSuccess({
					dialog:dlg,
					timer:{
						second:5,
						callback:function(){ 
							window.location.href='list.do';
						}
					},
					content:ctn
				});
			},   
			error: function(errors){
				var msg = errors[0].message;
				var ctn = "<div class='title'>数据新增失败,具体原因如下：</div>"+
				 "<div class='row'>"+msg+"</div>";
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
				
			}
		});
	});
	
	
	//修改
	$(".submit").click(function(){
		if(validate()==false)
			return;
		var data = FormUtils.getSubmitData($(document));
		
		var dlg = null;
		Ajax.post({
			url: "edit.do",
			data: data,
			contentType:"application/json;charset=utf-8",
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success: function(rtn){
				var ctn = "<div class='title'>角色修改成功,您可以继续选择下面的操作：</div>";
				ctn = ctn + "<div class='row'><a href=\'add.do\'>填写其他角色</a></div>";
				ctn = ctn + "<div class='row'><a href=\'list.do\'>返回角色列表</a>(5 秒钟之后自动选择)</div>";
				ResultUtils.showSuccess({
					dialog:dlg,
					timer:{
						second:5,
						callback:function(){ 
							window.location.href='list.do';
						}
					},
					content:ctn
				});
			},   
			error: function(errors){
				var msg = errors[0].message;
				var ctn = "<div class='title'>角色修改失败,具体原因如下：</div>"+
				 "<div class='row'>"+msg+"</div>";
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
				
			}
		});
	});
	
	
	
	//删除
	$(".delete").click(function(){
		
		var obj = new Object(); 
		obj.id = $(this).attr("date-id");
		
		var dlg = null;
		Ajax.post({
			url: "delete.do",
			data: obj,
			contentType:"application/json;charset=utf-8",
			submitBefore:function(){
				dlg = ResultUtils.showProgress();
			},
			success: function(rtn){
				window.location.href='list.do';
			},   
			error: function(errors){
				
				var msg = errors[0].message;
				var ctn = "<div class='title'>角色删除失败,具体原因如下：</div>"+
				 "<div class='row'>"+msg+"</div>";
				ResultUtils.showError({ 
					dialog:dlg,
					width:400,
					height:150,
					buttons:[{
					    name: '关闭'
					}],
					content:ctn
				});
				
			}
		});
	});
	
	
	$(".demo-add").click(function(){
		$.dialog({ 
			id: '1', 
			title: "新增数据", 
			width: 800, 
			height: 440, 
			lock: true, 
			content:'url:'+base+'/select/selectProduct.do'
		});
	});
	
	
	var api = frameElement.api;
	if(api!=null){
		api.button({
	    	name: '确定',
	        callback: function () {
	            var api = frameElement.api, opener = api.opener;
	            if(!opener.fillProducts)
	            	return;
	            var datas = getSelRowDatas();
	            if(datas==null) return;
	           
	            opener.fillProducts(datas);
	        },
	        focus: true
	    }).button({
	        name: '取消选择',
	        callback: function () {
	       	}
	    });
	}
	
	
});

function validate(){
	return $("#frm").valid();
}
