var selectedGrid;
/**
 * 调用产品选择窗口后,在窗口中选择商品后点击保存会回调该函数
 * @param datas 被选择产品的json对象数组
 *//*
function fillProducts(datas){
	 for(var i=0;i<datas.length;i++){
     	datas[i]["productId"] = datas[i]["id"];
     	datas[i]["productName"] = datas[i]["name"];
     	if(datas[i]["electType"]=='Electronic') {
     		datas[i]["electName"] ="电子";
     	}else if(datas[i]["electType"]=='Nonelectronic') {
     		datas[i]["electName"] ="非电子";
     	}
     	delete datas[i].id;
     }
	
	$("#CheckVouchItemGrid").editgrid("addRowDatas",datas,"productId");
	
}*/
/**
 * 调用产品选择窗口后,在窗口中如果要显示已经被选择的商品,需要提供该函数
 * @return 已经被选择产品的json对象数组
 */
function getRowDatas(){
	return $("#CheckVouchItemGrid").editgrid("getEffectiveRowData","productId");
}

$(document).ready(function(){
	
	initElements();
	
	
	var vouchProductType=$("#vouchProductType").val();
	$("#storageId").comboList({
		dataType:'json',
		url:"../enum/findStorages.do",
	/*	url:"../enum/findStorages.do?ouType="+vouchProductType,*/
		dataCache:false,
		width:'90%',
		validate:true,
		colModel:[
					{name:'id',isValue:true},	
					{name:'storageName',align: "center",isText:true}	
		],
		clear:true,
		onChange:function(){
			//changeGetItem();
		}
	});
	

	$('#frm').validate({
		rules : {
			storageId : {
				minlength:1
			}
		},
		messages : {
			storageId : {
				minlength: '必须选择仓库'
			}
		}
	});
	
	var initRowVal = 0;
	var tempType = $("#vouchTypeTemp").val();
	var colModelVal = CheckVouchItemColsMonth;
	if(tempType=='noneElecNfMonthVouch'){
		//colModelVal = ScanCheckVouchItemCols;
		colModelVal = CheckVouchItemCols;
	}else if(tempType=='noTraceBackNfMonthVouch'){
		colModelVal = CheckVouchItemCols;
		initRowVal = 1;
	}else if(tempType=='monthVouch'){ 
		colModelVal = CheckVouchItemCols; 
	}
	var realScanCellNumber = 0;
	$('#CheckVouchItemGrid').editgrid({
		datatype : 'local',
		dataSource : checkVouchItemItems,
		multiselect : false,
		multiboxonly : false,
		initRows : initRowVal,
		autowidth : true,
		autoResize : true,
		autoResizeHeight : false,
		colModel : colModelVal,
		colOpt:[{url:'statics:insert'},{url:'statics:delete',allowEmpty:false,callback:function(e, rowid, rowData){
			
		},isDelete:function(e,allow, rowid, rowData){
			if(true) {
				if(typeof(allow)!=='undefined'&&allow!=null&&allow==true)
					e.delRow(rowid);
				else
					e.delRowNotEmpty(rowid);
			}/*else if($("#vouchTypeTemp").val()=='scanFillVouch') {
				
			}*/
			/*var id=$('input[name="id"]').val();
			var url = "checkHaveScanDetail.do?vouchId="+id+"&productId="+rowData.productId;
			Ajax.post({
				url: url,
				contentType:"application/json;charset=utf-8",
				success: function(rtn){
					if(rtn==true) {
						var ctn = "<div class='title'>不能删除该产品,具体原因如下：</div>"+
						 "<div class='row'>该产品已有扫码明细!</div>";
						ResultUtils.showError({ 
							dialog:dlg,
							width:400,
							height:150,
							buttons:[{
							    name: '关闭'
							}],
							content:ctn
						});
						return false;
					}
					if(typeof(allow)!=='undefined'&&allow!=null&&allow==true)
						e.delRow(rowid);
					else
						e.delRowNotEmpty(rowid);
				},
				error: function(errors){
					var msg = errors[0].message;
					var ctn = "<div class='title'>操作失败,具体原因如下：</div>"+
					 "<div class='row'>"+msg+"</div>";
					ResultUtils.showError({ 
						dialog:dlg,
						width:400,
						height:150,
						buttons:[{
						    name: '关闭'
						}],
						content:ctn
					});
					return false;
				}
			});*/
		}}],
		formatCell: function(rowid,name,val,iRow,iCol) {
			if(name==='realityQuantity'){
				$("#CheckVouchItemGrid").each(function (){
					var $t = this, nm, tmp,cc, cm;
					cc = $("td:eq("+iCol+")",$t.rows[iRow]);
					var row = $("#CheckVouchItemGrid").editgrid('getRowData',rowid);
					var vouchTypeTemp = $("#vouchTypeTemp").val();
					var vouchProductType=$("#vouchProductType").val(); 
					if((row.canZs=='Y' && vouchProductType=='NF')) {
						$("td:eq("+$t.p.iCol+")",$t.rows[$t.p.iRow]).removeClass("edit-cell ui-state-highlight");
						$($t.rows[$t.p.iRow]).removeClass("selected-row ui-state-hover");
						cc.addClass("not-editable-cell");
					}
				});
			}
        },
		beforeEditCell:function(rowId, name, val, iRow, iCol) {
			if(name==='realityQuantity'){
				$("#CheckVouchItemGrid").each(function (){
					var $t = this, nm, tmp,cc, cm;
					cc = $("td:eq("+iCol+")",$t.rows[iRow]);
					var row = $("#CheckVouchItemGrid").editgrid('getRowData',rowId);
					var vouchTypeTemp = $("#vouchTypeTemp").val();
					var vouchProductType=$("#vouchProductType").val();
					if((row.canZs=='Y' && vouchProductType=='NF')) {
						/*$(this).removeClass("edit-cell ui-state-highlight");
						$(this).removeClass("selected-row ui-state-hover");
						$(this).addClass("not-editable-cell");
						setTimeout(function () {
							$(this).jqGrid("setRowData",rowId,row);
		                }, 1);
						return false;*/
						$("td:eq("+$t.p.iCol+")",$t.rows[$t.p.iRow]).removeClass("edit-cell ui-state-highlight");
						$($t.rows[$t.p.iRow]).removeClass("selected-row ui-state-hover");
						cc.addClass("not-editable-cell");
					}
				});
			}
			if(name==='productName'){
				var vouchTypeTemp = $("#vouchTypeTemp").val();
				if(vouchTypeTemp!='noneElecNfMonthVouch' && vouchTypeTemp!='noTraceBackNfMonthVouch' && vouchTypeTemp!='monthVouch') {
					setTimeout(function () {
	                	$("#CheckVouchItemGrid").jqGrid('restoreCell', iRow, iCol);
	                }, 1);
					/*this.removeClass("edit-cell ui-state-highlight");
					
					$(".grid_plugins_element_OrderItem").attr("val",val);*/
				}
			}
		},
		gridComplete:function(){
        	if($("#RowGrid").editgrid('getEffectiveRowData').length==0){
        		$("#RowGrid").editgrid('addRowData',{});
        	}
        },afterSaveCell : function(rowId,name,val,iRow,iCol) {
			if(name === 'productName'){
				var combo = GridPlugins.getEdittype("OrderItem").getEle();
				var data = combo.comboList("getDataByText",val);
				if(data == null){return;}
				var canZsName = "";
				if(data.canZs=='Y') {
					canZsName ="扫码";
		     	}else if(data.canZs=='N') {
		     		canZsName ="非扫码";
		     	}
				
				var products = $("#CheckVouchItemGrid").editgrid("getEffectiveRowData","productId");
				if(products.length>0){
					var str="";
					for(var i=0;i<products.length;i++){
						var product = products[i];
						var productId = product['productId'];
						if(productId==data.id) {
							var dlg = ResultUtils.showProgress();
							var ctn = "<div class='title'>产品新增失败,具体原因如下：</div>"+
							 "<div class='row'>已存在该产品！</div>";
							ResultUtils.showError({ 
								dialog:dlg,
								width:400,
								height:150,
								buttons:[{
								    name: '关闭'
								}],
								content:ctn
							});
							var rowData = {
									/*id:	data.id,*/
									no:	"",
									productId:"",
									canZs:"",
									canZsName:"",
									productName:"",
									snapshootQuantity:0
							};
							$(this).jqGrid("setRowData",rowId,rowData);
							return false;
						}
					}
				}
				
				var rowData = {
					/*id:	data.id,*/
					no:	data.no,
					productId:data.id,
					canZs:data.canZs,
					canZsName:canZsName,
					unitCode:data.unitCode,
					snapshootQuantity:data.snapshootQuantity
				};
				$(this).jqGrid("setRowData",rowId,rowData);
			} 
        }
	/*,
		
		afterSaveCell : function(rowId, name, val, iRow, iCol) {
			
			if(name==='realityQuantity'){
				var row = $("#CheckVouchItemGrid").editgrid('getRowData',rowId);
				var differenceQuantity = 0;
				var rowData = {};
				rowData["realityQuantity"]="22";
				if(row.realityQuantity&&row.secondSnapshootQuantity) {
					differenceQuantity = parseInt(row.realityQuantity)- parseInt(row.secondSnapshootQuantity);
					rowData["differenceQuantity"]=differenceQuantity;
				}else{
					rowData["differenceQuantity"]=null;
				};
				//$("#CheckVouchItemGrid").editgrid("setRowData",rowId,rowData);
        	}
			
		}*/
	});
	
	$(".ui-jqgrid-title").click(function(){
		var vouchProductType=$("#vouchProductType").val();
		var vouchType =  $("#vouchTypeTemp").val();
		
		$.dialog({ 
			id: '1', 
			title: "选择产品", 
			width: 800, 
			height: 440, 
			lock: false, 
			content:'url:'+base+'/select/invSelectProduct.do?vouchProductType='+vouchProductType+'&vouchType='+vouchType
		});
	});
	
	$("#frm").on('click',function(event){
		var target =event.srcElement ? event.srcElement :event.target; 
		if($(target).hasClass("not-editable-cell")){
			$(target).removeClass("edit-cell ui-state-highlight");
			$(target).removeClass("selected-row ui-state-hover");
		}
	});
	
});


/*function changeGetItem(){
	var url = "findOrderItems.do?";
	var data = {};
	Ajax.post({
		url: getUrl(),
		data: data,
		contentType:"application/json;charset=utf-8",
		success: function(rtn){
			products = JSON.parse(rtn);
			initGrid("#productGrid","产品",products,"PRODUCT",10,300);
		},
		error: function(errors){
			products = [];
			initGrid("#productGrid","产品",products,"PRODUCT",10,300);
		}
	});
	setNull();
}*/

function validate_table() {
	var products = $("#CheckVouchItemGrid").editgrid("getEffectiveRowData");
	if(products.length>0){
		var str="";
		for(var i=0;i<products.length;i++){
			var product = products[i];
			
			var snapshootQuantity = parseInt(product['snapshootQuantity']);
			var realityQuantity = parseInt(product['realityQuantity']); 
			var vouchType = $("#vouchTypeTemp").val();
			if(vouchType=='monthVouch' && snapshootQuantity<realityQuantity){
				//$("#productGridError").html("第"+(i+1)+"行，实盘数量不能超过库存数量").show();
				//return false;
			}
			
			if(vouchType=='noScanFillVouch' && (product['productName']==null || product['productName']=="")) {
				str=str+"第"+(i+1)+"行，未选择产品！<br>";
			}
				
			if(product['realityQuantity'] && product['realityQuantity']==null || product['realityQuantity']=="" ){
				str=str+"第"+(i+1)+"行，实盘数量不能为空！<br>";
			}else if(vouchType=='noTraceBackNfMonthVouch'&&realityQuantity<0) {
				str=str+"第"+(i+1)+"行，实盘数量不能小于0<br>";
			}
		}
		if(str!="") {
			$("#productGridError").html(str).show();
			return false;
		}
	}else{
		$("#productGridError").html("产品不能为空").show();
		return false;
	}
	$("#productGridError").hide();
	return true;
}

/*function validate_quantity(rowData,iRow){
	var itemQuantityCount = parseInt(rowData['itemQuantityCount']);
	var realityQuantity = parseInt(rowData['realityQuantity']);
	var type = $("#vouchTypeTemp").val();
	if(type=='scanFillVouch' && itemQuantityCount!=0 && itemQuantityCount>realityQuantity){
		$("#productGridError").html("第"+(iRow)+"行，实际盘点明细数量超过实际盘点总数量").show();
		return false;
	}else if(type=='noScanFillVouch'&&realityQuantity<=0){						
		$("#productGridError").html("第"+(iRow)+"行，补盘时盘点数量不能小于1").show();
		return false;
	}else{
		$("#productGridError").hide();
		return true;
	}
}*/
var ScanCheckVouchItemCols = [ {
	name : 'productId',
	label : '产品编号ID',
	editable : false,
	hidden : true
}, {
	name : 'itemQuantityCount',
	label : '明细总数',
	editable : false,
	hidden : true
},{
	name : 'no',
	label : '产品编号',
	editable : false,
	hidden : false
}, {
	name : 'productName',
	label : '产品全称',
	edittype:'OrderItem',
	editable:true,
	sortable : false
},{
	name : 'canZs',
	label : '是否扫码产品',
	editable : false,
	hidden : true
},{
	name : 'canZsName',
	label : '是否扫码产品',
	editable : false,
	hidden : false
},{
	name : 'unitCode',
	label : '单位',
	editable : false,
	hidden : false
},{
	name : 'electName',
	label : '产品类型',
	editable : false,
	hidden : true
}, {
	name : 'snapshootQuantity',
	label : '库存',
	editable : false,
	hidden : false
}, {
	name : 'realityQuantity',
	label : '实盘数量',
	editable : true,
	formatter:"currency",
	formatoptions:{decimalPlaces:0,showZero:true},
	hidden : false
} /*,{
	name : 'secondSnapshootQuantity',
	label : '第二次快照数量',
	editable : false,
	hidden : false
}, {
	name : 'differenceQuantity',
	label : '差异数量',
	editable : false,
	hidden : false
}*/, {
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
}];


var CheckVouchItemCols = [ {
	name : 'productId',
	label : '产品编号ID',
	editable : false,
	classes: "productId",
	hidden : true
}, {
	name : 'itemQuantityCount',
	label : '明细总数',
	editable : false,
	hidden : true
},{
	name : 'no',
	label : '产品编号',
	editable : false,
	hidden : false
}, {
	name : 'productName',
	label : '产品全称',
	edittype:'OrderItem',
	editable:true,
	sortable : false
},{
	name : 'canZs',
	label : '是否扫码产品',
	editable : false,
	hidden : true
},{
	name : 'canZsName',
	label : '是否扫码产品',
	editable : false,
	hidden : false
},{
	name : 'unitCode',
	label : '单位',
	editable : false,
	hidden : false,
	classes : 'enter_column',
	edittype : 'productUnit'
},{
	name : 'electName',
	label : '产品类型',
	editable : false,
	hidden : true
}, {
	name : 'snapshootQuantity',
	label : '库存',
	editable : false,
	hidden : false
}, {
	name : 'realityQuantity',
	label : '实盘数量',
	editable : true,
	formatter:"currency",
	formatoptions:{decimalPlaces:0,showZero:true},
	hidden : false
} /*,{
	name : 'secondSnapshootQuantity',
	label : '第二次快照数量',
	editable : false,
	hidden : false
}, {
	name : 'differenceQuantity',
	label : '差异数量',
	editable : false,
	hidden : false
}*/, {
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
}, {
	"align" : "center",
	"editable" : false,
	"fixed" : true,
	"hidden" : false,
	"label" : "操作",
	"name" : "operation",
	"sortable" : false,
	"width" : 60
} ];

var CheckVouchItemColsMonth = [ {
	name : 'productId',
	label : '产品编号ID',
	editable : false,
	hidden : true
}, {
	name : 'itemQuantityCount',
	label : '明细总数',
	editable : false,
	hidden : true
},{
	name : 'no',
	label : '产品编号',
	editable : false,
	hidden : false
}, {
	name : 'productName',
	label : '产品全称',
	edittype:'OrderItem',
	editable:true,
	sortable : false
},{
	name : 'canZs',
	label : '是否扫码产品',
	editable : false,
	hidden : true
},{
	name : 'canZsName',
	label : '是否扫码产品',
	editable : false,
	hidden : false
},{
	name : 'unitCode',
	label : '单位',
	editable : false,
	hidden : false
},{
	name : 'electName',
	label : '产品类型',
	editable : false,
	hidden : true
}, {
	name : 'snapshootQuantity',
	label : '库存',
	editable : false,
	hidden : false
}, {
	name : 'realityQuantity',
	label : '实盘数量',
	editable : true,
	formatter:"currency",
	formatoptions:{decimalPlaces:0,showZero:true},
	hidden : false
} /*,{
	name : 'secondSnapshootQuantity',
	label : '第二次快照数量',
	editable : false,
	hidden : false
}, {
	name : 'differenceQuantity',
	label : '差异数量',
	editable : false,
	hidden : false
}*/, {
	name : 'id',
	label : '主键',
	editable : false,
	hidden : true
} ];


GridPlugins.edittypes.push({
	getEle : function() {
		return $('.grid_plugins_element_OrderItem');
	},
	name : 'OrderItem',
	element : function(value, options) {
		var elem = $('.grid_plugins_element_OrderItem');
		if (elem.length == 0) {
			elem = $("<input type='text' class='grid_plugins_element_OrderItem textbox' style='width:100%'>");
			var container = $("#grid_plugins_element_container");
			if (container.length == 0) {
				container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
				$(document.body).append(container);
				container.append(elem);
			}
			// 初始化下拉组件
			elem.comboList({
				dataType:'json', 
				url:getGridUrl(),
				dataCache:true,
				validate : true,
				autoWidth : true,
				jsonReader : {
					root : null
				},
				editable : true,
				colModel : [ {
					name : 'productId',
					isValue : true
				}, {
					name : 'productName',
					align : "center",
					isText : true
				} ],
				prmNames : {
					condition : "name"
				}
			});
		}
		elem.val(value);
		return elem.parent()[0];
	},
	value : function(elem, operation, value) {
		if (operation === 'get') {
			$('#grid_plugins_element_container').append(elem);
			$('.grid_plugins_element_OrderItem').comboList('hidePanel');
			$(elem).focus();
			return $('.grid_plugins_element_OrderItem').val();
		} else if (operation === 'set') {
			$('.grid_plugins_element_OrderItem').val(value);
		}
	},
	handle : function() {
	},
	show : function() {
		$(".grid_plugins_element_OrderItem").comboList('showPanel');
	}
});

/**
 * 页面加载后对界面元素初始化,主要针对下拉类型
 * @return
 */
function initElements(){
	$(".ui-datepicker-input").datepicker();
	
}

/**
 * 触发表单验证
 * @return
 */
function validate(){
	return $("#frm").valid();
}
/**
 * 触发grid验证
 * @return
 */
function validateGrid(){
	return true;
}

function getGridUrl(){
	var type = $("#vouchProductType").val();
	var storageId = $("#storageIdTemp").val();
//	alert(storageId);
	var vouchTypeTemp=$("#vouchTypeTemp").val();
	var url = "../select/findProductsByType.do?type="+type;
	if(type=='NF' && vouchTypeTemp=='noneElecNfMonthVouch'){
		url = "../select/findNoScanTracProds.do?type="+type+"&vouchType=noneElecNfMonthVouch&storageId="+storageId;
	}else if(type=='NF' && vouchTypeTemp=='noTraceBackNfMonthVouch'){
		url = "../select/findNoScanTracProds.do?type="+type+"&vouchType=noTraceBackNfMonthVouch&storageId="+storageId;
	} else if(['SN','LY'].indexOf(type)>=0){
		url = "../select/findAllProductsByType.do?type="+type+"&storageId="+storageId;
	}
	
	return url;
}

