(function( $, undefined ) {
	
	$.widget("ui.editgrid",$.ui.grid, {
		options:{ 
			multiselect: false,
			multiboxonly:false,
			initRows:6,
			autoResize:true,
			autoResizeHeight:false,
			onselectrow: false,
            footerrow : true,
            userDataOnFooter : true
		},
		/* 在grid基础上把编辑功能打开 */
		_init:function(){
			this.grid.jqGrid('setGridParam',{cellEdit: true});
			
			/* 触发编辑框失去焦点事件 */
			var that = this;
			$(document.body).on('click',function(event){
				var target =event.srcElement ? event.srcElement :event.target;
				if(
						$(target).hasClass("edit-cell")||
						($(target).is("input")&&$(target).closest("td").attr("role")=="gridcell"))
					return;
				that.blur(); 
			});
		}
	});
	

}( jQuery ) );