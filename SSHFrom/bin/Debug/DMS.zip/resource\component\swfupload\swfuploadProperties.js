var upload1;

var uploadUrl = base + "/ueditor/upload.do?saveDataUrl=saveDataUrl1";
var deleteUrl = base + "/ueditor/delete.do";
var flashUrl = base + "/resource/component/swfupload/swfupload.swf";
var flash9Url = base + "/resource/component/swfupload/swfupload_fp9.swf";
var buttonImageUrl = base + "/resource/component/swfupload/images/XPButtonUploadText_61x22.png";

window.onload = function() {
	upload1 = new SWFUpload({
		// Backend Settings
		upload_url : uploadUrl,
		delete_url : deleteUrl,
		
		// Event Handler Settings (all my handlers are in the Handler.js file)
		swfupload_preload_handler : preLoad,
		swfupload_load_failed_handler : loadFailed,
		// Button Settings
		button_image_url : buttonImageUrl,
		button_placeholder_id : "spanButtonPlaceholder1",
		// Flash Settings
		flash_url : flashUrl,
		flash9_url : flash9Url,

		custom_settings : {
			progressTarget : "fsUploadProgress1",
			cancelButtonId : "btnCancel1"
		}
	});

}
