var ReportIndex = {
		
		options:{
			name:'商品',
			focusEle:'#condition'
		},
		gridOptions:{
			url:null,
			datatype: "json",
			arraytype:'list',
			pager:'#pager',
			autoResize:true,
			scrollrows:true,
			rowNum:10,
		   	rowList:[10,20,30],
			colOpts:[],
			colModel:[],
			bind:null
		},
		searchOptions:{
			click:function(e){
				//$("#condition").focus();
				var form = $(this.searchOptions.bind).closest("form");
				form.find("input:first").focus();
				var data = FormUtils.getSubmitData(form);
				//alert(JSON.stringify(data));
				this.grid.jqGrid("setGridParam",{postData:data}).trigger("reloadGrid");
			},
			bind:null
		},
		optOptions:{
			
		},
		init:function(){
			this._initGlobal();
			this._initGrid(this.gridOptions.bind);
			this._initSearchButton(this.searchOptions.bind);
			if(this._init)
				this._init();
		},
		_initGlobal:function(){
			$(this.options.focusEle).focus();
		},
		_initSearchButton:function(bind){
			if(StringUtils.isEmpty(bind))
				return;
			var btn = $(bind);
			var form = btn.closest("form");
			if(form.length>0){
				form.attr("onSubmit","return false;");
			}
			var clearEles = form.find(".clear");
			$.each(clearEles,function(i,n){
				var ele = $(n);
				if(StringUtils.isNotEmpty(ele.val())){
					ele.attr("title",ele.val());
					ele.click(function(){
						if($(this).val()==$(this).attr("title"))
							$(this).val("");
					}).blur(function(){
						if($(this).val()=="")
							$(this).val($(this).attr("title"));
					});
				}
			});
			var that = this;
			btn.on({
				click:function(e){
					that.searchOptions.click.apply(that,[e]);
				}
			});
		},
		_initGrid:function(bind){
			if(StringUtils.isEmpty(bind))
				return;
			this.grid = $(bind);
			this.grid.grid(this.gridOptions);
		}
};