GridPlugins = new function() {
};
GridPlugins.getEdittype = function(name) {
	for ( var i = 0; i < GridPlugins.edittypes.length; i++) {
		var edittype = GridPlugins.edittypes[i];
		try {
			if (edittype.name === name)
				return edittype;
		} catch (e) {

		}

	}
	return null;
};
GridPlugins.edittypes = [		
			{
			getEle : function() {
				return $('.grid_plugins_element_searchshop');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'searchshop',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_searchshop');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_searchshop textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/searchShop.do",
						typecode : '',
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						//panelHeight: 58,
						clear: false,
						editable:true,
						colModel : [ {
										name : 'id',
										isValue : true
									}, {
										name : 'shopName',
										align : "center",
										isText : true
									} ],
						prmNames: {
							/*
							 * 传递到后台查询条件的名称
							 */
							condition:"name"
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_searchshop').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_searchshop').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_searchshop').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_searchshop").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_searchRegion');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'searchRegion',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_searchRegion');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_searchRegion textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.regionTree({
						arrow:{
								hasDownArrow:false,
								alt:'打开下拉菜单',
								callback:function(combo){}
							  },
						width: '100%',
						clear: true,
						typecode : 'ALl'
					});
					
					setTimeout(function(){
						$(".grid_plugins_element_searchRegion").click();
					},200);
					
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					//$('.grid_plugins_element_searchRegion').comboTree('hidePanel');	
					$(elem).focus();
					return $('.grid_plugins_element_searchRegion').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_searchRegion').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				//$(".grid_plugins_element_searchRegion").comboTree('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_fixPriceType');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'fixPriceType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_fixPriceType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_fixPriceType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'fixprice_type',
						onChange : function() {
							setTimeout(function(){
								$("#product_price_grid").editgrid('blur');
							},200);
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						panelHeight: 58,
						clear: true,
						editable:false,
						colModel : [ {
										name : 'name',
										isValue : true
									}, {
										name : 'val',
										align : "center",
										isText : true
									} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_fixPriceType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_fixPriceType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_fixPriceType').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_fixPriceType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_country');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'country',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_country');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_country textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'COUNTRY',
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_country').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_country').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_country').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_country").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_province');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'province',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_province');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_province textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'STATE_ABBREV',
						dependence : function() {
							return "China";
						},
						// dependence:function(){return
						// $(this).parents("td:first").prev("td").prev("td").prev("td").html();},
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_province').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_province').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_province').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_province").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_city');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'city',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_city');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_city textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						dependence : function() {
							return $(this).parents("td:first").prev("td").prev(
									"td").prev("td").html();
						},
						typecode : 'TCBJ_CITY',
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_city').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_city').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_city').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_city").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_county');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'county',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_county');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_county textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						dependence : function() {
							return $(this).parents("td:first").prev("td").prev(
									"td").prev("td").html();
						},
						typecode : 'COUNTY',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_county').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_county').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_county').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_county").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_addresstype');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'addresstype',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_addresstype');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_addresstype textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'ADDR_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_addresstype').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_addresstype').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_addresstype').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_addresstype").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_receivetime');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'receivetime',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_receivetime');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_receivetime textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'TCBJ_RECEIVE_DATE_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_receivetime').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_receivetime').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_receivetime').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_receivetime").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_dutytype');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'dutytype',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_dutytype');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_dutytype textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'CONTACT_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_dutytype').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_dutytype').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_dutytype').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_dutytype").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_contact');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'contact',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_contact');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_contact textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findContacts.do",
						typecode : null,
						validate : true,
						autoWidth : true,
						dataCache : false,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'fullname',
							align : "center",
							isText : true
						} ],
						prmNames : {
							partnerId : function() {
								return $("#parentDealerId").val();
							}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_contact').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_contact').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_contact').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_contact").comboList('showPanel');
			}
		},

		{
			getEle : function() {
				return $('.grid_plugins_element_selectregion');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'selectRegion',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				elem = $("<input type='text' class='grid_plugins_element_selectregion textbox' style='width:100%'>");
				$(document.body).append(elem);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_selectregion').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_selectregion').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_selectregion').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_selectregion").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_applyers');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'applyers',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_applyers');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_applyers textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findApplyers.do",
						typecode : null,
						onchange : function() {
						},
						validate : true,
						dataCache : false,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'applyerId',
							isValue : true
						}, {
							name : 'applyerCode',
							isText : true
						} , {
							name : 'applyerName',
							isText : true
						}],
						prmNames : {
							areaId : function() {
								return $(this).parents("td:first").prev("td").html();
							}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_applyers').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_applyers').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_applyers').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_applyers").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_giftSource');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'giftSource',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_giftSource');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_giftSource textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "TCBJ_GIFT_SOURCE_TYPE",
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_giftSource')
							.comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_giftSource').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_giftSource').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_giftSource").comboList('showPanel');
			}
		},
	{
		getEle : function() {
			return $('.grid_plugins_element_isEnable');
		},
		/*
		 * 扩展编辑插件名称
		 */
		name : 'isEnable',
		/*
		 * 获取编辑插件界面元素
		 */
		element : function(value, options) {
			var elem = $('.grid_plugins_element_isEnable');
			if (elem.length == 0) {
				elem = $("<input type='text' class='grid_plugins_element_isEnable textbox' style='width:100%'>");
				var container = $("#grid_plugins_element_container");
				if (container.length == 0) {
					container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
					$(document.body).append(container);
					container.append(elem);
				}
				// 初始化下拉组件
				elem.comboList({
					dataType : 'json',
					url : "../enum/find.do",
					typecode : "IS_DEFAULT",
					onchange : function() {
					},
					validate : true,
					autoWidth : true,
					jsonReader : {
						/*
						 * 集合的名称
						 */
						root : null
					},
					colModel : [ {
						name : 'name',
						isValue : true
					}, {
						name : 'val',
						align : "center",
						isText : true
					} ]
				});
			}
			elem.val(value);
			return elem.parent()[0];
		},
		/*
		 * 获取或设置编辑插件界面元素值
		 */
		value : function(elem, operation, value) {
			if (operation === 'get') {
				$('#grid_plugins_element_container').append(elem);
				$('.grid_plugins_element_isEnable')
					.comboList('hidePanel');
				$(elem).focus();
				return $('.grid_plugins_element_isEnable').val();
			} else if (operation === 'set') {
				$('.grid_plugins_element_isEnable').val(value);
			}
		},
		/*
		 * 编辑插件编辑完成后触发事件
		 */
		handle : function() {
		},
		/*
		 * 编辑插件界面显示时触发事件
		 */
		show : function() {
			$(".grid_plugins_element_isEnable").comboList('showPanel');
		}
	},
		{
			getEle : function() {
				return $('.grid_plugins_element_locusOfControlName');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'locusOfControlName',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_locusOfControlName');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_locusOfControlName textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "TCBJ_CONTROL_SOURCE_TYPE",
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_locusOfControlName').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_locusOfControlName').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_locusOfControlName').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_locusOfControlName").comboList(
						'showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_controlContentName');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'controlContentName',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_controlContentName');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_controlContentName textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						typecode : "TCBJ_CONTROL_CONTENT",
						dataCache : false,
						dependence : function() {
							return $(this).parents("td:first").prev("td")
									.html();
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_controlContentName').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_controlContentName').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_controlContentName').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_controlContentName").comboList(
						'showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_applyControlName');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'applyControlName',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_applyControlName');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_applyControlName textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "TCBJ_ACTION_TYPE",
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_applyControlName').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_applyControlName').val();
				} else if (operation === 'set') {
					$('.grid_plugins_applyControlName').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_applyControlName").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_applyControl');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'applyControl',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_applyControl');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_applyControl textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "YON",
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_applyControl').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_applyControl').val();
				} else if (operation === 'set') {
					$('.grid_plugins_applyControl').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_applyControl").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_protoType');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'protoType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_protoType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_protoType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "TCBJ_ABILITY_TYPE",
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',isValue : true}, 
							{name : 'val',align : "center",isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_protoType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_protoType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_protoType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_protoType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_testModeName');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'testModeName',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_testModeName');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_testModeName textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "TCBJ_CHECK_METHOD",
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_testModeName').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_testModeName').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_testModeName').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_testModeName").comboList('showPanel');
			}
		},
		{

			getEle : function() {
				return $('.grid_plugins_element_inspectTypeName');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'inspectTypeName',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_inspectTypeName');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_inspectTypeName textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : "TCBJ_CHECK_TYPE",
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_inspectTypeName').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_inspectTypeName').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_inspectTypeName').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_inspectTypeName").comboList(
						'showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_partnerproduct');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'partnerProducts',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_partnerproduct');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_partnerproduct textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// alert($(this).parents("tr:first").html());
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findPartnerProducts.do",
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'name',
							align : "center",
							isText : true
						} ],
						prmNames : {
							applyerId : function() {return $(this).parents("td:first").prev("td").html();}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_partnerproduct').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_partnerproduct').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_partnerproduct').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_partnerproduct")
						.comboList('showPanel');
				// $(".grid_plugins_element_goods").comboList('setOldVal',value);
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_adjustType');
			},
			/*
			 * 扩展编辑插件名称(价格调整类型)
			 */
			name : 'adjustTypes',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_adjustType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_adjustType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'TCBJ_MODIFY_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_adjustType')
							.comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_adjustType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_adjustType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_adjustType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_coefficientType');
			},
			/*
			 * 扩展编辑插件名称(价格系数类型)
			 */
			name : 'coefficientTypes',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_coefficientType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_coefficientType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						typecode : 'TCBJ_COEFFICIENT_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_coefficientType').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_coefficientType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_coefficientType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_coefficientType").comboList(
						'showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_partnerStorage');
			},
			name : 'partnerStorage',
			element : function(value, options) {
				var elem = $('.grid_plugins_element_partnerStorage');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_partnerStorage textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					elem.comboList({
						dataType : 'json',
						url : "../enum/findStorages.do",
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'storageName',
							align : "center",
							isText : true
						} ],
						prmNames : {
							applyerId : function() {
								return $(this).parents("td:first").prev("td")
										.prev("td").prev("td").html();
							}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_partnerStorage').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_partnerStorage').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_partnerStorage').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_partnerStorage")
						.comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_disDelearId');
			},
			name : 'disDelearId',
			element : function(value, options) {
//				var data = FormUtils.getSubmitData("#frm");
				var elem = $('.grid_plugins_element_disDelearId');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_disDelearId textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					elem.comboList({
						dataType : 'json',
						url : "../enum/findApplyers.do",
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'applyerId',
							isValue : true
						}, {
							name : 'applyerName',
							align : "center",
							isText : true
						} ],
						prmNames : {
							applyerId : function() {
								return $("#parentDealerId").val();
							}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_disDelearId').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_disDelearId').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_disDelearId').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_disDelearId").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_customerStorage');
			},
			name : 'customerStorage',
			element : function(value, options) {
//				var data = FormUtils.getSubmitData("#frm");
				var elem = $('.grid_plugins_element_customerStorage');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_customerStorage textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					elem.comboList({
						dataType : 'json',
						url : "../enum/findStorages.do",
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'storageName',
							align : "center",
							isText : true
						} ],
						prmNames : {
							applyerId : function() {
								return $("#applyerId").val();
							}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_customerStorage').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_customerStorage').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_customerStorage').val(value);
				}
			},
			handle : function() {
			},
			show : function() {
				$(".grid_plugins_element_customerStorage").comboList(
						'showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_targetType');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'targetType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_targetType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_targetType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_TARGET_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_targetType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_targetType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_targetType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_targetType").comboList('showPanel');
			}
		}, 
		{
			getEle : function() {
				return $('.grid_plugins_element_resourceType');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'resourceType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_resourceType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_resourceType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_SOURCE_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_resourceType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_resourceType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_resourceType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_resourceType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_expense');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'expense',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_expense');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_expense textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_EXPENSE_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ],
						filter:{
							high:'0,2'
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_expense').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_expense').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_expense').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_expense").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_expenseType');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'expenseType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_expenseType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_expenseType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_EXPENSE_TYPE',
						dependence : function() {
							return $(this).parents("td:first").prev("td").html();
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ],
						filter:{
							high:'0,2'
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_expenseType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_expenseType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_expenseType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_expenseType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_expense_n');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'expense_n',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_expense_n');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_expense_n textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_EXPENSE_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ],
						filter:{
							high:'0,1'
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_expense_n').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_expense_n').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_expense_n').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_expense_n").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_expenseType_n');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'expenseType_n',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_expenseType_n');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_expenseType_n textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_EXPENSE_TYPE',
						dependence : function() {
							return $(this).parents("td:first").prev("td").html();
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ],
						filter:{
							high:'0,1'
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_expenseType_n').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_expenseType_n').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_expenseType_n').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_expenseType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_activityType');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'activityType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_activityType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_activityType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_ACTIVE_TYPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_activityType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_activityType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_activityType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_activityType").comboList('showPanel');
				//$(".grid_plugins_element_goods").comboList('setOldVal',value);
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_activity');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'activity',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_activity');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_activity textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_ACTIVE_SUB_TYPE',
						dependence : function() {
							return $(this).parents("td:first").prev("td").html();
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_activity').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_activity').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_activity').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_activity").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_planShape');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'planShape',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_planShape');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_planShape textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_PLAN_SHAPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_planShape').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_planShape').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_planShape').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_planShape").comboList('showPanel');
				//$(".grid_plugins_element_goods").comboList('setOldVal',value);
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_resource');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'resource',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_resource');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_resource textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_SOURCE_SUB_TYPE',
						dependence : function() {
							return $(this).parents("td:first").prev("td").html();
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_resource').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_resource').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_resource').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_resource").comboList('showPanel');
				//$(".grid_plugins_element_goods").comboList('setOldVal',value);
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_target');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'target',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_target');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_target textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'local',
						url : "../enum/find.do",
						type : 'enum',
						dataCache : false,
						typecode : 'TCBJ_PACT_TARGET_SUB_TYPE',
						dependence : function() {
							return $(this).parents("td:first").prev("td").html();
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_target').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_target').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_target').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_target").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_bigArea');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'bigArea',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_bigArea');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_bigArea textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findAreas.do",
						typecode : null,
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'regionName',
							align : "center",
							isText : true
						} ],
						prmNames : {
							parentAreaId : function() {return $(this).parents("td:first").prev("td").html();}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_bigArea').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_bigArea').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_bigArea').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_bigArea").comboList('showPanel');
			}
		},
		
		
		{
			getEle : function() {
				return $('.grid_plugins_element_employees');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'employees',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_employees');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_employees textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findEmployees.do",
						typecode : null,
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'contactName',
							align : "center",
							isText : true
						} ],
						prmNames : {
							areaId : function() {return $(this).parents("td:first").prev("td").html();}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_employees').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_employees').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_employees').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_employees").comboList('showPanel');
			}
		},
		
		{
			getEle : function() {
				return $('.grid_plugins_element_productType');
			},
			/*
			 * 扩展编辑插件名称------产品类型
			 */
			name : 'productType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_productType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_productType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findProductCategorys.do",
						onchange : function() {
						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'name',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_productType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_productType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_productType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_productType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_productSubType');
			},
			/*
			 * 扩展编辑插件名称-------产品子类型
			 */
			name : 'productSubType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_productSubType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_productSubType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findProductCategorys.do",
						type : 'enum',
						dataCache : false,
//						dependence : function() {
//							return $(this).parents("td:first").prev("td").html();
//						},
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'name',
							align : "center",
							isText : true
						} ],
						prmNames : {
							pid : function() {
								var pid = $(this).parents("td:first").prev("td").html();
								return pid;
							},
							type : function(){
								return "sub";
							}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_productSubType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_productSubType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_productSubType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_productSubType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_ability');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'abilitys',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_ability');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_ability textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// alert($(this).parents("tr:first").html());
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/findPartnerAbilitys.do",
						dataCache : false,
						validate : true,
						autoWidth : true,
						jsonReader : {
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'prototypeName',
							align : "center",
							isText : true
						} ],
						prmNames : {
							year : function() {
									var year = "0";
									if($(this).parents("td:first").prev("td").html()!="" || $(this).parents("td:first").prev("td").html() != null){
										year = $(this).parents("td:first").prev("td").html();
									}
									return year;
								}
						}
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_ability').comboList(
							'hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_ability').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_ability').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件
			 */
			show : function() {
				$(".grid_plugins_element_ability")
						.comboList('showPanel');
			}
		},{
			getEle : function() {
				return $('.grid_plugins_element_scope');
			},
			/*
			 * 扩展编辑插件名称
			 */
			name : 'scope',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_scope');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_scope textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType : 'json',
						url : "../enum/find.do",
						dataCache : false,
						typecode : 'APPLY_SCOPE',
						validate : true,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_scope').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_scope').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_scope').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_scope").comboList('showPanel');
			}
		},{
			getEle : function() {
				return $('.grid_plugins_element_OrderItemType');
			},
			/*
			 * 订单明细类型
			 */
			name : 'OrderItemType',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_OrderItemType');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_OrderItemType textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType:'local',
						dataCache : true,
						typecode:null,
						dataSource:[{name:1,val:'正常'},{name:2,val:'赠品'},{name:7,val:'临期'}/*,{name:3,val:'补货'}*/],
						validate : true,
						editable:false,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'name',
							isValue : true
						}, {
							name : 'val',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_OrderItemType').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_OrderItemType').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_OrderItemType').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_OrderItemType").comboList('showPanel');
			}
		},
		{
			getEle : function() {
				return $('.grid_plugins_element_supplieres');
			},
			/*
			 * 选择供货商
			 */
			name : 'supplieres',
			/*
			 * 获取编辑插件界面元素
			 */
			element : function(value, options) {
				var elem = $('.grid_plugins_element_supplieres');
				if (elem.length == 0) {
					elem = $("<input type='text' class='grid_plugins_element_supplieres textbox' style='width:100%'>");
					var container = $("#grid_plugins_element_container");
					if (container.length == 0) {
						container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
						$(document.body).append(container);
						container.append(elem);
					}
					// 初始化下拉组件
					elem.comboList({
						dataType:'json',
						url:"../enum/findSupplieres.do",
						validate:true,
						typecode:null,
						dataCache : true,
						editable:false,
						autoWidth : true,
						jsonReader : {
							/*
							 * 集合的名称
							 */
							root : null
						},
						colModel : [ {
							name : 'id',
							isValue : true
						}, {
							name : 'name',
							align : "center",
							isText : true
						} ]
					});
				}
				elem.val(value);
				return elem.parent()[0];
			},
			/*
			 * 获取或设置编辑插件界面元素值
			 */
			value : function(elem, operation, value) {
				if (operation === 'get') {
					$('#grid_plugins_element_container').append(elem);
					$('.grid_plugins_element_supplieres').comboList('hidePanel');
					$(elem).focus();
					return $('.grid_plugins_element_supplieres').val();
				} else if (operation === 'set') {
					$('.grid_plugins_element_supplieres').val(value);
				}
			},
			/*
			 * 编辑插件编辑完成后触发事件
			 */
			handle : function() {
			},
			/*
			 * 编辑插件界面显示时触发事件 
			 */
			show : function() {
				$(".grid_plugins_element_supplieres").comboList('showPanel');
			}
		},
	{
		getEle : function() {
			return $('.grid_plugins_element_productUnit');
		},
		/*
		 * 订单选择单位
		 */
		name : 'productUnit',
		element : function(value, options) {
			var elem = $('.grid_plugins_element_productUnit');
			if (elem.length == 0) {
				elem = $("<input type='text' class='grid_plugins_element_productUnit textbox' style='width:100%'>");
				var container = $("#grid_plugins_element_container");
				if (container.length == 0) {
					container = $("<div id='grid_plugins_element_container' style='display:none;'/>");
					$(document.body).append(container);
					container.append(elem);
				}
				
				// 初始化下拉组件
				elem.comboList({
					dataType : 'json',
					url : "../enum/findproductUnit.do",
//					dataType : 'local',
//					dataSource:function(){
//						var productUnitName = $(this).parents("td:first").parent("tr").find(".productUnitName").html();
//						var primayUnitName = $(this).parents("td:first").parent("tr").find(".primayUnitName").html();
//						return '[{id:'+productUnitName+',name:'+productUnitName+'},{id:'+primayUnitName+',name:'+primayUnitName+'}]';
//					},
					type : 'enum',
					validate : true,
					typecode : null,
					dataCache : false,
					editable : false,
					autoWidth : true,
					panelHeight : 80,
					onChange: function(){
						
						setTimeout(function(){//用于自动释放编辑状态
							if("undefined" != typeof autoBlurEidt){ 
								autoBlurEidt();
							}
						},200);
					},
					filter: function(datas){
						
					},
					filterData: function(datas){
						if("undefined" != typeof filterDataHandle){ 
							return filterDataHandle(datas);
						}else{
							return datas;
						}
					},
					jsonReader : {
						/*
						 * 集合的名称
						 */
						root : null
					},
					colModel : [ {
						name : 'id',
						isValue : true
					}, {
						name : 'name',
						align : "center",
						isText : true
					} ]
					,
					prmNames: {
						id:function(){
							return $(this).parents("td:first").parent("tr").find(".productId").html();
						}
					}
				});
			}
			elem.val(value);
			return elem.parent()[0];
		},
		/*
		 * 获取或设置编辑插件界面元素值
		 */
		value : function(elem, operation, value) {
			if (operation === 'get') {
				$('#grid_plugins_element_container').append(elem);
				$('.grid_plugins_element_productUnit').comboList('hidePanel');
				$(elem).focus();
				return $('.grid_plugins_element_productUnit').val();
			} else if (operation === 'set') {
				$('.grid_plugins_element_productUnit').val(value);
			}
		},
		/*
		 * 编辑插件编辑完成后触发事件
		 */
		handle : function() {},
		/*
		 * 编辑插件界面显示时触发事件 
		 */
		show : function() {
			$(".grid_plugins_element_productUnit").comboList('showPanel');
		}
	}
];

// 验证整数类型
GridPlugins.integer = function(cellvalue, options, rowObject){
	if(cellvalue ==='' || cellvalue == undefined){
		return "";
	}
	return parseInt(cellvalue);
}
