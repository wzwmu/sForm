var ListIndex = {
		
		options:{
			name:'商品',
			focusEle:'#condition'
		},
		gridOptions:{
			url:null,
			datatype: "json",
			arraytype:'list',
			pager:'#pager',
			autoResize:true,
			scrollrows:true,
			rowNum:10,
		   	rowList:[10,20,30],
			colOpts:[],
			colModel:[],
			bind:null
		},
		addOptions:{
			click:function(e){
				var name = this.options.name;
				$.dialog({ 
				    id: '1', 
				    title: "新增"+name, 
				    width: '700px', 
				    height: 350, 
				    lock: true, 
				    content:'url:create.do'
				});
			},
		    bind:null
		},
		searchOptions:{
			click:function(e){
				//$("#condition").focus();
				var form = $(this.searchOptions.bind).closest("form");
				form.find("input:first").focus();
				var data = FormUtils.getSubmitData(form);
				//alert(JSON.stringify(data));
				this.grid.jqGrid("setGridParam",{postData:data}).trigger("reloadGrid");
			},
			bind:null
		},
		optOptions:{
			
		},
		init:function(){
			this._initGlobal();
			this._initCombos(); 
			this._initGrid(this.gridOptions.bind);
			this._initAddButton(this.addOptions.bind);
			this._initSearchButton(this.searchOptions.bind);
			if(this._init)
				this._init();
		},
		_initGlobal:function(){
			$(this.options.focusEle).focus();
		},
		_initCombos:function(){
			if(!ArrayUtils.isArray(this.comboOptions)||this.comboOptions.length==0)
				return;
			for(var i=0;i<this.comboOptions.length;i++){
				var opt = this.comboOptions[i];
				this._initCombo(opt);
			}
		},
		_initCombo:function(opt){
			if(StringUtils.isEmpty(opt.bind)||StringUtils.isEmpty(opt.type))
				return;
			if(opt.type=="datepicker"){
				$(opt.bind).datepicker();
				return;
			}
			var url = "";
			if(typeof(opt.type)=="function")
				opt.type = opt.type();
			if(opt.type=="partner")
				url = "../partner/find.do";
			if(opt.type=="repository")
				url = "../repository/find.do";
			if(opt.type=="goodsType")
				url = "../goodsType/findGoodsType.do";
			else if(opt.type=="customer")
				url = "../customer/find.do";
			else if(opt.type=="balanceaccount")
				url = "../balanceAccount/find.do";
			var editable = true;
			if(typeof(opt.editable)!="undefined"&&opt.editable==false)
				editable = false;

			$(opt.bind).comboList({
				dataType:'json', 
				url:url,
				validate:true,
				editable:editable,
				jsonReader: {
					/*
					 * 集合的名称
					 */
					root: null
				},
				colModel:[
					{name:'id',isValue:true},	
					{name:'name',align: "center",isText:true}	
				],
				prmNames: {
					/*
					 * 传递到后台查询条件的名称
					 */
					condition:"name"
				}
			});
		},
		_initSearchButton:function(bind){
			if(StringUtils.isEmpty(bind))
				return;
			var btn = $(bind);
			var form = btn.closest("form");
			if(form.length>0){
				form.attr("onSubmit","return false;");
			}
			var clearEles = form.find(".clear");
			$.each(clearEles,function(i,n){
				var ele = $(n);
				if(StringUtils.isNotEmpty(ele.val())){
					ele.attr("title",ele.val());
					ele.click(function(){
						if($(this).val()==$(this).attr("title"))
							$(this).val("");
					}).blur(function(){
						if($(this).val()=="")
							$(this).val($(this).attr("title"));
					});
				}
			});
			var that = this;
			btn.on({
				click:function(e){
					that.searchOptions.click.apply(that,[e]);
				}
			});
		},
		_initAddButton:function(bind){
			if(StringUtils.isEmpty(bind))
				return;
			var that = this;
			$(bind).on({
				click:function(e){
					that.addOptions.click.apply(that,[e]);
				}
			});
		},
		_initGrid:function(bind){
			if(StringUtils.isEmpty(bind))
				return;
			this.grid = $(bind);
			var colModel = this.gridOptions.colModel;
			var that = this;
			
			for(var i=0;i<colModel.length;i++){
				if("operation"!=colModel[i].name&&"operating"!=colModel[i].name)
					continue;
				colModel[i].formatter=function(val, opt, row){
					var opts = [];
					opts[opts.length] = "<div class='operating' data-id='";
					opts[opts.length] = opt.rowId;
					opts[opts.length] = "'>";
					for(var i=0;i<that.gridOptions.colOpts.length;i++){
						var opt = that.gridOptions.colOpts[i];
						opts[opts.length] = "<span class='ui-icon "+opt.cls+"' title='"+opt.title+"'></span>";
					}
				    opts[opts.length] = "</div>";
				    return opts.join("");
				};
			}
			if(this.gridOptions.colOpts==null||this.gridOptions.colOpts.length==0){
				this.gridOptions.colOpts = [
				            			    {
				            			    	type:'edit',
				            			    	name:'修改',
				            			    	cls:'ui-icon-pencil',
				            			    	click:function(e,rowId,rowData){
				            			    		var name = this.options.name;
				            				    	$.dialog({ 
				            						    id: '1', 
				            						    title: "新增"+name, 
				            						    width: '700px', 
				            						    height: 350, 
				            						    lock: true, 
				            						    content:'url:edit.do?id='+rowData.id
				            						});
				            			    	}
				            			    },
				            			    {
				            			    	type:'del',
				            			    	name:'删除',
				            			    	cls:'ui-icon-trash',
				            			    	click:function(e,rowId,rowData){
				            				    	var that = this;
				            				    	var name = this.options.name;
				            			    		$.dialog.confirm("你确定要删除该"+name+"信息吗？", function(){
				            				    		var tip = $.dialog.tips("正在删除商"+name+"品数据...");
				            							$.ajax({
				            								url:'delete.do',
				            								data:{id:rowData.id},
				            								method:'get',
				            								success:function(){
				            									tip.close();
				            									that.grid.jqGrid("delRowData",rowId,{reloadAfterSubmit:false});
				            								}
				            							});
				            						});
				            			    	}
				            			    }
				            			];
			}
			this.grid.grid(this.gridOptions);
			for(var i=0;i<this.gridOptions.colOpts.length;i++){
				var opt = this.gridOptions.colOpts[i];
				var cls = opt.cls&&opt.cls.indexOf(".")<0?'.'+opt.cls:opt.cls;
				this.grid.on('click', cls, function(e){
					var id = $(this).parent().data('id');
					var data = that.grid.getRowData(id);
					var _opt = that.gridOptions.colOpts[$(this).index()];
					//_opt.click(e,id,data);
					_opt.click.apply(that,[e,id,data]);
				});
			}
		},
		_getFormData:function(form){
			var data = {};
			var eles = $(form).find("input,select,textarea");
			$.each(eles,function(i,n){
				var ele = $(n);
				var name = ele.attr("name");
				if(typeof(name)==undefined || name=="")
					name = ele.attr("id");
				data[name] = ele.val();
			});
			return data;
		},
		addRowData:function(data){
			var ids = this.grid.jqGrid('getDataIDs');  
		    var newrowId = (ids.length ==0 ? 1: Math.max.apply(Math,ids)+1);  
			this.grid.jqGrid('addRowData',newrowId,data);
			this.grid.resetSelection();
			this.grid.setSelection(newrowId);
		},
		updateRowData:function(data){
			var rowid = this.grid.jqGrid("getGridParam", "selrow");  
		    this.grid.jqGrid("setRowData",rowid,data);
		},
		showMessage:function(msg){
			var errorContainer = $("#errors div");
			errorContainer.append("<label for='' class='error'>"+msg+"</label>");
			errorContainer.parent().show();
		},
		clearMessage:function(forId){
			if(StringUtils.isEmpty(forId)){
				$("#errors div").empty().parent().hide();
			}else{
				var errorContainer = $("#errors div");
				errorContainer.children("label[for='"+forId+"']").remove();
				if(errorContainer.children("label").size()<1)
					errorContainer.parent().hide();
			}
		}
};