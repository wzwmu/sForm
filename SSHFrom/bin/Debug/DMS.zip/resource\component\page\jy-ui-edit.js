var Edit= {
		validate:function(){
			return true;
		},
		getFormData:function(){
			return null;
		},
		buttonOptions:[
		{
			name: '保存',
			focus:true,
			callback: function(){
				/*
				 * 如果没有绑定表单,保存事件不执行任何操作
				 */
				if(StringUtils.isEmpty(DialogExtend.getForm()) ||
						$(DialogExtend.getForm()).size()<1		)
					return false;
				if($(DialogExtend.getForm()).valid()==false ||
						DialogExtend.getEdit().validate()==false)
					return false;
				DialogExtend.getApi().button({
		            name: '保存',
		            disabled:true
		        });
		        var _params = FormUtils.getSubmitData(DialogExtend.getForm());
		        var params=$.extend(_params,DialogExtend.getEdit().getFormData());
		        
				var url = window.location.href;
				/* 防止id重复传参 */
				url = url.replace("id=", "aabbcc=");
		        DialogExtend.post({
				    params:params,
				    url:url,
				    dataType:"json",
				    success:function(data){
				    	if($("#id").val()!=""){
				    		DialogExtend.getIndex().updateRowData(data);
				    	}else{
				    		DialogExtend.getIndex().addRowData(data);
				    	}
				    	DialogExtend.getApi().close();
				    },
				    error:function(err) {
				    	DialogExtend.reset();
				    	DialogExtend.getApi().button({
				            name: '保存',
				            disabled:false
				        });
		            }
		        });
				return false;
			},
			focus: true
		},
		{
			name: '取消'
		}
		],
		options:{
			focusEle:null,
			bindForm:null,
			bindIndex:null
		},
		init:function(){
			if(this._init){
				this._init();
			}
			this._initGlobal();
			for(var i=0;i<this.buttonOptions.length;i++)
				DialogExtend.getApi().button(this.buttonOptions[i]);
			
		},
		_initGlobal:function(){
			if(StringUtils.isNotEmpty(this.options.focusEle))
				$(this.options.focusEle).focus(); 
			DialogExtend.bindEdit(this);
			$(this.options.bindForm).attr("onSubmit","return false");
		}
};