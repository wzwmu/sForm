
(function( $, undefined ) {
	
	//选取ou
	$.widget("ui.OU",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../enum/findOu.do",
			validate:true,
			panelHeight:120,
			dataCache:true,
			width:'95%',
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	
	//采购商收货联系人电话
	$.widget("ui.contactPhones",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			validate:false,
			panelHeight:120,
			width:'95%',
			editable:true,
			colModel:[
				{name:'phonenumber',isValue:true},
				{name:'phonenumber',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	$.widget("ui.enum",$.ui.comboList, { 
		options:{ 
			/*dataType:'json', */
			dataType:'local',
			url:"../enum/find.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	$.widget("ui.enumeration",$.ui.comboList, { 
		options:{
			dataType:'json', 
			/*dataType:'local',*/
			url:"../enum/find.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			clear: true,
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	
	$.widget("ui.enumerationquery",$.ui.comboList, { 
		options:{
			dataType:'json', 
			url:"../enum/find.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			initLoad:true,
			width:'90%',
			editable:true,
			selectable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	//查询未入库的订单信息列表
	$.widget("ui.unWarehousingOrder",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../godownEntry/unWarehousingOrder.do",
			validate:true,
			width:'90%',
			dataCache:true,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'no',align: "center",isText:true}
			]
		}
	});
	
	//查询经销商仓库
	$.widget("ui.storageVs", $.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findStorageVs.do",
			validate:true,
			width:'90%',
			dataCache:true,
			initLoad:true,
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'storageName',align: "center",isText:true}
			]
		}
	});
	//奶粉业务经理从伊利人员选择
    $.widget("ui.businessManagerNF", $.ui.comboList, {
        options:{
            dataType:'json',
            url:"../enum/findBusinessManagerForNF.do",
            validate:true,
            width:'90%',
            dataCache:true,
            initLoad:true,
            editable:true,
            jsonReader: {
                root: null
            },
            colModel:[
                {name:'id',isValue:true},
                {name:'name',align: "center",isText:true}
            ]
        }
    });
    //责任业代从伊利人员从选择
    $.widget("ui.dutyBusiness", $.ui.comboList, {
        options:{
            dataType:'json',
            url:"../enum/findDutyBusiness.do",
            validate:true,
            width:'90%',
            dataCache:true,
            initLoad:true,
            editable:true,
            jsonReader: {
                root: null
            },
            colModel:[
                {name:'id',isValue:true},
                {name:'name',align: "center",isText:true}
            ]
        }
    });

	//责任销代从伊利人员从选择
	$.widget("ui.saleBusiness", $.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findSaleBusiness.do",
			validate:true,
			width:'90%',
			dataCache:false,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]
		}
	});

	//当前经销商下的客户
	$.widget("ui.customers",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findApplyers.do?isSearch=true",
			validate:true,
			width:'90%',
			dataCache:false,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'applyerId',isValue:true},
				{name:'applyerName',align: "center",isText:true}
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"applyerName"
			}
		}})
	
	//查询当前客户同级客户
	$.widget("ui.customBySameLevel",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/getCustomBySameLevel.do",
			validate:true,
			width:'90%',
			dataCache:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	//费用类型(全部)
	$.widget("ui.expense",$.ui.comboList, { 
		options:{ 
			/*dataType:'json', */
			dataType:'local',
			url:"../enum/find.do",
			type:'enum',
			typecode:'TCBJ_EXPENSE_TYPE',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	$.widget("ui.expense_n",$.ui.comboList, { 
		options:{ 
			/*dataType:'json', */
			dataType:'local',
			url:"../enum/find.do",
			type:'enum',
			typecode:'TCBJ_EXPENSE_TYPE',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			},
			filter:{
				high : '0,1'
			}
		}
	});
	
	$.widget("ui.expense_w",$.ui.comboList, { 
		options:{ 
			/*dataType:'json', */
			dataType:'local',
			url:"../enum/find.do",
			type:'enum',
			typecode:'TCBJ_EXPENSE_TYPE',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			},
			filter:{
				high : '0,2'
			}
		}
	});
	
	$.widget("ui.locusOfControl",$.ui.comboList, { 
		options:{ 
			/*dataType:'json', */
			dataType:'local',
			url:"../enum/find.do",
			type:'enum',
			typecode:'TCBJ_CONTROL_SOURCE_TYPE',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	/**
	 * 获取指定经销商或当前经销商 下人员,
	 */
	$.widget("ui.contacts",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:"../enum/findContacts.do",
			type:'contacts',
			validate:true,
			dataCache:false,
			initLoad:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'fullname',align: "center",isText:true}	
			]
		}
	});
	
	/**
	 * 获取当前经销商下的销售代表
	 */
	$.widget("ui.contactsBySales",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:base + "/enum/findContactsBySales.do",
			type:'contacts',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'fullname',align: "center",isText:true}	
			]
		}
	});
	
	
	$.widget("ui.currency",$.ui.comboList, { 
		options:{ 
			dataType:'local', 
			url:"../enum/findCurrencyType.do",
			type:'currency',
			validate:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'curcyCd',isValue:true},	
				{name:'curcyCd',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	$.widget("ui.customerType",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:"../customerType/find.do",
			validate:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	$.widget("ui.partners",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:"../enum/partners.do",
			validate:true,
			editable:true,
			dataCache:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'no',align: "center",isText:true},
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	$.widget("ui.balanceaccount",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:"../balanceAccount/find.do",
			validate:true,
			panelHeight:120,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	$.widget("ui.years",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:2014,name:'2014'},{id:2015,name:'2015'},{id:2016,name:'2016'},{id:2017,name:'2017'},{id:2018,name:'2018'}],
			validate:false,
			width:'90%',
			panelHeight:120,
			editable:false,
			clear:true,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	$.widget("ui.budgetTargetType",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'org',name:'组织'},{id:'channel',name:'渠道'},{id:'bigarea',name:'大区'},{id:'area',name:'区域'},{id:'seller',name:'业务员'},{id:'customer',name:'客户'}],
			validate:false,
			width:'90%',
			panelHeight:156,
			editable:false,
			clear:true,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	/**
	 * 订单状态
	 */
	$.widget("ui.allStates",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../enum/findStates.do",
			type:'states',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'value',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	$.widget("ui.auditState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'dealing',name:'待确认'},{id:'dealed',name:'已确认'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	$.widget("ui.approveState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'dealing',name:'待审批'},{id:'dealed',name:'已审批'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	//sfa订单审批状态
	$.widget("ui.sfaApproveState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'0',name:'待审批'},{id:'1',name:'审批通过'},{id:'9',name:'审批不通过'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	//门店采购退货单状态
	$.widget("ui.shopReturnPurStatus",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'0',name:'新建'},{id:'1',name:'提交'},{id:'1-1',name:'已确认'},{id:'1-0',name:'确认不通过'},{id:'5',name:'已发货'},{id:'6',name:'已收货'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	//经销商订单审批状态
	$.widget("ui.purchaseOrderStatus",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'0',name:'新建'},{id:'1',name:'提交'},{id:'3',name:'审批通过'},{id:'2',name:'审批不通过'},{id:'1-1',name:'已确认'},{id:'1-0',name:'确认不通过'},{id:'5',name:'已发货'},{id:'6',name:'已收货'}],
			validate:true,
			panelHeight:180,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	
	//调拨订单审批状态
	$.widget("ui.allotOrderStatus",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'0',name:'新建'},{id:'1',name:'提交'},{id:'1-1',name:'已确认'},{id:'5',name:'已发货'},{id:'6',name:'已收货'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	
	$.widget("ui.sendState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'sending',name:'待发货'},{id:'sended',name:'已发货'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	$.widget("ui.xundanState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'0',name:'新建'},{id:'1-1',name:'确认'},{id:'10',name:'关闭'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	$.widget("ui.receiveState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{id:'',name:'全部'},{id:'sended',name:'待收货'},{id:'received',name:'已收货'}],
			validate:true,
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	$.widget("ui.goodsType",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../goodsType/findGoodsType.do",
			validate:true,
			panelHeight:120,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	$.widget("ui.storage",$.ui.comboList, { 
		options:{  
			dataType:'json',
			url:"../enum/findStorages.do",
			validate:true,
			panelHeight:120,
			dataCache:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'storageName',align: "center",isText:true},
				{name:'address',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	$.widget("ui.department",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../department/find.do",
			validate:true,
			panelHeight:120,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	$.widget("ui.products",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../select/findProducts.do",
			validate:true,
			width:'90%',
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	
	/* 新增客户，选择正式数据经销商,排除当前自己的 */
	$.widget("ui.notmypartner",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findNotmypartner.do",
			type:'suppliers',
			validate:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	$.fn.customer = function(){   
		$(this).click(function(){
			$.dialog({ 
				id: '1', 
				title: "选择客户", 
				width: 800, 
				height: 440, 
				lock: false, 
				content:'url:'+base+'/select/selectCustomer.do'
			});
		});
	}; 

	
	//当前经销商的客户
	$.widget("ui.applyers",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findApplyers.do",
			validate:true,
			width:'90%',
			dataCache:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'applyerId',isValue:true},
				{name:'applyerCode',align: "center",isText:true},
				{name:'applyerName',align: "center",isText:true}
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"applyerName"
			}
		}
	});
	

	/*获取当前组织经销商及下级经销商 */
	$.widget("ui.subPartner",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findSubPartner.do",
			type:'suppliers',
			validate:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});

	/*获取当前组织经销商及下级经销商 */
	$.widget("ui.subPartners",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findSubPartners.do",
			type:'suppliers',
			validate:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	/*获取当前渠道下所有经销商*/
	$.widget("ui.orgPartner",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findOrgPartners.do",
			type:'suppliers',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});

	/*获取当前组织下业务员*/
	$.widget("ui.salseManId",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findOrgSalesman.do",
			type:'suppliers',
			validate:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'contactName',align: "center",isText:true},	
				{name:'mobile',align: "center",isText:false	}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"contactName"
//				condition:"mobile"
			}
		}
	});
	
	
	/**
	 * 级联选择省市区
	 */
	$.widget("ui.findGeoregion",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../enum/findGeoregion.do",
			validate:true,
			dataCache:false,
			initLoad:true,
			width:'90%',
			panelHeight:120,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'rowId',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//级联选择区域
	$.widget("ui.areas",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findAreas.do",
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:false,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});

	//级联根据区域选择区域下的所有门店，其中包含了城市群层级
	$.widget("ui.areas_city",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findAreasCity.do",
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:false,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});

	$.widget("ui.subAreas",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findsubBusinessDepart.do",
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:false,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"regionName"
			}
		}
	});

	//级联选择区域
	$.widget("ui.manyAreas",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findManyAreas.do",
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:false,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});
	//门店-大区
	$.widget("ui.orgBigAreas",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findPartnerAreas.do",
			validate:true,
			width:'90%',
			dataCache:false,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});
	//当前经销商下的大区
	$.widget("ui.allBigAreas",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findAllBigAreas.do",
			validate:true,
			width:'90%',
			dataCache:false,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});
	
	
	$.widget("ui.positions",$.ui.comboList, {
		options:{ 
			dataType:'json',
			// url:"../enum/findPosition.do",
			url:"../enum/findDivisionPosition.do",
//			type:'suppliers',
			validate:true,
			width:'90%',
			dataCache:true,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
			          {name:'id',isValue:true},	
			          {name:'name',align: "center",isText:true}
			]
		}
	});
	/**
	 * 根据BUSINESS_UNIT_ID获取职位信息
	 */
	$.widget("ui.positionsExt",$.ui.comboList, {
		options:{ 
			dataType:'json',
			// url:"../enum/findPosition.do",
			url:"../enum/findDivisionPositionExt.do",
//			type:'suppliers',
			validate:true,
			width:'90%',
			dataCache:true,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
			          {name:'id',isValue:true},	
			          {name:'name',align: "center",isText:true}
			]
		}
	});

	/**
	 * 获取上级主管
	 */
	$.widget("ui.parentPerson",$.ui.comboList, {
		options:{
			dataType:'json',
			url:"../enum/findParentPerson.do",
//			type:'suppliers',
			validate:true,
			width:'90%',
			dataCache:true,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]
		}
	});
	
	/**
	 * 当前经销商的供货方
	 */
	$.widget("ui.supplieres",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findSupplieres.do",
			validate:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	/**
	 * 此方法用于获取经销商或直营门店在指定事业部下所归属的多个分仓
	 */
	$.widget("ui.supplierOUs",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findSupplierOUs.do",
			validate:true,
			dataCache:true,
			initLoad: true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]
		}
	});
	
	/**
	 * 根据事业部Id获取ou
	 */
	$.widget("ui.findOuByBusId",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findOuByBusId.do",
			validate:true,
			dataCache:true,
			initLoad: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]
		}
	});
	
	/**
	 * 经销商直营门店收货地址
	 */
	$.widget("ui.shipAddress",$.ui.comboList, {
		options:{ 
			dataType:'json',
			url:"../enum/findShipAddress.do",
			validate:true,
			initLoad: true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'address',align: "center",isText:true}
			]
		}
	});
	

	//销售价格状态
	$.widget("ui.priceState",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{"id": "1", "name": "有效"}, {"id": "2", "name": "无效"}],
			validate:false,
			width: '90%',
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	
	//获取指导价目表及该经销商的客户价目表 名称
	$.widget("ui.searchPriceListName",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			/*dataType:'local',*/
			url:"../productprice/searchPriceListNames.do",
			typecode:null,
			validate:true,
			dataCache:false,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				condition:"name"
			}
		}
	});

    //获取指导价目表及该经销商的客户价目表 名称
    $.widget("ui.searchPriceList",$.ui.comboList, {
        options:{
            dataType:'json',
            /*dataType:'local',*/
            url:"../enum/findPriceList.do",
            typecode:null,
            validate:true,
            dataCache:false,
			initLoad: true,
            width:'90%',
            editable:true,
            jsonReader: {
                root: null
            },
            colModel:[
                {name:'rowId',isValue:true},
                {name:'name',align: "center",isText:true}
            ],
            prmNames: {
                condition:"name"
            }
        }
    });

	//获取指导价目表及该经销商的客户价目表 名称
	$.widget("ui.compartment",$.ui.comboList, {
		options:{
			dataType:'json',
			/*dataType:'local',*/
			url:base + "/enum/findCompartment.do",
			typecode:null,
			validate:true,
			dataCache:false,
			initLoad: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'organizationName',align: "center",isText:true}
			],
			prmNames: {
				condition:"name"
			}
		}
	});
	
	
	//获取产品信息列表
	$.widget("ui.product",$.ui.comboList, {
		options:{
			dataType:'json',
			/*dataType:'local',*/
			url:base + "/enum/findProduct.do",
			typecode:null,
			validate:true,
			dataCache:false,
			initLoad: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			],
			prmNames: {
				condition:"name"
			}
		}
	});

	//采购商收货地址
	$.widget("ui.address",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			validate:false,
			panelHeight:120,
			width:'95%',
			editable:true,
			colModel:[
				{name:'address',isValue:true},
				{name:'address',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	//采购商收货联系人
	$.widget("ui.contacts",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			validate:false,
			panelHeight:120,
			width:'95%',
			editable:true,
			colModel:[
				{name:'fullname',isValue:true},
				{name:'fullname',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	//查询已入库的采购单单号
	$.widget("ui.entryPurchaseOrderNo",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:"../godownEntry/searchNo.do",
			typecode:null,
			validate:true,
			dataCache:false,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'no',isValue:true},	
				{name:'no',align: "center",isText:true}	
			],
			prmNames: {
				condition:"no"
			}
		}
	});
	
	//拜访方式
	$.widget("ui.visitMode",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{"id": "1", "name": "伊利业务拜访"}, {"id": "2", "name": "预售拜访"}, {"id": "3", "name": "车销拜访"}],
			validate:true,
			width: '90%',
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	//拜访日模式
	$.widget("ui.visitDayMode",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{"id": "1", "name": "每一周"},{"id": "2", "name": "每二周"},{"id": "3", "name": "每三周"},{"id": "4", "name": "每四周"}, {"id": "5", "name": "按间隔日"}, {"id": "6", "name": "按自然日"}],
			validate:true,
			width: '90%',
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	//销售区域业务员查询
	$.widget("ui.searchRegionUser",$.ui.comboList, {
		options:{ 
			dataType:'local',
			validate:true,
			panelHeight:120,
			dataCache: false,
			width:'95%',
			editable:true,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	//拜访路线状态
	$.widget("ui.state",$.ui.comboList, { 
		options:{ 
			dataType:'local',
			dataSource:[{"id": "1", "name": "有效"}, {"id": "0", "name": "无效"}],
			validate:true,
			width: '90%',
			panelHeight:120,
			editable:false,
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}	
		    ]
		}
	});
	
	//区域门店终端查询
	$.widget("ui.searchRegionShop",$.ui.comboList, {
		options:{
			dataType:'local',
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:false,
			initLoad:false,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'fullName', align: "center", isText:true}
			]
		}
	});
	
	//经销商下的客户(门店)终端查询
	$.widget("ui.searchPartnerShop",$.ui.comboList, { 
		options:{ 
			width:'90%',
			validate:true,
			colModel:[
				{name:'id',isValue:true},
				{name:'fullName',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});
	
	//获取当前登录人员可管理的经销商、分销商
	$.widget("ui.searchRegionPartner",$.ui.comboList, {
		options:{
			dataType:'json',
			url: base + "/enum/searchRegionPartner.do",
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:false,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name', align: "center", isText:true}
			],
			prmNames: {
				condition:"name"
			}
		}
	});
	
	//经销商业务员
	$.widget("ui.searchPartnerUser",$.ui.comboList, {
		options:{
			dataType:'json',
			url: base + "/enum/searchPartnerUser.do",
			validate:true,
			width:'90%',
			panelHeight:120,
			dataCache:true,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			],
			prmNames: {
				condition:"name"
			}
		}
	});
	
	//销售区域树形
	$.widget("ui.regionTree",$.ui.comboTree, {
		options:{
			dataType:'json',
			url: base + "/enum/findRegionTree.do",
			validate:true,
			width:'90%',
			panelHeight:260,
			panelWidth: 300,
			dataCache:true,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});
	
	//人员类型(内部外部)
	$.widget("ui.personType",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../enum/find.do",
			type:'enum',
			typecode:'TCBJ_PERSON_TYPE_CD',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			clear:true,
			panelHeight:85,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'val',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	
	/**
	 * 订单联系人
	 */
	$.widget("ui.linkman",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../enum/findLinkman.do",
			type:'enum',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'contactName',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});
	
	//伊利事业部
	$.widget("ui.businessDepart",$.ui.comboList, {
		options:{
			dataType:'json',
			url: base + "/enum/findBusinessDepart.do",
			validate:true,
			width:'90%',
			panelHeight:260,
			panelWidth: 300,
			dataCache:true,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'regionName',align: "center",isText:true}
			]
		}
	});

	//伊利事业部
	$.widget("ui.businessDepart2",$.ui.comboList, {
		options:{
			dataType:'json',
			url: base + "/enum/findBusinessDepart.do",
			validate:true,
			width:'90%',
			panelHeight:260,
			panelWidth: 300,
			dataCache:true,
			initLoad:true,
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]
		}
	});
	
	//查询分销商、代理商外部人员列表
	$.widget("ui.enumcontacts",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			/*dataType:'local',*/
			url:"../enum/findContacts.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'fullname',align: "center",isText:true}
			]
			
		}
	});


	//查询分销商经销商列表
	$.widget("ui.listPartners",$.ui.comboList, {
		options:{
			dataType:'json',
			/*dataType:'local',*/
			url:"../enum/listPartners.do",
			type:'enum',
			validate:true,
			dataCache:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]

		}
	});

	//查询门店列表
	$.widget("ui.listShops",$.ui.comboList, {
		options:{
			dataType:'json',
			/*dataType:'local',*/
			url:"../enum/listShops.do",
			type:'enum',
			validate:true,
			dataCache:true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			]

		}
	});
	
	/**获取当前登录人责任区域*/
	$.widget("ui.responsibilityRegion",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url: base + "/enum/findResponsibilityRegion.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:false,
			width:'90%',
			editable:true,
			panelHeight:120,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//可管理的组织(奶粉：经销商)
	$.widget("ui.pieceCodeDealerOrg",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/traceBackCode/orgByPartnerTraceCodesDelear.do",
			type:'enum',
			typecode:null,//PARTNER 经销商SHOP 门店  
			validate:true,
			dataCache:false,
			clear: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//可管理的组织(经销商、门店)
	$.widget("ui.manageOrg",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findManageOrg.do",
			type:'enum',
			typecode:null,//PARTNER 经销商SHOP 门店  
			validate:true,
			dataCache:false,
			clear: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//可管理的组织(经销商、分销商)
	$.widget("ui.manageOrgIds",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findManageOrgIds.do",
			type:'enum',
			typecode:null,//PARTNER 经销商、分销商
			validate:true,
			dataCache:false,
			clear: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
				]
		}
	});
	
	//可管理的组织(奶粉：分仓,经销商,分销商,门店)
	$.widget("ui.pieceCodeManageOrg",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/traceBackCode/orgByPartnerTraceCodesAll.do",
			type:'enum',
			typecode:null,//PARTNER 经销商SHOP 门店  
			validate:true,
			dataCache:false,
			clear: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	


	//可管理的区域(事业部、大区、区域、城市)
	$.widget("ui.manageRegion",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findManageRegion.do",
			type:'enum',
			typecode:null,//sbu 事业部、bigarea 大区、area 区域、city 城市
			validate:true,
			dataCache:false,
			clear: true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//可管理的区域(事业部、大区、区域、城市)
	$.widget("ui.manageRegionDevision",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findManageRegionDevision.do",
			type:'enum',
			typecode:null,//sbu 事业部、bigarea 大区、area 区域、city 城市
			validate:true,
			dataCache:false,
			clear: true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//最近三年的年份与月份
	$.widget("ui.lately3YearMonth",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/lately3YearMonth.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//未来三年的年与月
	$.widget("ui.future3YearMonth",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/future3YearMonth.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//获取期间内的年与月
	$.widget("ui.yearMonthBetween",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/yearMonthBetween.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//查询经销商奶粉计划版本
	$.widget("ui.queryPlanVersion",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/queryPlanVersion.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'name',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//查询经销商奶粉计划版本
	$.widget("ui.queryDisionByOrgId",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/queryDisionByOrgId.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
	
	//第三方供货商
	$.widget("ui.otherSuper",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findOtherSuper.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'supplierName',align: "center",isText:true}	
			]
		}
	});
	
	//第三方供货商销售的产品
	$.widget("ui.findOtherProduct",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findProductOtherSuperId.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'supplierName',align: "center",isText:true}	
			]
		}
	});
	
	//第三方供货商销售的产品
	$.widget("ui.findShopSupplier",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/shopPaterSupplier.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			]
		}
	});
		
	//获取母婴店常规积分积分订单明细订单商品分类
	$.widget("ui.findOrderProdType",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findOrderProdType.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			clear: true,
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'categoryId',isValue:true},	
				{name:'categoryVal',align: "center",isText:true}	
			]
		}
	});
	
	/**
	 * 积分订单发货量统计表获取订单类型
	 */
	$.widget("ui.findOrderType",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/findOrderType.do",
			type:'enum',
			typecode:null,
			validate:true,
			dataCache:true,
			width:'90%',
			clear: true,
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'categoryId',isValue:true},	
				{name:'categoryVal',align: "center",isText:true}	
			]
		}
	});
	
	$.widget("ui.findPartnersByBusType",$.ui.comboList, { 
		options:{ 
			dataType:'json', 
			url:base + "/enum/getPartnerByBusType.do",
			validate:true,
			editable:true,
			dataCache:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"orgName"
			}
		}
	});
	
	//根据事业部获取分仓
	$.widget("ui.getWareByBusType",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:base + "/enum/getWareByBusType.do",
			validate:true,
			dataCache:true,
			width:'90%',
			editable:true,
			colModel:[
				{name:'organizationId',isValue:true},
				{name:'organizationName',align: "center",isText:true}	
		    ],
			jsonReader: {
				root: null
			}
		}
	});

	//获取产品生产工厂信息列表
	$.widget("ui.factory",$.ui.comboList, {
		options:{
			dataType:'json',
			/*dataType:'local',*/
			url:base + "/report/linkTraceBackCode/findFactory.do",
			typecode:null,
			validate:true,
			dataCache:false,
			initLoad: true,
			width:'90%',
			editable:true,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},
				{name:'name',align: "center",isText:true}
			],
			prmNames: {
				condition:"name"
			}
		}
	});
	
	/**
	 * 获取经销商车仓集合
	 */
	$.widget("ui.findContacts",$.ui.comboList, { 
		options:{ 
			dataType:'json',
			url:"../enum/findAllotContacts.do",
			type:'enum',
			validate:true,
			dataCache:false,
			width:'90%',
			editable:false,
			jsonReader: {
				root: null
			},
			colModel:[
				{name:'id',isValue:true},	
				{name:'name',align: "center",isText:true}	
			],
			prmNames: {
				/*
				 * 传递到后台查询条件的名称
				 */
				condition:"name"
			}
		}
	});

}( jQuery ) );