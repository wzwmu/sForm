$.ajaxSetup({ 
	cache: false 
}); 

(function(){
	
	if(!window.console){
	    window.console = {};
	}
	
	if(!window.console.log){
	    window.console.log = function(msg){};
	}
	
	if(!window.console.info){
	    window.console.info = function(msg){};
	}
	
	if(!window.console.error){
	    window.console.error = function(msg){};
	}
	
})()

/** 
 * 时间对象的格式化; 
 */  
Date.prototype.format = function(format_) {  
    /* 
     * eg:format="yyyy-MM-dd hh:mm:ss"; 
     */
	
	var format = format_ || "yyyy-MM-dd hh:mm:ss" ;
	
    var o = {  
        "M+" : this.getMonth() + 1, // month  
        "d+" : this.getDate(), // day  
        "h+" : this.getHours(), // hour  
        "m+" : this.getMinutes(), // minute  
        "s+" : this.getSeconds(), // second  
        "q+" : Math.floor((this.getMonth() + 3) / 3), // quarter  
        "S" : this.getMilliseconds()  
        // millisecond  
    }  
  
    if (/(y+)/.test(format)) {  
        format = format.replace(RegExp.$1, (this.getFullYear() + "").substr(4  
                        - RegExp.$1.length));  
    }  
  
    for (var k in o) {  
        if (new RegExp("(" + k + ")").test(format)) {  
            format = format.replace(RegExp.$1, RegExp.$1.length == 1  
                            ? o[k]  
                            : ("00" + o[k]).substr(("" + o[k]).length));  
        }  
    }  
    return format;  
}  

$.fn.setCursorPosition = function(position){  
    if(this.lengh == 0) return this;  
    return $(this)._setSelection(position, position);  
};
  
$.fn._setSelection = function(selectionStart, selectionEnd) {  
    if(this.lengh == 0) return this;  
    input = this[0];   
  
    if (input.createTextRange) {  
        var range = input.createTextRange();  
        range.collapse(true);  
        range.moveEnd('character', selectionEnd);  
        range.moveStart('character', selectionStart);  
        range.select();  
    } else if (input.setSelectionRange) {  
        input.focus();  
        input.setSelectionRange(selectionStart, selectionEnd);  
    }  
    return this;  
}; 
  
$.fn.focusEnd = function(){   
    this.setCursorPosition(this.val().length);  
}; 
$.fn.disabled = function() {
	this.attr("disabled", true); 
	this.attr("tmp",this.attr("class"));
	this.removeAttr("class");
	this.addClass("disabled");
	return this; 
};
$.fn.enabled = function() {
	this.attr("disabled", false); 
	this.removeClass("disabled");
	this.attr("class",this.attr("tmp"));
	this.removeAttr("tmp");
	return this;
};
/*
 * 回车事件
 */
$.fn.enterKey = function() {
	this.each(function() {
		$(this).keydown(function(e) {
			if (e.which == 13) {
				var ref = $(this).data("jump");
				if (ref) {
					$('#' + ref).select().focus().click();
				}
				else {
					eval($(this).data("enterKeyHandler"));
				}
			}
		});
	}); 
	return this;
};
/*
 * 只允许输入数字
 */
$.fn.numberKey = function() { 
	this.each(function() {
		$(this).keypress(function(e) {
			var allowed = '0123456789.-', allowedReg;
			allowed = allowed.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
			allowedReg = new RegExp('[' + allowed + ']');
			var charCode = typeof e.charCode != 'undefined' ? e.charCode : e.keyCode; 
			var keyChar = String.fromCharCode(charCode);
			if(!e.ctrlKey && charCode != 0 && ! allowedReg.test(keyChar)){
				e.preventDefault();
			};
		});
	}); 
	return this;
}; 
var ContextUtils = {
	ctx:function(){
		return window.parent.top.appContext;
	}
};
var JsonUtils = {
	convertJsonToString:function(json){
		return JSON.stringify(json);
	}	
};
var GridUtils = {
	showGroup:function(val, opt, row) {
		if(val instanceof Array){
			return val.join('<p class="splitline" />');
		}else{
			return val;
		}
	},
	showPriceFormula:function(val,opt,row){
		return GridUtils._showPriceFormula("供货价格",val,opt,row);
	},
	showRtnPriceFormula:function(val,opt,row){
		return GridUtils._showPriceFormula("退货价格",val,opt,row);
	},
	_showPriceFormula:function(title,val,opt,row){
		if(StringUtils.isEmpty(val))
			return "";
		var json = jQuery.parseJSON(val);
		var formula = [];
		if("0"===json.type){
			formula[formula.length] = title+" = 全国统一价格 * 产品子类型扣率";
			formula[formula.length] = title+" = "+json.basePrice+" * "+json.settleRate+"%";
			return "<span style='cursor:pointer' title='"+formula.join("\n")+"'>元</span>";
		}
		else if("1"===json.type){
			formula[formula.length] = title+" = 全国统一价格 * 合同扣率";
			formula[formula.length] = title+" = "+json.basePrice+" * "+json.settleRate+"%";
			return "<span style='cursor:pointer' title='"+formula.join("\n")+"'>元</span>";
		}else if("2"===json.type){
			formula[formula.length] = title+" = 产品定价,不参照全国统一价格";
			formula[formula.length] = title+" = "+json.fixedPrice;
			return "<span style='cursor:pointer' title='"+formula.join("\n")+"'>元</span>";
		}else if("3"===json.type){
			formula[formula.length] = title+" = 全国统一价格 *（合同扣率+临时扣率）+ 固定加价";
			formula[formula.length] = title+" = "+json.basePrice+" * （"+json.settleRate+"%+"+json.discount+"%）+ "+json.markup;
			return "<span style='cursor:pointer' title='"+formula.join("\n")+"'>元</span>";
		}else{
			formula[formula.length] = title+" = 全国统一价格 *（产品子类型+临时扣率）+ 固定加价";
			formula[formula.length] = title+" = "+json.basePrice+" * （"+json.settleRate+"%+"+json.discount+"%）+ "+json.markup;
			return "<span style='cursor:pointer' title='"+formula.join("\n")+"'>元</span>";
		}
		return json.type;
	}
};
var MathUtils = {
	m2:function(val){
		var len = arguments.length>1?arguments[1]:1;
		if(isNaN(val))
			return 0;
		return parseFloat(val).toFixed(digits);
	}	
};
var ValidateFromUtils = {
		showError:function(error, element){
			var Y = $(element).offset().top;
			var X = $(element).offset().left+$(element).outerWidth() ;
			error.toggleClass("u-error");
			error.css({left:X,top:Y});
			if($("label[for='"+error.attr("for")+"']").length<1)
				$(document.body).append(error);
		},
		showErrorMessage:function(errormessage, elementName){
			var element = $("input[name='"+elementName+"']");
			var Y = $(element).offset().top;
			var X = $(element).offset().left+$(element).outerWidth() ;
			var error = $("<label for='"+elementName+"' generated='true' class='error u-error'></label>");
			error.html(errormessage);
			error.css({left:X,top:Y});
			if($("label[for='"+error.attr("for")+"']").length<1)
				$(document.body).append(error);
		},
		clearError:function(label){ 
			$("label[for='"+label.attr("for")+"']").remove();
		}
	};
var ValidateUtils = {
	_getContainer:function(){
		var c = $(".m-errors .body");
		if(c.length==0){
			c = $("<div class='body'></div>");
			var pc = $("<fieldset class='m-errors' style='display:none'><legend>数据录入错误信息</legend></fieldset>");
			pc.append(c);
			var side = $(".g-side");
			if(side.length==0){
				$(document.body).append(pc);
			}else{
				side.append(pc);
			}
		}
		return c;
	},
	showErrorMessage:function(msg){
		var errorContainer = ValidateUtils._getContainer();
		errorContainer.append("<label for='' class='error'>"+msg+"</label>");
		errorContainer.parent().show();
	},
	showError:function(error, element){
		var errorContainer = ValidateUtils._getContainer();
        var id = element.attr("id");
        var has = false;
        $.each(errorContainer.children("label"),function(i,n){
        	var label = $(n);
        	if(label.attr("for")==id){
        		has = true;
        	}
        });
        if(has==false){
        	errorContainer.append(error).parent().show();
        }
	},
	clearError:function(label){ 
		if(StringUtils.isEmpty(label)){
			ValidateUtils._getContainer().empty().parent().hide();
		}else{
			var errorContainer = ValidateUtils._getContainer();
			var forId = label.attr("for"); 
			errorContainer.children("label[for='"+forId+"']").remove();
			if(errorContainer.children("label").size()<1)
				errorContainer.parent().hide();
		}
	}
};
var FormUtils = {
	getSubmitData : function(container) {
		var data = {};
		var eles = $(container).find("input,select,textarea");
		$.each(eles, function(i, n) {
			var ele = $(n);
			
			var val = ele.val();
			
			try{
				if(ele.attr("type") == "radio"){
					console.info($(container).find("input[name='" + ele.attr("name") + "']:checked").val());
					val = $(container).find("input[name='" + ele.attr("name") + "']:checked").val();
				}
			}catch(e){}
			
			if(ele.hasClass("clear")){
				if(ele.val()==ele.attr("title"))
					val="";
			}
			var name = ele.attr("name");
			if ( name == undefined || name == "")
				name = ele.attr("id");
			if( name != undefined && name != ""){
				if(name.indexOf(".")>=0)
					name = name.substring(name.indexOf(".")+1,name.length);
				data[name] = val;
			}
		});
		return data;
	}
};
var ArrayUtils = {
	isArray:function(obj){
		if(typeof(obj)==="undefined" || obj===null)
			return false;
		return obj instanceof Array;
	}	
};

var StringUtils = {
	isEmpty:function(str){
		if(typeof(str)==="undefined" || str===null || $.trim(str)==="")
			return true;
		return false;
	},
	isNotEmpty:function(str){
		return !this.isEmpty(str);
	},
	replaceTemplate:function(str,obj){
		var start = str.indexOf("{");
		if(start<0)
			return str;
		var leftStr = str.substring(0,start);
		var rightStr = str.substring(start+1,str.length);
		var end = rightStr.indexOf("}");
		if(end<0)
			return str;
		var key = rightStr.substring(0,end);
		var value = ObjectUtils.isNull(obj[key])?"":obj[key];
		var newStr = leftStr+value;
		if(end+1<rightStr.length)
			newStr += rightStr.substring(end+1,rightStr.length);
		return StringUtils.replaceTemplate(newStr,obj);
	},
	isdigital:function(str){	//必须是整数
		if (/[^0-9 -]+/.test(str)){
			return true;
		}
	},
	range:function(str){	//1-100的整数
		if(parseInt(str,10)<1 || parseInt(str,10)>100 ){
			return true;
		}
	},
	number:function(str){
		
		if(!/^[0-9]+(.[0-9]{1,3})?$/.test(str)){
			return true;
		}
//		if(/^-?\d+[\.\d]?\d{0,2}$/.test(str)){
//			return true;
//		}
	},
	zip:function(str){	//邮编
//		alert(/^\d{6}$/.test(str));
		if(!/^\d{6}$/.test(str)){
			return true;
		}else{
			return false;
		}
	},
	mobile:function(str){//手机号
		if(!/^1[3-8]{1}\d{9}$/.test(str))
			return true;
		else
			return false;
		
	},
	tel:function(str){
		if(!/^0?\d{2,3}-?[1-9]{6,8}$/.test(str))
			return true;
		else
			return false;
			
	},
	
	email:function(str){
		if(!/^\w+((-\w+)|(\.\w+))*\@[A-Za-z0-9]+((\.|-)[A-Za-z0-9]+)*\.[A-Za-z0-9]+$/.test(str))
			return true;
		else 
			return false;
	}
	
};

var ObjectUtils = {
	isNull:function(obj){
		if(typeof(obj)==="undefined" || obj===null)
			return true;
		return false;
	},
	isNotNull:function(obj){
		return !this.isNull(obj);
	}
};

var ResultUtils = {
	showProgress:function(config){
		var ctn = config&&config.content?config.content:'数据正在处理中,请稍候......';
		var dlg = $.dialog({
		    id: 'id_result_nav',
		    title: "温馨提示",
		    width:400, 
		    height:30,
		    fixed: true,
		    max: false,
		    min: false,
		    close:false,
		    background: '#000', /* 背景色 */
		    opacity: 0.2,       /* 透明度 */
		    content: "",
		    lock: true,
		    esc: false,	
		    cancel: false 
		});
		dlg.content(ctn);
		return dlg;
	},
	showSuccess:function(config){
		ResultUtils.showInfo(config, "success");
	},
	showSuccessInfo:function(config){	
		config.buttons = 
		[
		 	{
		 		name: '关闭'
		 	}
		];
		ResultUtils.showInfo(config, "success");
	},
	showError:function(config){	
		config.buttons = 
		[
		 	{
		 		name: '关闭'
		 	}
		];
		ResultUtils.showInfo(config, "error");
	},
	showMessage:function(config){		
		ResultUtils.showInfo(config, "message");
	},
	showInfo:function(config,type){		
		var dlg = config.dialog;
		if(config.width&&config.height)
			dlg.size(config.width,config.height);
		if(config.content){
//			var wrap = $("<div class='"+type+"' style='overflow-y: scroll;height:"+config.height+"px;'></div>");
			var wrap = $("<div class='dlg_wrap "+type+"'></div>");
			if(StringUtils.isEmpty(config.content))
				config.content="&nbsp";
			wrap.append(config.content);
			dlg.content(wrap);
		}
		if(config.buttons){
			for(var i=0;i<config.buttons.length;i++){
				dlg.button(config.buttons[i]);
			}
		}
		if(config.timer){
			var i = 5;
			if(config.timer.second)
			var i=config.timer.second;
			var fn = function () {
				if(i < 0){return;}
	            dlg.title(i + '秒后跳转');
	            if(i==0){
	            	dlg.close();
	            	if(config.timer.callback)
	            		config.timer.callback();
	            }
	            i --;
	        };
        	timer = setInterval(fn, 1000);
	        fn();
		}
	},
	showNav:function(config){
		
		if(ObjectUtils.isNull(config))
			return;
		var title = config.title?config.title:'温馨提示';
		
		var next = $("<div class='m-nav2' id='global_loading'><div class='remark'>您可以继续选择下面的操作:<div></div>");
		var ul = $("<ul></ul>");
		if(ObjectUtils.isNotNull(config.navs)){
			for(var i=0;i<config.navs.length;i++){
				var nav = config.navs[i];
				var box = $("<li>"+nav.title+"</li>");
				box.click(function(){
					var no = $(this).index();
					config.navs[no].callback();
				});
				ul.append(box);
			}
		}
		next.append(ul);
		
		//$(document.body).append(next);
		//next.css({left:($(document.body).width()-next.width())/2,top:($(document.body).height()-next.height())/2});
		
		$.dialog({
		    id: 'id_result_nav',
		    title: title,
		    width:360,
		    height:180,
		    icon: 'success.gif',
		    fixed: true,
		    max: false,
		    min: false,
		    close:false,
		    background: '#000', /* 背景色 */
		    opacity: 0.5,       /* 透明度 */
		    content: next,
		    lock: true,
		    esc: false,	
		    cancel: false 
		});
	},
	removeNav:function(){
		//$(".m-nav2").remove();
		$.dialog({id: 'id_result_nav'}).close();
	}
};
var PopupU = {
	show:function(){
		var loading = $("<div class='popup' id='global_loading'>正在提交数据,请稍候...</div>");
		var loadingbg = $("<div class='popupbg'></div>");
		$(document.body).append(loading);
		$(document.body).append(loadingbg);
		
		var resizeLoading = function(){
			loadingbg.css({width:$(document).width(),height:$(document).height()});
			loading.css({top:($(document).height()+$(document).scrollTop()-loading.outerHeight())/2,left:($(document).width()-loading.width())/2});
			
		}
		resizeLoading();
		loading.show();
		loadingbg.show();
		$(window).resize(function(){
			resizeLoading();
		});
	},
	success:function(){
		
	}
};
var Confirm = {
	tips:function(config){
		var clz = "success";
		if(config.type&&config.type==2)
			clz = "error";
		var ele = $("<div class='m-conf "+clz+"'><div>");
		if(config&&config.message){
			ele.html(config.message);
		}
		var close = $("<div class='close'>х</div>");
		close.on("click",function(){
			ele.remove();
		});
		ele.append(close);
		ele.append("<span class='icon'></span>");
		ele.appendTo(document.body);
		if(config&&config.valign&&config.valign=='middle'){
			//var top = $(window).height()/2+$(document).scrollTop();
			var top = $(window).height()/2;
			//alert($(document).scrollTop());
			ele.css({top:top});
		}
		ele.css({left:($(document.body).width()-ele.outerWidth())/2});
		
		setTimeout(function () {
			ele.remove();
		}, 3000);
	},
	alert:function(config){
		var dlg = $.dialog({
		    id: 'id_result_nav',
		    title: "温馨提示",
		    width:400, 
		    height:120,
		    fixed: true,
		    max: false,
		    min: false,
		    close:false,
		    background: '#000', /* 背景色 */
		    opacity: 0.2,       /* 透明度 */
		    content: config.content,
		    lock: true,
		    esc: false
		});
		var wrap = $("<div class='dlg_wrap confirm'></div>");
		if(StringUtils.isEmpty(config.content))
			config.content="&nbsp";
		wrap.append(config.content);
		dlg.content(wrap);
	} 
};
var _AjaxForIframe = {
		_doSuccessResult:function(config,rtn){
	
		},
		post:function(config){
			//alert(1);
			//var loading = $("<div class='m-waiting' id='global_loading'></div>");
			//$(document.body).append(loading);
			//loading.css({top:($(document).height()-loading.height())/2,left:($(document).width()-loading.width())/2});
			//loading.show();
			
			var iframeName = 'iframe' + Math.random();
            var ifm = $('<iframe width="0" height="0" frameborder="1" id="'+ iframeName +'" name="'+ iframeName +'">');
            ifm.appendTo($('body'));
            var frm = $(config.form);
            frm.attr('target',iframeName);
            frm[0].submit();
            if(typeof(config.submitBefore)==="function"){
    			config.submitBefore();
    		}
            ifm.load(function(){
            	//loading.remove();
            	var doc = document.getElementById(iframeName).contentDocument||document.frames[iframeName].document;
                var rtn = doc.body.innerHTML;
                
                /* 解决ie8及以前版本返回结果中包含<PRE> */
//                if(rtn.toLowerCase().indexOf("<pre>")==0){
//                	rtn = rtn.substring(5,rtn.length-6);
//                }
                if(rtn.indexOf("<")==0){
                	rtn = jQuery.parseJSON(jQuery(rtn).text());
                }else{
                	rtn = jQuery.parseJSON(rtn);
                }
                if(rtn.status == "200"){
                	Ajax._doSuccessResult(config,rtn);
                }else{
                	if(rtn.error){
	            	config.error([ {
	    				message : rtn.error.infos[0]
	    			}]);
	            	}else{
	            		config.error([ {
		    				message : rtn.data
		    			}]);
	            	}
                }
                ifm.remove();
            });
		},
		callback:function(rtn){
			//$("#global_loading").remove();
			if (rtn.status == '200') {
				AjaxForIframe.config.success(rtn.data);
			} else { 
				var type = rtn.error.type;
				if (type === "ssoError") {
					// 身份验证异常
				} else if (type === "fieldError") {
					// 表单验证错误
					AjaxForIframe.config.error(rtn.error.infos);
				} else {
					// 其他类错误
					AjaxForIframe.config.error([ {
						message : '未知错误'
					} ]);
				}
			}
		}
	};
var AjaxForIframe = {
	post:function(config){
		AjaxForIframe.config = config;
		var id = Math.random();
		var ifr = $("<iframe id='"+id+"' name='"+id+"' style='display:none;'></iframe>");
		ifr.appendTo($(document.body));
		var frm = $(config.form);
		frm.attr("target",id); 
		
		if(typeof(config.submitBefore)==="function"){
			config.submitBefore();
		}
		
		frm[0].submit();
		
		//var loading = $("<div class='loading' id='global_loading'></div>");
		//$(document.body).append(loading);
	},
	callback:function(rtn){
		//$("#global_loading").remove();
		//alert(rtn.data);
		if (rtn.status == '200') {
			AjaxForIframe.config.success(rtn.data);
		} else { 
			var type = rtn.error.type;
			if (type === "ssoError") {
				// 身份验证异常
			} else if (type === "fieldError") {
				// 表单验证错误
				AjaxForIframe.config.error(rtn.error.infos);
			} else {
				// 其他类错误
				AjaxForIframe.config.error([ {
					message : '未知错误'
				} ]);
			}
		}
	}
};
var Ajax = {
	_doSuccessResult:function(config,rtn, status){
		var showError = function(errors){
			if(config.error){
				config.error(errors);
			}
			//Confirm.tips({type:'2',message:errors[0].message});
		};
		var showResult = function(data){
			if(config.success)
				config.success(data);
		};
		$("#global_loading").remove();
		$(".m-waitingbg").remove();
		if(ObjectUtils.isNull(rtn)){
			showError([{
				message : '未知错误'
			}]);
		}
		if ('200'===rtn.status) {
			showResult(rtn.data);
		} else {
			var type = rtn.type;
			if (type === "authentication") {
				// 身份验证异常,系统统一处理
				$.dialog({
					min:false,
					max:false,
				    content: '<br><br>由于长时间没有操作,为了安全考虑系统需要您重新进行登陆<br><br>',
				    init: function () {
				        var that = this, i = 3;
				        var fn = function () {
				        	if(i==0)
				        		top.location.href = top.location.href;
				            i --;
				        };
				        timer = setInterval(fn, 1000);
				        fn();
				    },
				    close: function () {
				        clearInterval(timer);
				    }
				});
			} else if (type === "validation") {
				// 表单验证错误
				if(config.error){
					config.error(rtn.data);
				}
			}else if (type === "business") {
				// 业务异常
				showError([ {
					message : rtn.data
				} ]);
			} else {
				// 其他类错误
				var emessage = "未知错误";
				if(StringUtils.isNotEmpty(rtn.data))
					emessage = rtn.data;
				showError([ {
					message : emessage
				} ]);
			}
		}
	},
	_doErrorResult:function(config,xhr, status, errMsg){
		$("#global_loading").remove();
		$(".m-waitingbg").remove();
		var msg = null;
//		alert(errMsg);
		if(errMsg.toLowerCase().indexOf("internal server error")>=0){
			msg = "服务器未知错误";
		}else if(errMsg.toLowerCase().indexOf("bad request")>=0){
			msg = "客户端数据不合法";
		}else{
			msg = "操作失败，请检查您的网络链接！";
		}
		if(config.error)
			config.error([ {
				message : msg
			} ]);
	},
	post : function(config) {
		if(true==config.progress){
			var loading = $("<div class='m-waiting' id='global_loading'>正在提交数据,请稍候...</div>");
			var loadingbg = $("<div class='m-waitingbg'></div>");
			$(document.body).append(loading);
			$(document.body).append(loadingbg);
			loadingbg.css({width:$(document).width(),height:$(document).height()});
			loading.css({top:($(document).height()+$(document).scrollTop()-loading.height())/2,left:($(document).width()-loading.width())/2});
			loading.show();
			loadingbg.show();
		}
		/******************************
		 * 临时处理,解决url后面带的参数和data中的属性重名后
		 * springmvc controller无法获取参数值
		 * 暂时只解决已发生的冲突属性id
		 *******************************/
		if(config.data&&ObjectUtils.isNotNull(config.data["id"]))
			config.url = config.url.replace("id=","_id=");
		
		var ct = config.contentType?config.contentType.toLowerCase():'application/x-www-form-urlencoded';
		if(config.data&&(ct==='application/json;charset=utf-8'||ct==='application/json;charset=utf8')){
			config.data = JSON.stringify(config.data);
			//alert(config.data);
		}
		
		var type = config.type?config.type:'post';
		
		if(typeof(config.submitBefore)==="function"){
			config.submitBefore();
		}
			
		$.ajax({
			type : type,
			url : config.url,
			data : config.data,
			dataType : config.dataType?config.dataType:'json',
			contentType:config.contentType?config.contentType:'application/x-www-form-urlencoded',
			success : function(rtn, status) {
				Ajax._doSuccessResult(config,rtn, status);
			},
			error : function(xhr, status, errMsg) {
				Ajax._doErrorResult(config,xhr, status, errMsg);
			}
		});
	},
	get : function(config) {
		config.type = "get";
		Ajax.post(config);
	}
};

function download_file(url)
{

    if (typeof (download_file.iframe) == "undefined")
    {
        var iframe = document.createElement("iframe");
        download_file.iframe = iframe;
        document.body.appendChild(download_file.iframe);
    }
    // alert(download_file.iframe);
    download_file.iframe.src = url;

    download_file.iframe.style.display = "none";
}

function urlPost(url, params){
	
	var formname = Math.random();
	
	document.write("<form action='" + url + "' method='post' name='" + formname + "' style='display:none'>");    
	
	for(var i  = 0; i < params.length; i++){
		document.write("<input type='hidden' name='" + params[i].name + "' value='" + params[i].val + "'></input>");    
	}
	
	document.write("</form>");    
	
	$("form[name='" + formname + "']").submit();	
}

/**
 * 获取日期间隔天数
 */
function getDateDiff(startDate, endDate){  
	
    var startTime = new Date(Date.parse(startDate.replace(/-/g,   "/"))).getTime();     
    var endTime = new Date(Date.parse(endDate.replace(/-/g,   "/"))).getTime();     
    var dates = Math.abs((startTime - endTime))/(1000*60*60*24);     
    return  dates;    
}
