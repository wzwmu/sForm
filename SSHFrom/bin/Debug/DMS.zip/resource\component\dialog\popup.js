/**
 * config = {
 * 		title: title, 
		width: '700px', 
		height: 350, 
		lock: true, 
		url:"",
		validateBefore:function(){}
 *      validate:function(){},
 *      submitBefore:function(){}
 *      submitData:function(){}
 *      submitTo:""
 *      submitContentType:""
 * }
 */
$.fn.popup = function(config){   
	var module = $(this);
	var url = config&&config.url?config.url:'about:blank';
	var title = config&&config.title?config.title:'弹出窗口';
	var popupOpt = { 
		    id: '1', 
		    title: title, 
		    width: '700px', 
		    height: 350, 
		    lock: true, 
		    content:'url:'+url
	};
	popupOpt = $.extend(popupOpt,config.popupOpt);
	module.on({
		click:function(e){
			$.dialog(popupOpt);
		}
	});
}; 

/**
 * config = {
 * 	   validateBefore:function(){}
 *     validate:function(){},
 *     submitBefore:function(){}
 *     submitData:function(){}
 *     submitTo:""
 *     submitContentType:""
 * }
 */
$.fn.popupButton = function(config){   
	
	////////////////////////
	var submitType = config&&config.submitType?config&&config.submitType:'ajax';
	if(submitType==='ajax'){
		var forms = $("form");
		if(forms.length>0){
			forms.attr("onSubmit","return false;");
		}	
	}
	////////////////////////
	
	
	var api = this[0];
	
	api.button({
	    name: '保存',
	    focus:true,
	    callback: function(){
	    	if(config&&config.validateBefore){
	    		config.validateBefore();
	    	}
	    	if(config&&config.validate){
	    		if(config.validate()==false)
	    			return false;
	    	}
			this.button({
                name: '保存',
                disabled: true
            });
			var params = null;
			if(config&&config.submitData){
				if(typeof(config.submitData)=="function")
					params = config.submitData();
				else
					params = config.submitData;
			}else{
				params = {};
			}
			if(config&&config.submitBefore){
				config.submitBefore();
			}
			
			var submitTo = config&&config.submitTo?config.submitTo:window.location.href;
			var submitContentType = config&&config.submitContentType?config.submitContentType:"application/x-www-form-urlencoded";
			var dialog = this;
			if(submitType==='ajax'){
				AjaxUtil.post({
					data:params,
				    dataType: "json",  
					contentType:submitContentType, 
				    url:submitTo,
				    success:function(data){
				    	if(config&&config.submitSuccess){
				    		config.submitSuccess(data);
				    	}
				    	dialog.close();
				    },
				    error:function(errs) {
				    	dialog.button({
				            name: '保存',
				            disabled:false
				        });
				    	for(var i=0;i<errs.length;i++){
				    		var err = errs[i];
				    		ValidateFromUtils.showErrorMessage(err.message,err.code);
				    	}
		            }
		        });
				return false;
			}else{
				//iframe方式提交表单
				_AjaxForIframe.post({
					success:function(data){
						if($("#id").val()!=""){
				    		var listgrid = api.opener.Index.grid;
				    		var rowid = listgrid.grid("getGridParam","selrow");
				    		listgrid.grid("setRowData",rowid,data);
				    	}else{
				    		var listgrid = api.opener.Index.grid;
				    		listgrid.grid("addRowData",data);
				    	}
				    	dialog.close();
				    },
				    error:function(errs) {
				    	dialog.button({
				            name: '保存',
				            disabled:false
				        });
				    	for(var i=0;i<errs.length;i++){
				    		var err = errs[i];
				    		//ValidateFromUtils.showErrorMessage(err.message,err.code);
				    	}
		            }
				});
				return false;
			}
	    },
	    focus: true
	},
	{
	    name: '取消'
	});
}; 