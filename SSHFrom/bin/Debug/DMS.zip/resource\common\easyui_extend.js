﻿/*依赖于easyui库a
 
$.dragIcon.drag(id,tagName,menuUrl,sortSaveUrl);
$.dragIcon.drag("conent",'li','data.jsp','sortsave.jsp');
*/
$.extend({dragIcon:{}});
$.extend($.dragIcon,{iconMap:{},hightDiff:124,noCloseTab:'个人门户',className:"",menuUrl:'data.jsp',sortSaveUrl:"sortsave.jsp",drag:function(obj,tagName,menuUrl,sortSaveUrl){
	
	var className    = this.className="#"+obj+" "+tagName;
	this.menuUrl     = menuUrl||this.menuUrl;
	this.sortSaveUrl = sortSaveUrl||this.sortSaveUrl;

	$(className).draggable({
		revert:true,cursor:'pointer',proxy:'clone',
		onStartDrag:function(){
                 var proxy = $(this).draggable('proxy').css('z-index', 40);
				 $(this).draggable('proxy').css({opacity:0.6});
				 $(this).draggable('proxy').attr('id',"proxy___li");
                 proxy.hide();
                 setTimeout(function(){
                	 proxy.show();
                 }, 300);
		}
	});
	var obj=this;
	$(className).droppable({
		onDragEnter:function(e,source){$(this).addClass("curr");},
		onDragLeave:function(e,source){if($(className).index(this)!=0){$(this).removeClass("curr");}},
		onDrop:function(e,source){
			var i=$(className).index(source),j=$(className).index(this);
		 if(i>j){$(source).insertBefore(this);}else{$(source).insertAfter(this);}
		  $("#proxy___li").remove();//删除拖拽代理
		  $(this).removeClass("curr");
           obj.saveSortChild();
		   
		}
	});
	this.bindClickEvent();
    
},
bindClickEvent:function(){//绑定图标单击事件，单击图标左边出相应菜单列表;
 var obj=this;
 $(this.className).bind('click',function(e){
	 
		$(this).parent().find(".curr").removeClass("curr");
		$(this).addClass("curr");
		var title=$(this).text();
		$("#menutitle").html(title);//菜单标题
		var id=$(this).attr("id");
		for(var key in obj.iconMap){
			$("#"+obj.iconMap[key]).css("display","none");
		}
		if(obj.iconMap[id]){//如果缓存中有数据从缓存中获取二级菜单
			$('#'+obj.iconMap[id]).css("display","block");
			 //选中第一个
			 
			 var panels = $("#"+obj.iconMap[id]).accordion('panels');
			 var t = panels[0].panel('options').title;
			 $("#"+obj.iconMap[id]).accordion('select', t);
             $("#"+obj.iconMap[id]+' li a').first().trigger("click");
             $('#'+obj.iconMap[id]).accordion("resize");
		}else{
			$.post(obj.menuUrl,{menuId:id},function(result){ //从服务器获取菜单列表
			result=result.replace(/\t|\r|\n/gi,"");
				var menus= $(result);
				var accordion_id="accordion_"+id;
                var accordion=$('<div id="'+accordion_id+'" class="easyui-accordion" data-options="hightDiff:'+obj.hightDiff+',fit:true,border:false" ></div>');
                $("#left").append(accordion);
				obj.iconMap[id]=accordion_id;//缓存每个二级菜单内容
				$.dragIcon.addMenu(accordion_id,menus);
                $("#"+accordion_id).accordion("resize");
			});	 
		}
  });
},
addTab:function (subtitle,url,icon,accordion_id){//添加标签内容，subtitle：标题，url:url链接，icon:标签图标
    var isCreate=false;
    var currTab = $('#tabs').tabs('tabs');
	for(var i=0;i<currTab.length;i++){
	  var option=currTab[i].panel('options');
	  var titleId=$(option.content).attr("accordion_id")+option.title;

	  if(titleId==(accordion_id+subtitle)){
	       isCreate=true;
		   break;
	  }

	}
	var closable=true;
	
	if(subtitle.split("<span")[0]==(this.noCloseTab)){
	  closable=false;
	}
	
	if(!isCreate){
		if(!document.getElementById("windowmask")){
	     $("<div id='windowmask' class=\"window-mask\" style='z-index:1000000;'><table align='center' style='height:100%;width:100%;z-index:2000000'><tr><td align='center' valign='middle'><img src='OAnew/img/ajax.gif'/></td></tr></table></div>").appendTo(window.top.document.body);
	    }else{
	     windowmask.style.display='block'
	    }
		$('.easyui-tabs').tabs('add',{
			title:subtitle,
			
			content:function(url){
	           var s = '<iframe scrolling="auto" onload="windowmask.style.display=\'none\'" accordion_id="'+accordion_id+'" frameborder="0"  src="'+url+'" style="width:100%;height:100%;" ></iframe>';
	           return s;}(url),
			closable:closable,
			icon:icon
		});
	  setTimeout("windowmask.style.display='none'",2000);
	}else{

		$('.easyui-tabs').tabs('select',subtitle);
        
		$('#mm-tabupdate').click();
		
	}
	 
	this.bindTabsRightMenu();
	
},addHtmlTab:function (subtitle,id,icon){

	if(!$('.easyui-tabs').tabs('exists',subtitle)){
		$('.easyui-tabs').tabs('add',{
			title:subtitle,
			content:$("#"+id).html(),
			closable:false,
			icon:icon
		});
	}else{
		$('.easyui-tabs').tabs('select',subtitle);
		
	}
	
},iconToggle:function(id){
   //图标矩阵的打开和关闭
       
      var closeIcon=function(topNav){
		      topNav.animate({height:'70px'},function(){topNav.css({"background-color":''});});
              topNav.removeAttr("sign"); 
		   }
      $("#"+id).bind('click',function(e){
		  if($("#"+id).prev().children().length<=7){
		   return;
	    }
		   var topNav=$(this).parent();
		   if(!topNav.attr("sign")){
		     topNav.css({"background-color":'#1f78b6'});
			 var row=Math.ceil(topNav.find("li").length/7);
			 var h=row*63+5*2*(row+1);
	         topNav.animate({height:h});
             topNav.attr("sign","1");
           }else{
	         closeIcon(topNav);
		   }
	  });
	  $("#"+id).parent().bind('mouseleave',function(){
		  if($("#"+id).prev().children().length<=7){
		   return;
	    }
	     closeIcon($(this));
	  });
}
,saveSortChild:function(){//排序完毕后，将排序后的图标保存到数据库
	  var xml="<root>";
      $(this.className).each(function(i){
	     xml+='<node index="'+i+'" name="'+$(this).text()+'" id="'+$(this).attr("id")+'"/>'
	  });
	  xml+="</root>" ;
	  
	  $.ajax({url:this.sortSaveUrl,
		      type:"POST",
		      data:{iconList:xml},
	          error: function(){
				//出错信息
			},
		   success:function(){}
	  });	 
	  return $(this.className);
},addMenu:function(accordion_id,menus){
    var ul=menus;
	$("#"+accordion_id).accordion({animate:false});
	var panels = $("#"+accordion_id).accordion('panels');
    var len=panels.length;
	var a=[];
	for(var i=0;i<len;i++){
	  var t = panels[i].panel('options').title;
       a[i]=t;
	}
	for(var i=0;i<len;i++){
	$("#"+accordion_id).accordion('remove',a[i]);
	}
	for(var i=0;i<ul.length;i++){
		var m=$(ul[i]);
         m.find(".nav").each(function(index){
			 $(this).append("<span style='display:none'>"+parseInt(Math.random()*100000000000000)+"</span>");
		     
		  }); 
		$("#"+accordion_id).accordion('add', {
            title: m.attr('title'),
            content: '<ul sign="'+accordion_id+'">'+m.html()+"</ul>",
            iconCls: 'icon ' + m.icon,
			sign:accordion_id
        });

	}
	

	///////
   
	$("#"+accordion_id+' li a').click(function(){
		var tabTitle = $(this).children('.nav').html();
		var url = $(this).attr("rel");
		var menuid = $(this).attr("ref");
		var icon = "";
	     $.dragIcon.addTab(tabTitle,url,icon,accordion_id);
		
		$("#"+accordion_id+' li div').removeClass("selected");
		$(this).parent().addClass("selected");
		
		
	}).hover(function(){
		
		$(this).parent().addClass("hover");
	},function(){
		$(this).parent().removeClass("hover");
	});
   
     //选中第一个
	var panels = $("#"+accordion_id).accordion('panels');
	var t = panels[0].panel('options').title;
    $("#"+accordion_id).accordion('select', t);
    $("#"+accordion_id+' li a').first().trigger("click");
 


 ///
},bindTabsRightMenu:function (){
	
	
	/*为选项卡绑定右键*/
	$(".tabs-inner").bind('contextmenu',function(e){
		$('#mm').menu('show', {
			left: e.pageX,
			top: e.pageY
		});

		var subtitle =$(this).children(".tabs-closable").text();

		$('#mm').data("currtab",subtitle);
		$('#tabs').tabs('select',subtitle);
		return false;
	});
}, bindtabCloseEven:function (){//绑定右键菜单事件
	//刷新
	var obj=this;
	$('#mm-tabupdate').click(function(){
		var currTab = $('#tabs').tabs('getSelected');
		var iframe= $(currTab.panel('options').content);
		var url = $(iframe).attr('src');
		var accordion_id=$(iframe).attr('accordion_id');
		windowmask.style.display='block'
		$('#tabs').tabs('update',{
			tab:currTab,
			options:{
				content:'<iframe scrolling="auto" onload="windowmask.style.display=\'none\';" accordion_id="'+accordion_id+'" frameborder="0"  src="'+url+'" style="width:100%;height:100%;" ></iframe>'
			}
		})
	})
			
			//setTimeout("windowmask.style.display='none'",2000);
	//关闭当前
	$('#mm-tabclose').click(function(){
       var currtab_title = $('.tabs-selected span').html();
	   if(currtab_title.indexOf(obj.noCloseTab)==-1){
         $('#tabs').tabs('close',currtab_title);
	   }
    })
	//全部关闭

	$('#mm-tabcloseall').click(function(){
		$('.tabs-inner span').each(function(i,n){
			var t = $(n).html();
			if(t.indexOf(obj.noCloseTab)==-1){
			 $('#tabs').tabs('close',t);
			}
		});
	});
}
});
//初始化右键菜单事件

$(function(){
	//窗口变化时重新调整二级菜单大小
	$(window).bind('resize', function(event) {
	  var currTab = $('#tabs').tabs('getSelected');
	    var resize=function(){$('.easyui-tabs').tabs('select',$('.tabs-selected span').html());}
	   setTimeout(resize,240);
    });
	//绑定tab标签右键菜单事件
    $.dragIcon.bindtabCloseEven();
	//表格隔行变换事件
	$("table.table_list").find("tbody tr:even").css('background-color','#f6f9fe');
    $("table.table_list").find("tbody tr:odd").css('background-color','#FFFFFF');
	$("table.table_list").each(function(){
		 var _table=this;
	    $(this).find("tbody tr").each(function(index,e){
               $(this).click(function(){//单击颜色
				      $(_table).find("tbody tr:even").css('background-color','#f6f9fe');
                      $(_table).find("tbody tr:odd").css('background-color','#FFFFFF');
				      $(this).css('background-color','#FBEC88');

                      $(_table).data("cursor",index);
			   }).mouseleave(function(){//鼠标离开后颜色
			        if(index%2==0){
					    if(RGBToHex($(this).css('background-color'))!='#FBEC88')
					  
						$(this).css('background-color','#f6f9fe');
					}else{
						if(RGBToHex($(this).css('background-color'))!='#FBEC88')
                        $(this).css('background-color','#FFFFFF');
					}
			   }).mouseover(function(){//鼠标放上去的颜色
			        if(index%2==0){
					    if(RGBToHex($(this).css('background-color'))!='#FBEC88')
					  
						$(this).css('background-color','#f6f9fe');
					}else{
						if(RGBToHex($(this).css('background-color'))!='#FBEC88')
                        $(this).css('background-color','#f6f9fe');
					}
			   });
		});
	});	
   $("form").submit(function(e){
		var validate=$(this).form("validate");
		 return validate;
	});
    //绑定ajax提交按钮
	$('.submit').bind('click',function(){
	     sbmit($(this).attr('formid'))
	
	});
	//三级菜单tab选中事件
    $('.easyui-tabs').tabs({onSelect:function(t){
            
		   var currTab = $('#tabs').tabs('getSelected');
		var iframe= $(currTab.panel('options').content);
		var accordion_id="#"+$(iframe).attr('accordion_id');
           //将一级菜单选中并显示
		   for(var key in $.dragIcon.iconMap){
			$("#"+$.dragIcon.iconMap[key]).css("display","none");
			$("#"+key).removeClass("curr");
			if(("#"+$.dragIcon.iconMap[key])==accordion_id){
			     $("#"+key).addClass("curr");
				  $("#menutitle").html($("#"+key).text());//菜单标题
			}
		   }
           //将二级菜单选中并显示调整尺寸
           $(accordion_id).css("display","block");
		   $(accordion_id).accordion("resize");
		 
		   var li= $(accordion_id+' li');
            for(var i=0;i<li.length;i++){
			    var tabTitle = $(li[i]).find("a").children('.nav').html();
			    if(tabTitle==t){
					var panels = $(accordion_id).accordion('panels');
					for(var j=0;j<panels.length;j++){
                       var t=panels[j].panel('options').title;
					   if(panels[j].html().indexOf(tabTitle)!=-1){
						 $(accordion_id).accordion('select', t);
                         $(accordion_id+' li div').removeClass("selected");
			             $(li[i]).find("div").addClass("selected");
			             return;
					   }
					}
					
				}
			}
	
	}});

});
function moveRow(sign,tableID){
	   var tID='#'+tableID;
	   var trs= $(tID).find("tbody tr");
	   var cursor=parseInt($(tID).data("cursor"));
	   var obj={};

     if(sign=='down'){
        if(cursor==undefined){cursor=-1}
		
	    cursor+=1;
		if(cursor>=trs.length)
		return;
        obj.id=$($(trs[cursor-1]).find("td")[0]).html();
	    obj.cursor=cursor;
		$(tID).find("tbody tr:even").css('background-color','#f6f9fe');
        $(tID).find("tbody tr:odd").css('background-color','#FFFFFF');
	    $(trs[cursor]).css('background-color','#FBEC88');
	   $(tID).data("cursor",cursor);
	    
	 }else{
		if(cursor==undefined){cursor=1}
	    cursor-=1;
		if(cursor<0)
		return;
		obj.id=$($(trs[cursor+1]).find("td")[0]).html();
		obj.cursor=cursor;
	    $(tID).find("tbody tr:even").css('background-color','#f6f9fe');
        $(tID).find("tbody tr:odd").css('background-color','#FFFFFF');
	    $(trs[cursor]).css('background-color','#FBEC88');
	   $(tID).data("cursor",cursor); 	 
     }
     return obj;
}
//ajax提交form  <input type="button" class='submit' formid='ff' value="提交"/>
function sbmit(form){
   $('#'+form).form({ 
	  url:$('#'+form).attr("action"),
	onSubmit: function(){   
	   var validate=$('#'+form).form("validate");
	   return validate;
	},   
	success:function(data){   
	   msgShow("提示框","提交成功",'success');
   }});   
	$('#'+form).submit();
}

//弹出信息窗口 title:标题 msgString:提示信息 msgType:信息类型 [success,error,info,question,warning]
function msgShow(title, msgString, msgType) {
	var a=window.top.$.messager.alert(title, msgString, msgType);
}
//弹出远程html，jsp文件对话框，url:链接地址，fn:回调函数
function showUrlWindow(url,title,ajax,fn,width,height){
	  var width=710,height=350
	     var _diaglog=$("<div id='myshowwinddow'></div>").appendTo(document.body); 
	     $(_diaglog).dialog({href:url,width:540,height:290,resizable:true,title:title||'窗口', modal : true,
			           onLoad:function(){
		                     var _from=$(_diaglog).find("form");
							 if(!_from){
								return;
							 }
	               			  var w=_from.find(".form_box").width()+35;
							  var h=_from.find(".form_box").height()+90;
							  var top=($(window).height()-h)/2+$(document).scrollTop();
							  var left=($(window).width()-w)/2;
							 
							 $(_diaglog).dialog("resize",{width:w,height:h,top:top,left:left});
	                        
		               },
		               buttons:[{
						text:'确定',
						iconCls:'icon-ok',
						
						handler:function(){	
						  if(fn){
	                       //回调函数
						   fn.call(this,"#myshowwinddow",_diaglog);

	                      } 
						  var _from=$(_diaglog).find("form");
						  if(ajax){
							 
						  _from.form({ 
							  url:_from.attr("action"),
							  onSubmit: function(){   
							    var validate=_from.form("validate");
							   return validate;
							  },success:function(data){   
							    msgShow("提示框","提交成功",'success');
	                           $(_diaglog).dialog("close");
						   }});   
						   _from.submit();
						   
						  }else{
							  
	                       if(_from.form("validate")){
							   var div=document.getElementById("myshowwinddow");
							  
							   div.getElementsByTagName("form")[0].submit();
						    };
						  }
	                        
						}
					},{
						text:'关闭',
						handler:function(){
							 $(_diaglog).dialog("close");
						}
					}],onClose:function(){  $(_diaglog).dialog('destroy');}
	});
}
//弹出本地html窗口，id：元素id， fn：回调函数
function showHtmlWinow(id,title,fn){

     $("#"+id).dialog({title:title,resizable:true,iconCls:"icon-save", modal : true, buttons:[{
					text:'确定',
					iconCls:'icon-ok',
					handler:function(){	
					  if(fn){
						 
					   fn.call(this,"#myshowwinddow");
                      }
					  var _from=$("#"+id).find("form");
					  if(_from.length>=1){
						  if(_from.form("validate")){
						   var div=document.getElementById(id);
						   var form=div.getElementsByTagName("form")[0];
						   $(form).form('submit', {   
							 url:_from.attr("action"),   
							 success:function(data){   
								 $("#"+id).dialog("close");
							 }
							});
						  }
					    }else{
						  $("#"+id).dialog("close");
						}
					   
					}
				},{
					text:'取消',
					handler:function(){
						 $("#"+id).dialog("close");
					}
				}]
});
}

//iframe自适应
function iframeH(ifId)
	{
		var win = document.getElementById(ifId).contentWindow;
		var heihgt = win.document.body.offsetHeight;
		document.getElementById(ifId).height=heihgt; 
		
	}

//tabs插件

(function ($) {

    $.fn.extend({

        qmTabs: function () {
			
            $(this).children("li").each(function (index) {
				var rel=$(this).find("a").attr("rel");
                if(index==0&&rel!=""&&rel!=undefined){
				  var aTabBodys = $(this).parent().parent().next().find('div.tabC');
				  var c=aTabBodys.hide().eq(index);
				  $.ajax({url:rel,success:function(data){
								c.html(data);
				   }});
				  c.show();
				}
               

                $(this).click(function () {
					
                    $(this).addClass('active').siblings().removeClass('active');
					 var aTabBodys = $(this).parent().parent().next().find('div.tabC');
					 var c=aTabBodys.hide().eq(index);
					  c.show();
                      var rel=$(this).find("a").attr("rel");
					  if(rel!=""&&rel!=undefined){
						  $.ajax({url:rel,success:function(data){
								c.html(data);
								//alert(data);
						  }});
					  }
					   
                });

            });

        }

    });

})(jQuery);

function formatter(date){
	var y = date.getFullYear();
	var m = date.getMonth()+1;
	var d = date.getDate();
	return y+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d);
}

function test1(){
	
	alert("test1");
	
}

//rgb颜色转换为16进制

function RGBToHex(rgb){
             if(navigator.userAgent.indexOf("MSIE 6.0")>0||navigator.userAgent.indexOf("MSIE 7.0")>0||navigator.userAgent.indexOf("MSIE 8.0")>0){
				    
				   return rgb.toUpperCase();
				 }
                var regexp = /^rgb\(([0-9]{0,3})\,\s([0-9]{0,3})\,\s([0-9]{0,3})\)/g;

                var re = rgb.replace(regexp, "$1 $2 $3").split(" ");//利用正则表达式去掉多余的部分
                var hexColor = "#";
                var hex = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'];
                for (var i = 0; i < 3; i++) {
                    var r = null;
                    var c = re[i];
                    var hexAr = [];
                    while (c > 16) {
                        r = c % 16;
                        c = (c / 16) >> 0;
                        hexAr.push(hex[r]);
                    }
                    hexAr.push(hex[c]);
                    hexColor += hexAr.reverse().join('');
                }
                
                return hexColor;
            }